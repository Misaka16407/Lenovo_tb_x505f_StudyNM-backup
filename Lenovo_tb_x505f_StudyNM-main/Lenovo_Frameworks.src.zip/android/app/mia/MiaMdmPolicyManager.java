package android.app.mia;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.provider.Settings;
import java.util.List;

public class MiaMdmPolicyManager {
  private static final String TAG = "MiaMdmPolicyManager";
  
  private static IMiaMdmPolicyService mService;
  
  private final Context mContext;
  
  public MiaMdmPolicyManager(Context paramContext) {
    this.mContext = paramContext;
  }
  
  private boolean getControl(String paramString) {
    boolean bool = false;
    if (1 == Settings.System.getInt(this.mContext.getContentResolver(), paramString, 0))
      bool = true; 
    return bool;
  }
  
  private static IMiaMdmPolicyService getService() {
    if (mService != null)
      return mService; 
    mService = IMiaMdmPolicyService.Stub.asInterface(ServiceManager.getService("mia_mdm"));
    return mService;
  }
  
  private void sentControl(String paramString1, String paramString2, boolean paramBoolean) {
    Intent intent = new Intent();
    intent.setAction(paramString1);
    if (paramBoolean) {
      intent.putExtra(paramString2, true);
    } else {
      intent.putExtra(paramString2, false);
    } 
    this.mContext.sendBroadcast(intent);
  }
  
  private void sentControl(String paramString, boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = false;
    } else {
      bool = true;
    } 
    MiaSystemSetting(paramString, bool);
  }
  
  public List<String> APPIPBlackListRead() {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      List<String> list = iMiaMdmPolicyService.APPIPBlackListRead();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (List<String>)remoteException;
  }
  
  public List<String> APPIPWhiteListRead() {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      List<String> list = iMiaMdmPolicyService.APPIPWhiteListRead();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (List<String>)remoteException;
  }
  
  public boolean AddAppBlackRule(String paramString) {
    boolean bool;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      bool = iMiaMdmPolicyService.AddAppBlackRule(paramString);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean AddAppWhiteRule(String paramString) {
    boolean bool;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      bool = iMiaMdmPolicyService.AddAppWhiteRule(paramString);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean ClearAppRules() {
    boolean bool;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      bool = iMiaMdmPolicyService.ClearAppRules();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean ClearURLListRules() {
    boolean bool;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      bool = iMiaMdmPolicyService.ClearURLListRules();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public void MiaSystemSetting(String paramString, int paramInt) {
    try {
      getService().MiaSystemSetting(paramString, paramInt);
    } catch (RemoteException remoteException) {}
  }
  
  public void addBluetoothPairingWhitelist(List<String> paramList) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.addBluetoothPairingWhitelist(paramList);
    } catch (RemoteException remoteException) {}
  }
  
  public void addDisallowedUninstallPackages(List<String> paramList) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    if (paramList != null)
      try {
        iMiaMdmPolicyService.addDisallowedUninstallPackages(paramList);
      } catch (RemoteException remoteException) {} 
  }
  
  public void addInstallPackages(List<String> paramList) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    if (paramList != null)
      try {
        iMiaMdmPolicyService.addInstallPackages(paramList);
      } catch (RemoteException remoteException) {} 
  }
  
  public void addNotificationList(List<String> paramList) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    if (paramList != null)
      try {
        iMiaMdmPolicyService.addNotificationList(paramList);
      } catch (RemoteException remoteException) {} 
  }
  
  public void addWifiWhiteList(List<String> paramList) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.addWifiWhiteList(paramList);
    } catch (RemoteException remoteException) {}
  }
  
  public void allowBluetooth(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.allowBluetooth(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean allowBluetoothDataTransfer(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    boolean bool = false;
    try {
      paramBoolean = iMiaMdmPolicyService.allowBluetoothDataTransfer(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = bool;
    } 
    return paramBoolean;
  }
  
  public void allowLocation(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.allowLocation(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void allowNotification(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.allowNotification(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean allowWifi(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      paramBoolean = iMiaMdmPolicyService.allowWifi(paramBoolean);
    } catch (Exception exception) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public List<String> appWhiteListRead() {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      List<String> list = iMiaMdmPolicyService.getInstallPackageWhiteList();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (List<String>)remoteException;
  }
  
  public boolean appWhiteListWrite(List<String> paramList) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    if (paramList != null) {
      boolean bool1;
      try {
        iMiaMdmPolicyService.addInstallPackages(paramList);
        bool1 = true;
      } catch (RemoteException remoteException) {
        bool1 = false;
      } 
      return bool1;
    } 
    boolean bool = true;
  }
  
  public void canDrawOveylays(String paramString) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.canDrawOveylays(paramString);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean clearCustomLauncher() {
    boolean bool;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      bool = iMiaMdmPolicyService.clearCustomLauncher();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public void controlApp(String paramString, boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.controlApp(paramString, paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean controlClipboard(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    boolean bool = false;
    try {
      paramBoolean = iMiaMdmPolicyService.controlClipboard(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = bool;
    } 
    return paramBoolean;
  }
  
  public boolean deleteLockPattern(int paramInt) {
    boolean bool;
    try {
      bool = getService().unlockScreen();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean forceLocationService(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    boolean bool = false;
    try {
      paramBoolean = iMiaMdmPolicyService.forceLocationService(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = bool;
    } 
    return paramBoolean;
  }
  
  public List<String> getBluetoothPairingWhitelist() {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      List<String> list = iMiaMdmPolicyService.getBluetoothPairingWhitelist();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (List<String>)remoteException;
  }
  
  public String getBtStatus() {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    String str = null;
    try {
      String str1 = iMiaMdmPolicyService.getBtStatus();
      str = str1;
    } catch (RemoteException remoteException) {}
    return str;
  }
  
  public List<String> getDisallowedUninstallPackageList() {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      List<String> list = iMiaMdmPolicyService.getDisallowedUninstallPackageList();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (List<String>)remoteException;
  }
  
  public List<String> getInstallPackageWhiteList() {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      List<String> list = iMiaMdmPolicyService.getInstallPackageWhiteList();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (List<String>)remoteException;
  }
  
  public Bitmap getMiaScreen() {
    try {
      Bitmap bitmap = getService().getMiaScreen();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (Bitmap)remoteException;
  }
  
  public List<String> getNotificationList() {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      List<String> list = iMiaMdmPolicyService.getNotificationList();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (List<String>)remoteException;
  }
  
  public String getWifiStatus() {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    String str = null;
    try {
      String str1 = iMiaMdmPolicyService.getWifiStatus();
      str = str1;
    } catch (RemoteException remoteException) {}
    return str;
  }
  
  public List<String> getWifiWhiteList() {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      List<String> list = iMiaMdmPolicyService.getWifiWhiteList();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (List<String>)remoteException;
  }
  
  public boolean isBluetoothAllowed() {
    boolean bool;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      bool = iMiaMdmPolicyService.isBluetoothAllowed();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isBluetoothDataTransferAllowed() {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    boolean bool = false;
    try {
      boolean bool1 = iMiaMdmPolicyService.isBluetoothDataTransferAllowed();
      bool = bool1;
    } catch (RemoteException remoteException) {}
    return bool;
  }
  
  public boolean isBluetoothPairingControl(String paramString) {
    boolean bool;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      bool = iMiaMdmPolicyService.isBluetoothPairingControl(paramString);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isCoerciveMute() {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    boolean bool = false;
    try {
      boolean bool1 = iMiaMdmPolicyService.isCoerciveMute();
      bool = bool1;
    } catch (RemoteException remoteException) {}
    return bool;
  }
  
  public boolean isControlBackKey() {
    boolean bool;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      bool = iMiaMdmPolicyService.isControlBackKey();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isControlClipboard() {
    boolean bool2;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    boolean bool1 = false;
    try {
      bool2 = iMiaMdmPolicyService.isControlClipboard();
    } catch (RemoteException remoteException) {
      bool2 = bool1;
    } 
    return bool2;
  }
  
  public boolean isControlHomeKey() {
    boolean bool;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      bool = iMiaMdmPolicyService.isControlHomeKey();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isControlRecentsKey() {
    boolean bool;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      bool = iMiaMdmPolicyService.isControlRecentsKey();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isControlStatus() {
    boolean bool2;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    boolean bool1 = false;
    try {
      bool2 = iMiaMdmPolicyService.isControlStatus();
    } catch (RemoteException remoteException) {
      bool2 = bool1;
    } 
    return bool2;
  }
  
  public boolean isControlmiaNavigaView() {
    boolean bool;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      bool = iMiaMdmPolicyService.isControlmiaNavigaView();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isForbidCamera() {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    boolean bool = false;
    try {
      boolean bool1 = iMiaMdmPolicyService.isForbidCamera();
      bool = bool1;
    } catch (RemoteException remoteException) {}
    return bool;
  }
  
  public boolean isForbidScreenCaptureKey() {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    boolean bool = false;
    try {
      boolean bool1 = iMiaMdmPolicyService.isForbidScreenCaptureKey();
      bool = bool1;
    } catch (RemoteException remoteException) {}
    return bool;
  }
  
  public boolean isForbidTFcard() {
    boolean bool2;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    boolean bool1 = false;
    try {
      bool2 = iMiaMdmPolicyService.isForbidTFcard();
    } catch (RemoteException remoteException) {
      bool2 = bool1;
    } 
    return bool2;
  }
  
  public boolean isInstallControl(String paramString) {
    boolean bool;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      bool = iMiaMdmPolicyService.isInstallControl(paramString);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isInstallNonMarketAppOpen() {
    boolean bool;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      bool = iMiaMdmPolicyService.isInstallNonMarketAppOpen();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isLocationAllowed() {
    boolean bool;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      bool = iMiaMdmPolicyService.isLocationAllowed();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isLocationServiceForced() {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    boolean bool = false;
    try {
      boolean bool1 = iMiaMdmPolicyService.isLocationServiceForced();
      bool = bool1;
    } catch (RemoteException remoteException) {}
    return bool;
  }
  
  public boolean isNotificationAllowed() {
    boolean bool;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      bool = iMiaMdmPolicyService.isNotificationAllowed();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isNotificationList(String paramString) {
    boolean bool;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      bool = iMiaMdmPolicyService.isNotificationList(paramString);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isSafeModeAllowed() {
    boolean bool;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      bool = iMiaMdmPolicyService.isSafeModeAllowed();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isUninstallControl(String paramString) {
    boolean bool;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      bool = iMiaMdmPolicyService.isUninstallControl(paramString);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isUsbOnlyCharging() {
    boolean bool2;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    boolean bool1 = false;
    try {
      bool2 = iMiaMdmPolicyService.isUsbOnlyCharging();
    } catch (RemoteException remoteException) {
      bool2 = bool1;
    } 
    return bool2;
  }
  
  public boolean isWifiAllowed() {
    boolean bool;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      bool = iMiaMdmPolicyService.isWifiAllowed();
    } catch (Exception exception) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isWifiControl(String paramString) {
    boolean bool;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      bool = iMiaMdmPolicyService.isWifiControl(paramString);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isWifiOpen() {
    boolean bool;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      bool = iMiaMdmPolicyService.isWifiOpen();
    } catch (Exception exception) {
      bool = false;
    } 
    return bool;
  }
  
  public void killApplicationProcess(String paramString) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.killApplicationProcess(paramString);
    } catch (RemoteException remoteException) {}
  }
  
  public void masterClearInbulitSD() {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.masterClearInbulitSD();
    } catch (RemoteException remoteException) {}
  }
  
  public void openWifi(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.openWifi(paramBoolean);
    } catch (Exception exception) {}
  }
  
  public void reBoot() {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.reBoot();
    } catch (Exception exception) {}
  }
  
  public void removeBluetoothPairingWhitelist(List<String> paramList) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.removeBluetoothPairingWhitelist(paramList);
    } catch (RemoteException remoteException) {}
  }
  
  public void removeDisallowedUninstallPackages(List<String> paramList) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    if (paramList != null)
      try {
        iMiaMdmPolicyService.removeDisallowedUninstallPackages(paramList);
      } catch (RemoteException remoteException) {} 
  }
  
  public void removeInstallPackages(List<String> paramList) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    if (paramList != null)
      try {
        iMiaMdmPolicyService.removeInstallPackages(paramList);
      } catch (RemoteException remoteException) {} 
  }
  
  public void removeNotificationList(List<String> paramList) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    if (paramList != null)
      try {
        iMiaMdmPolicyService.removeNotificationList(paramList);
      } catch (RemoteException remoteException) {} 
  }
  
  public void removeWifiWhiteList(List<String> paramList) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.removeWifiWhiteList(paramList);
    } catch (RemoteException remoteException) {}
  }
  
  public void reset() {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.reset();
    } catch (RemoteException remoteException) {}
  }
  
  public boolean restoreSlideLock(boolean paramBoolean) {
    try {
      paramBoolean = getService().restoreSlideLock(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public void setAdbEnable(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.setAdbEnable(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setBackKey(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.setBackKey(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setBluetoothPairingWhitelist(List<String> paramList) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.setBluetoothPairingWhitelist(paramList);
    } catch (RemoteException remoteException) {}
  }
  
  public void setCamera(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.setCamera(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean setCoerciveMute(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    boolean bool = false;
    try {
      paramBoolean = iMiaMdmPolicyService.setCoerciveMute(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = bool;
    } 
    return paramBoolean;
  }
  
  public boolean setCustomLauncher(String paramString) {
    boolean bool;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      bool = iMiaMdmPolicyService.setCustomLauncher(paramString);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public void setDisallowedUninstallPackages(List<String> paramList) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    if (paramList != null)
      try {
        iMiaMdmPolicyService.setDisallowedUninstallPackages(paramList);
      } catch (RemoteException remoteException) {} 
  }
  
  public void setFullScreen(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.setFullScreen(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean setGps(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    boolean bool = false;
    try {
      paramBoolean = iMiaMdmPolicyService.setGps(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = bool;
    } 
    return paramBoolean;
  }
  
  public void setHomeKey(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.setHomeKey(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setInstall(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.setInstall(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setInstallNonMarketApp(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.setInstallNonMarketApp(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setInstallPackages(List<String> paramList) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    if (paramList != null)
      try {
        iMiaMdmPolicyService.setInstallPackages(paramList);
      } catch (RemoteException remoteException) {} 
  }
  
  public boolean setLockPassword(String paramString) {
    boolean bool;
    try {
      bool = getService().setLockPassword(paramString);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public void setNavigaBar(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.setNavigaBar(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setNotificationList(List<String> paramList) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    if (paramList != null)
      try {
        iMiaMdmPolicyService.setNotificationList(paramList);
      } catch (RemoteException remoteException) {} 
  }
  
  public void setPowerLongPressKey(boolean paramBoolean) {
    sentControl("mia_control_powerLongPress_key", paramBoolean);
  }
  
  public void setPowerSingleClickKey(boolean paramBoolean) {
    sentControl("mia_control_powerSingleClick_key", paramBoolean);
  }
  
  public void setRecentKey(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.setRecentKey(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setReset(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.setReset(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setSafeMode(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.setSafeMode(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setScreenCaptureKey(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.setScreenCaptureKey(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setStatusBar(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.setStatusBar(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setTFcard(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.setTFcard(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setUninstall(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.setUninstall(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setUsbOnlyCharging(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.setOnlyCharging(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setUsbSettingShow(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.setUsbSettingShow(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setVolumedownKey(boolean paramBoolean) {
    sentControl("mia_control_volumedown_key", paramBoolean);
  }
  
  public void setVolumeupKey(boolean paramBoolean) {
    sentControl("mia_control_volumeup_key", paramBoolean);
  }
  
  public void setWifiProxy(boolean paramBoolean) {
    sentControl("mia_wifi_proxy_key", paramBoolean);
  }
  
  public void setWifiWhiteList(List<String> paramList) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.setWifiWhiteList(paramList);
    } catch (RemoteException remoteException) {}
  }
  
  public void shutDown() {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.shutDown();
    } catch (Exception exception) {}
  }
  
  public void silentInstall(String paramString) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.silentInstall(paramString);
    } catch (RemoteException remoteException) {}
  }
  
  public void silentUnInstall(String paramString) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.silentUnInstall(paramString);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean updateSystemTime(String paramString) {
    boolean bool;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      bool = iMiaMdmPolicyService.updateSystemTime(paramString);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public List<String> urlBlackListRead() {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      List<String> list = iMiaMdmPolicyService.urlBlackListRead();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (List<String>)remoteException;
  }
  
  public boolean urlBlackListWrite(List<String> paramList) {
    boolean bool;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      bool = iMiaMdmPolicyService.urlBlackListWrite(paramList);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean urlSetEnable(boolean paramBoolean) {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      paramBoolean = iMiaMdmPolicyService.SetEnable(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public List<String> urlWhiteListRead() {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      List<String> list = iMiaMdmPolicyService.urlWhiteListRead();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (List<String>)remoteException;
  }
  
  public boolean urlWhiteListWrite(List<String> paramList) {
    boolean bool;
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      bool = iMiaMdmPolicyService.urlWhiteListWrite(paramList);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public void wirteIPV6() {
    IMiaMdmPolicyService iMiaMdmPolicyService = getService();
    try {
      iMiaMdmPolicyService.wirteIPV6();
    } catch (RemoteException remoteException) {}
  }
}


/* Location:              C:\Users\Tonyha7\Desktop\huovink_-mdm_catch_for_-lenovo-master\lspirer\lspirer\master-new\app\libs\Lenovo_Frameworks.jar!\android\app\mia\MiaMdmPolicyManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */