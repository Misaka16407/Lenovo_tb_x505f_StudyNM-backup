package android.app.mia;

import android.graphics.Bitmap;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import java.util.ArrayList;
import java.util.List;

public interface IMiaMdmPolicyService extends IInterface {
  List<String> APPIPBlackListRead() throws RemoteException;
  
  List<String> APPIPWhiteListRead() throws RemoteException;
  
  boolean AddAppBlackRule(String paramString) throws RemoteException;
  
  boolean AddAppWhiteRule(String paramString) throws RemoteException;
  
  boolean ClearAppRules() throws RemoteException;
  
  boolean ClearURLListRules() throws RemoteException;
  
  void MiaSystemSetting(String paramString, int paramInt) throws RemoteException;
  
  boolean SetEnable(boolean paramBoolean) throws RemoteException;
  
  void addBluetoothPairingWhitelist(List<String> paramList) throws RemoteException;
  
  void addDisallowedUninstallPackages(List<String> paramList) throws RemoteException;
  
  void addInstallPackages(List<String> paramList) throws RemoteException;
  
  void addNotificationList(List<String> paramList) throws RemoteException;
  
  void addWifiWhiteList(List<String> paramList) throws RemoteException;
  
  void allowBluetooth(boolean paramBoolean) throws RemoteException;
  
  boolean allowBluetoothDataTransfer(boolean paramBoolean) throws RemoteException;
  
  void allowLocation(boolean paramBoolean) throws RemoteException;
  
  void allowNotification(boolean paramBoolean) throws RemoteException;
  
  boolean allowWifi(boolean paramBoolean) throws RemoteException;
  
  void canDrawOveylays(String paramString) throws RemoteException;
  
  boolean clearCustomLauncher() throws RemoteException;
  
  void controlApp(String paramString, boolean paramBoolean) throws RemoteException;
  
  boolean controlClipboard(boolean paramBoolean) throws RemoteException;
  
  boolean forceLocationService(boolean paramBoolean) throws RemoteException;
  
  List<String> getBluetoothPairingWhitelist() throws RemoteException;
  
  String getBtStatus() throws RemoteException;
  
  List<String> getDisallowedUninstallPackageList() throws RemoteException;
  
  List<String> getInstallPackageWhiteList() throws RemoteException;
  
  Bitmap getMiaScreen() throws RemoteException;
  
  List<String> getNotificationList() throws RemoteException;
  
  String getWifiStatus() throws RemoteException;
  
  List<String> getWifiWhiteList() throws RemoteException;
  
  boolean isBluetoothAllowed() throws RemoteException;
  
  boolean isBluetoothDataTransferAllowed() throws RemoteException;
  
  boolean isBluetoothPairingControl(String paramString) throws RemoteException;
  
  boolean isCoerciveMute() throws RemoteException;
  
  boolean isControlBackKey() throws RemoteException;
  
  boolean isControlClipboard() throws RemoteException;
  
  boolean isControlHomeKey() throws RemoteException;
  
  boolean isControlRecentsKey() throws RemoteException;
  
  boolean isControlStatus() throws RemoteException;
  
  boolean isControlmiaNavigaView() throws RemoteException;
  
  boolean isForbidCamera() throws RemoteException;
  
  boolean isForbidScreenCaptureKey() throws RemoteException;
  
  boolean isForbidTFcard() throws RemoteException;
  
  boolean isInstallControl(String paramString) throws RemoteException;
  
  boolean isInstallNonMarketAppOpen() throws RemoteException;
  
  boolean isLocationAllowed() throws RemoteException;
  
  boolean isLocationServiceForced() throws RemoteException;
  
  boolean isNotificationAllowed() throws RemoteException;
  
  boolean isNotificationList(String paramString) throws RemoteException;
  
  boolean isSafeModeAllowed() throws RemoteException;
  
  boolean isUninstallControl(String paramString) throws RemoteException;
  
  boolean isUsbOnlyCharging() throws RemoteException;
  
  boolean isWifiAllowed() throws RemoteException;
  
  boolean isWifiControl(String paramString) throws RemoteException;
  
  boolean isWifiOpen() throws RemoteException;
  
  void killApplicationProcess(String paramString) throws RemoteException;
  
  void masterClearInbulitSD() throws RemoteException;
  
  void openWifi(boolean paramBoolean) throws RemoteException;
  
  void reBoot() throws RemoteException;
  
  void removeBluetoothPairingWhitelist(List<String> paramList) throws RemoteException;
  
  void removeDisallowedUninstallPackages(List<String> paramList) throws RemoteException;
  
  void removeInstallPackages(List<String> paramList) throws RemoteException;
  
  void removeNotificationList(List<String> paramList) throws RemoteException;
  
  void removeWifiWhiteList(List<String> paramList) throws RemoteException;
  
  void reset() throws RemoteException;
  
  boolean restoreSlideLock(boolean paramBoolean) throws RemoteException;
  
  void setAdbEnable(boolean paramBoolean) throws RemoteException;
  
  void setBackKey(boolean paramBoolean) throws RemoteException;
  
  void setBluetoothPairingWhitelist(List<String> paramList) throws RemoteException;
  
  void setCamera(boolean paramBoolean) throws RemoteException;
  
  boolean setCoerciveMute(boolean paramBoolean) throws RemoteException;
  
  boolean setCustomLauncher(String paramString) throws RemoteException;
  
  void setDisallowedUninstallPackages(List<String> paramList) throws RemoteException;
  
  void setFullScreen(boolean paramBoolean) throws RemoteException;
  
  boolean setGps(boolean paramBoolean) throws RemoteException;
  
  void setHomeKey(boolean paramBoolean) throws RemoteException;
  
  void setInstall(boolean paramBoolean) throws RemoteException;
  
  void setInstallNonMarketApp(boolean paramBoolean) throws RemoteException;
  
  void setInstallPackages(List<String> paramList) throws RemoteException;
  
  boolean setLockPassword(String paramString) throws RemoteException;
  
  void setNavigaBar(boolean paramBoolean) throws RemoteException;
  
  void setNotificationList(List<String> paramList) throws RemoteException;
  
  boolean setOnlyCharging(boolean paramBoolean) throws RemoteException;
  
  void setRecentKey(boolean paramBoolean) throws RemoteException;
  
  void setReset(boolean paramBoolean) throws RemoteException;
  
  void setSafeMode(boolean paramBoolean) throws RemoteException;
  
  void setScreenCaptureKey(boolean paramBoolean) throws RemoteException;
  
  void setStatusBar(boolean paramBoolean) throws RemoteException;
  
  void setTFcard(boolean paramBoolean) throws RemoteException;
  
  void setUninstall(boolean paramBoolean) throws RemoteException;
  
  void setUsbSettingShow(boolean paramBoolean) throws RemoteException;
  
  void setWifiWhiteList(List<String> paramList) throws RemoteException;
  
  void shutDown() throws RemoteException;
  
  void silentInstall(String paramString) throws RemoteException;
  
  void silentUnInstall(String paramString) throws RemoteException;
  
  boolean unlockScreen() throws RemoteException;
  
  boolean updateSystemTime(String paramString) throws RemoteException;
  
  List<String> urlBlackListRead() throws RemoteException;
  
  boolean urlBlackListWrite(List<String> paramList) throws RemoteException;
  
  List<String> urlWhiteListRead() throws RemoteException;
  
  boolean urlWhiteListWrite(List<String> paramList) throws RemoteException;
  
  void wirteIPV6() throws RemoteException;
  
  public static abstract class Stub extends Binder implements IMiaMdmPolicyService {
    private static final String DESCRIPTOR = "android.app.mia.IMiaMdmPolicyService";
    
    static final int TRANSACTION_APPIPBlackListRead = 89;
    
    static final int TRANSACTION_APPIPWhiteListRead = 88;
    
    static final int TRANSACTION_AddAppBlackRule = 91;
    
    static final int TRANSACTION_AddAppWhiteRule = 90;
    
    static final int TRANSACTION_ClearAppRules = 93;
    
    static final int TRANSACTION_ClearURLListRules = 94;
    
    static final int TRANSACTION_MiaSystemSetting = 100;
    
    static final int TRANSACTION_SetEnable = 92;
    
    static final int TRANSACTION_addBluetoothPairingWhitelist = 23;
    
    static final int TRANSACTION_addDisallowedUninstallPackages = 55;
    
    static final int TRANSACTION_addInstallPackages = 50;
    
    static final int TRANSACTION_addNotificationList = 77;
    
    static final int TRANSACTION_addWifiWhiteList = 10;
    
    static final int TRANSACTION_allowBluetooth = 15;
    
    static final int TRANSACTION_allowBluetoothDataTransfer = 17;
    
    static final int TRANSACTION_allowLocation = 26;
    
    static final int TRANSACTION_allowNotification = 71;
    
    static final int TRANSACTION_allowWifi = 2;
    
    static final int TRANSACTION_canDrawOveylays = 101;
    
    static final int TRANSACTION_clearCustomLauncher = 79;
    
    static final int TRANSACTION_controlApp = 80;
    
    static final int TRANSACTION_controlClipboard = 35;
    
    static final int TRANSACTION_forceLocationService = 29;
    
    static final int TRANSACTION_getBluetoothPairingWhitelist = 20;
    
    static final int TRANSACTION_getBtStatus = 95;
    
    static final int TRANSACTION_getDisallowedUninstallPackageList = 52;
    
    static final int TRANSACTION_getInstallPackageWhiteList = 47;
    
    static final int TRANSACTION_getMiaScreen = 34;
    
    static final int TRANSACTION_getNotificationList = 74;
    
    static final int TRANSACTION_getWifiStatus = 96;
    
    static final int TRANSACTION_getWifiWhiteList = 7;
    
    static final int TRANSACTION_isBluetoothAllowed = 16;
    
    static final int TRANSACTION_isBluetoothDataTransferAllowed = 18;
    
    static final int TRANSACTION_isBluetoothPairingControl = 21;
    
    static final int TRANSACTION_isCoerciveMute = 38;
    
    static final int TRANSACTION_isControlBackKey = 64;
    
    static final int TRANSACTION_isControlClipboard = 36;
    
    static final int TRANSACTION_isControlHomeKey = 65;
    
    static final int TRANSACTION_isControlRecentsKey = 66;
    
    static final int TRANSACTION_isControlStatus = 69;
    
    static final int TRANSACTION_isControlmiaNavigaView = 67;
    
    static final int TRANSACTION_isForbidCamera = 25;
    
    static final int TRANSACTION_isForbidScreenCaptureKey = 33;
    
    static final int TRANSACTION_isForbidTFcard = 31;
    
    static final int TRANSACTION_isInstallControl = 48;
    
    static final int TRANSACTION_isInstallNonMarketAppOpen = 43;
    
    static final int TRANSACTION_isLocationAllowed = 27;
    
    static final int TRANSACTION_isLocationServiceForced = 28;
    
    static final int TRANSACTION_isNotificationAllowed = 72;
    
    static final int TRANSACTION_isNotificationList = 75;
    
    static final int TRANSACTION_isSafeModeAllowed = 45;
    
    static final int TRANSACTION_isUninstallControl = 53;
    
    static final int TRANSACTION_isUsbOnlyCharging = 12;
    
    static final int TRANSACTION_isWifiAllowed = 3;
    
    static final int TRANSACTION_isWifiControl = 8;
    
    static final int TRANSACTION_isWifiOpen = 5;
    
    static final int TRANSACTION_killApplicationProcess = 102;
    
    static final int TRANSACTION_masterClearInbulitSD = 98;
    
    static final int TRANSACTION_openWifi = 4;
    
    static final int TRANSACTION_reBoot = 39;
    
    static final int TRANSACTION_removeBluetoothPairingWhitelist = 22;
    
    static final int TRANSACTION_removeDisallowedUninstallPackages = 54;
    
    static final int TRANSACTION_removeInstallPackages = 49;
    
    static final int TRANSACTION_removeNotificationList = 76;
    
    static final int TRANSACTION_removeWifiWhiteList = 9;
    
    static final int TRANSACTION_reset = 40;
    
    static final int TRANSACTION_restoreSlideLock = 83;
    
    static final int TRANSACTION_setAdbEnable = 13;
    
    static final int TRANSACTION_setBackKey = 60;
    
    static final int TRANSACTION_setBluetoothPairingWhitelist = 19;
    
    static final int TRANSACTION_setCamera = 24;
    
    static final int TRANSACTION_setCoerciveMute = 37;
    
    static final int TRANSACTION_setCustomLauncher = 78;
    
    static final int TRANSACTION_setDisallowedUninstallPackages = 51;
    
    static final int TRANSACTION_setFullScreen = 70;
    
    static final int TRANSACTION_setGps = 97;
    
    static final int TRANSACTION_setHomeKey = 61;
    
    static final int TRANSACTION_setInstall = 56;
    
    static final int TRANSACTION_setInstallNonMarketApp = 42;
    
    static final int TRANSACTION_setInstallPackages = 46;
    
    static final int TRANSACTION_setLockPassword = 81;
    
    static final int TRANSACTION_setNavigaBar = 63;
    
    static final int TRANSACTION_setNotificationList = 73;
    
    static final int TRANSACTION_setOnlyCharging = 11;
    
    static final int TRANSACTION_setRecentKey = 62;
    
    static final int TRANSACTION_setReset = 41;
    
    static final int TRANSACTION_setSafeMode = 44;
    
    static final int TRANSACTION_setScreenCaptureKey = 32;
    
    static final int TRANSACTION_setStatusBar = 68;
    
    static final int TRANSACTION_setTFcard = 30;
    
    static final int TRANSACTION_setUninstall = 57;
    
    static final int TRANSACTION_setUsbSettingShow = 14;
    
    static final int TRANSACTION_setWifiWhiteList = 6;
    
    static final int TRANSACTION_shutDown = 1;
    
    static final int TRANSACTION_silentInstall = 59;
    
    static final int TRANSACTION_silentUnInstall = 58;
    
    static final int TRANSACTION_unlockScreen = 82;
    
    static final int TRANSACTION_updateSystemTime = 99;
    
    static final int TRANSACTION_urlBlackListRead = 85;
    
    static final int TRANSACTION_urlBlackListWrite = 87;
    
    static final int TRANSACTION_urlWhiteListRead = 84;
    
    static final int TRANSACTION_urlWhiteListWrite = 86;
    
    static final int TRANSACTION_wirteIPV6 = 103;
    
    public Stub() {
      attachInterface(this, "android.app.mia.IMiaMdmPolicyService");
    }
    
    public static IMiaMdmPolicyService asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("android.app.mia.IMiaMdmPolicyService");
      return (iInterface != null && iInterface instanceof IMiaMdmPolicyService) ? (IMiaMdmPolicyService)iInterface : new Proxy(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      ArrayList<String> arrayList2;
      List<String> list2;
      Bitmap bitmap;
      ArrayList<String> arrayList1;
      List<String> list1;
      String str1;
      String str2;
      boolean bool1 = false;
      null = false;
      boolean bool2 = false;
      boolean bool3 = false;
      boolean bool4 = false;
      boolean bool5 = false;
      boolean bool6 = false;
      boolean bool7 = false;
      boolean bool8 = false;
      boolean bool9 = false;
      boolean bool10 = false;
      boolean bool11 = false;
      boolean bool12 = false;
      boolean bool13 = false;
      boolean bool14 = false;
      boolean bool15 = false;
      boolean bool16 = false;
      boolean bool17 = false;
      boolean bool18 = false;
      boolean bool19 = false;
      boolean bool20 = false;
      boolean bool21 = false;
      boolean bool22 = false;
      boolean bool23 = false;
      boolean bool24 = false;
      boolean bool25 = false;
      boolean bool26 = false;
      boolean bool27 = false;
      boolean bool28 = false;
      boolean bool29 = false;
      boolean bool30 = false;
      boolean bool31 = false;
      boolean bool32 = false;
      boolean bool33 = false;
      boolean bool34 = false;
      boolean bool35 = false;
      boolean bool36 = false;
      boolean bool37 = false;
      boolean bool38 = false;
      boolean bool39 = false;
      boolean bool40 = false;
      boolean bool41 = false;
      boolean bool42 = false;
      boolean bool43 = false;
      boolean bool44 = false;
      boolean bool45 = false;
      boolean bool46 = false;
      boolean bool47 = false;
      boolean bool48 = false;
      boolean bool49 = false;
      boolean bool50 = false;
      boolean bool51 = false;
      boolean bool52 = false;
      boolean bool53 = false;
      boolean bool54 = false;
      boolean bool55 = false;
      boolean bool56 = false;
      boolean bool57 = false;
      boolean bool58 = false;
      boolean bool59 = false;
      boolean bool60 = false;
      boolean bool61 = false;
      boolean bool62 = false;
      boolean bool63 = false;
      boolean bool64 = false;
      boolean bool65 = false;
      boolean bool66 = true;
      switch (param1Int1) {
        default:
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
        case 1598968902:
          param1Parcel2.writeString("android.app.mia.IMiaMdmPolicyService");
          return bool66;
        case 1:
          param1Parcel1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          shutDown();
          param1Parcel2.writeNoException();
          return bool66;
        case 2:
          param1Parcel1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          if (param1Parcel1.readInt() != 0) {
            null = true;
          } else {
            null = false;
          } 
          null = allowWifi(null);
          param1Parcel2.writeNoException();
          param1Int1 = bool65;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 3:
          param1Parcel1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = isWifiAllowed();
          param1Parcel2.writeNoException();
          param1Int1 = bool1;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 4:
          param1Parcel1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          if (param1Parcel1.readInt() != 0)
            null = true; 
          openWifi(null);
          param1Parcel2.writeNoException();
          return bool66;
        case 5:
          param1Parcel1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = isWifiOpen();
          param1Parcel2.writeNoException();
          param1Int1 = bool2;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 6:
          param1Parcel1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          arrayList2 = param1Parcel1.createStringArrayList();
          setWifiWhiteList(arrayList2);
          param1Parcel2.writeNoException();
          param1Parcel2.writeStringList(arrayList2);
          return bool66;
        case 7:
          arrayList2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          list2 = getWifiWhiteList();
          param1Parcel2.writeNoException();
          param1Parcel2.writeStringList(list2);
          return bool66;
        case 8:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = isWifiControl(list2.readString());
          param1Parcel2.writeNoException();
          param1Int1 = bool3;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 9:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          list2 = list2.createStringArrayList();
          removeWifiWhiteList(list2);
          param1Parcel2.writeNoException();
          param1Parcel2.writeStringList(list2);
          return bool66;
        case 10:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          list2 = list2.createStringArrayList();
          addWifiWhiteList(list2);
          param1Parcel2.writeNoException();
          param1Parcel2.writeStringList(list2);
          return bool66;
        case 11:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          if (list2.readInt() != 0) {
            null = true;
          } else {
            null = false;
          } 
          null = setOnlyCharging(null);
          param1Parcel2.writeNoException();
          param1Int1 = bool4;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 12:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = isUsbOnlyCharging();
          param1Parcel2.writeNoException();
          param1Int1 = bool5;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 13:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = bool6;
          if (list2.readInt() != 0)
            null = true; 
          setAdbEnable(null);
          param1Parcel2.writeNoException();
          return bool66;
        case 14:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = bool7;
          if (list2.readInt() != 0)
            null = true; 
          setUsbSettingShow(null);
          param1Parcel2.writeNoException();
          return bool66;
        case 15:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = bool8;
          if (list2.readInt() != 0)
            null = true; 
          allowBluetooth(null);
          param1Parcel2.writeNoException();
          return bool66;
        case 16:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = isBluetoothAllowed();
          param1Parcel2.writeNoException();
          param1Int1 = bool9;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 17:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          if (list2.readInt() != 0) {
            null = true;
          } else {
            null = false;
          } 
          null = allowBluetoothDataTransfer(null);
          param1Parcel2.writeNoException();
          param1Int1 = bool10;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 18:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = isBluetoothDataTransferAllowed();
          param1Parcel2.writeNoException();
          param1Int1 = bool11;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 19:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          list2 = list2.createStringArrayList();
          setBluetoothPairingWhitelist(list2);
          param1Parcel2.writeNoException();
          param1Parcel2.writeStringList(list2);
          return bool66;
        case 20:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          list2 = getBluetoothPairingWhitelist();
          param1Parcel2.writeNoException();
          param1Parcel2.writeStringList(list2);
          return bool66;
        case 21:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = isBluetoothPairingControl(list2.readString());
          param1Parcel2.writeNoException();
          param1Int1 = bool12;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 22:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          list2 = list2.createStringArrayList();
          removeBluetoothPairingWhitelist(list2);
          param1Parcel2.writeNoException();
          param1Parcel2.writeStringList(list2);
          return bool66;
        case 23:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          list2 = list2.createStringArrayList();
          addBluetoothPairingWhitelist(list2);
          param1Parcel2.writeNoException();
          param1Parcel2.writeStringList(list2);
          return bool66;
        case 24:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = bool13;
          if (list2.readInt() != 0)
            null = true; 
          setCamera(null);
          param1Parcel2.writeNoException();
          return bool66;
        case 25:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = isForbidCamera();
          param1Parcel2.writeNoException();
          param1Int1 = bool14;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 26:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = bool15;
          if (list2.readInt() != 0)
            null = true; 
          allowLocation(null);
          param1Parcel2.writeNoException();
          return bool66;
        case 27:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = isLocationAllowed();
          param1Parcel2.writeNoException();
          param1Int1 = bool16;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 28:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = isLocationServiceForced();
          param1Parcel2.writeNoException();
          param1Int1 = bool17;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 29:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          if (list2.readInt() != 0) {
            null = true;
          } else {
            null = false;
          } 
          null = forceLocationService(null);
          param1Parcel2.writeNoException();
          param1Int1 = bool18;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 30:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = bool19;
          if (list2.readInt() != 0)
            null = true; 
          setTFcard(null);
          param1Parcel2.writeNoException();
          return bool66;
        case 31:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = isForbidTFcard();
          param1Parcel2.writeNoException();
          param1Int1 = bool20;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 32:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = bool21;
          if (list2.readInt() != 0)
            null = true; 
          setScreenCaptureKey(null);
          param1Parcel2.writeNoException();
          return bool66;
        case 33:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = isForbidScreenCaptureKey();
          param1Parcel2.writeNoException();
          param1Int1 = bool22;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 34:
          list2.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          bitmap = getMiaScreen();
          param1Parcel2.writeNoException();
          if (bitmap != null) {
            param1Parcel2.writeInt(1);
            bitmap.writeToParcel(param1Parcel2, 1);
            return bool66;
          } 
          param1Parcel2.writeInt(0);
          return bool66;
        case 35:
          bitmap.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          if (bitmap.readInt() != 0) {
            null = true;
          } else {
            null = false;
          } 
          null = controlClipboard(null);
          param1Parcel2.writeNoException();
          param1Int1 = bool23;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 36:
          bitmap.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = isControlClipboard();
          param1Parcel2.writeNoException();
          param1Int1 = bool24;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 37:
          bitmap.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          if (bitmap.readInt() != 0) {
            null = true;
          } else {
            null = false;
          } 
          null = setCoerciveMute(null);
          param1Parcel2.writeNoException();
          param1Int1 = bool25;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 38:
          bitmap.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = isCoerciveMute();
          param1Parcel2.writeNoException();
          param1Int1 = bool26;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 39:
          bitmap.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          reBoot();
          param1Parcel2.writeNoException();
          return bool66;
        case 40:
          bitmap.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          reset();
          param1Parcel2.writeNoException();
          return bool66;
        case 41:
          bitmap.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = bool27;
          if (bitmap.readInt() != 0)
            null = true; 
          setReset(null);
          param1Parcel2.writeNoException();
          return bool66;
        case 42:
          bitmap.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = bool28;
          if (bitmap.readInt() != 0)
            null = true; 
          setInstallNonMarketApp(null);
          param1Parcel2.writeNoException();
          return bool66;
        case 43:
          bitmap.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = isInstallNonMarketAppOpen();
          param1Parcel2.writeNoException();
          param1Int1 = bool29;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 44:
          bitmap.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = bool30;
          if (bitmap.readInt() != 0)
            null = true; 
          setSafeMode(null);
          param1Parcel2.writeNoException();
          return bool66;
        case 45:
          bitmap.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = isSafeModeAllowed();
          param1Parcel2.writeNoException();
          param1Int1 = bool31;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 46:
          bitmap.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          arrayList1 = bitmap.createStringArrayList();
          setInstallPackages(arrayList1);
          param1Parcel2.writeNoException();
          param1Parcel2.writeStringList(arrayList1);
          return bool66;
        case 47:
          arrayList1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          list1 = getInstallPackageWhiteList();
          param1Parcel2.writeNoException();
          param1Parcel2.writeStringList(list1);
          return bool66;
        case 48:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = isInstallControl(list1.readString());
          param1Parcel2.writeNoException();
          param1Int1 = bool32;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 49:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          list1 = list1.createStringArrayList();
          removeInstallPackages(list1);
          param1Parcel2.writeNoException();
          param1Parcel2.writeStringList(list1);
          return bool66;
        case 50:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          list1 = list1.createStringArrayList();
          addInstallPackages(list1);
          param1Parcel2.writeNoException();
          param1Parcel2.writeStringList(list1);
          return bool66;
        case 51:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          list1 = list1.createStringArrayList();
          setDisallowedUninstallPackages(list1);
          param1Parcel2.writeNoException();
          param1Parcel2.writeStringList(list1);
          return bool66;
        case 52:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          list1 = getDisallowedUninstallPackageList();
          param1Parcel2.writeNoException();
          param1Parcel2.writeStringList(list1);
          return bool66;
        case 53:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = isUninstallControl(list1.readString());
          param1Parcel2.writeNoException();
          param1Int1 = bool33;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 54:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          list1 = list1.createStringArrayList();
          removeDisallowedUninstallPackages(list1);
          param1Parcel2.writeNoException();
          param1Parcel2.writeStringList(list1);
          return bool66;
        case 55:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          list1 = list1.createStringArrayList();
          addDisallowedUninstallPackages(list1);
          param1Parcel2.writeNoException();
          param1Parcel2.writeStringList(list1);
          return bool66;
        case 56:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = bool34;
          if (list1.readInt() != 0)
            null = true; 
          setInstall(null);
          param1Parcel2.writeNoException();
          return bool66;
        case 57:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = bool35;
          if (list1.readInt() != 0)
            null = true; 
          setUninstall(null);
          param1Parcel2.writeNoException();
          return bool66;
        case 58:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          silentUnInstall(list1.readString());
          param1Parcel2.writeNoException();
          return bool66;
        case 59:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          silentInstall(list1.readString());
          param1Parcel2.writeNoException();
          return bool66;
        case 60:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = bool36;
          if (list1.readInt() != 0)
            null = true; 
          setBackKey(null);
          param1Parcel2.writeNoException();
          return bool66;
        case 61:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = bool37;
          if (list1.readInt() != 0)
            null = true; 
          setHomeKey(null);
          param1Parcel2.writeNoException();
          return bool66;
        case 62:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = bool38;
          if (list1.readInt() != 0)
            null = true; 
          setRecentKey(null);
          param1Parcel2.writeNoException();
          return bool66;
        case 63:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = bool39;
          if (list1.readInt() != 0)
            null = true; 
          setNavigaBar(null);
          param1Parcel2.writeNoException();
          return bool66;
        case 64:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = isControlBackKey();
          param1Parcel2.writeNoException();
          param1Int1 = bool40;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 65:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = isControlHomeKey();
          param1Parcel2.writeNoException();
          param1Int1 = bool41;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 66:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = isControlRecentsKey();
          param1Parcel2.writeNoException();
          param1Int1 = bool42;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 67:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = isControlmiaNavigaView();
          param1Parcel2.writeNoException();
          param1Int1 = bool43;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 68:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = bool44;
          if (list1.readInt() != 0)
            null = true; 
          setStatusBar(null);
          param1Parcel2.writeNoException();
          return bool66;
        case 69:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = isControlStatus();
          param1Parcel2.writeNoException();
          param1Int1 = bool45;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 70:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = bool46;
          if (list1.readInt() != 0)
            null = true; 
          setFullScreen(null);
          param1Parcel2.writeNoException();
          return bool66;
        case 71:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = bool47;
          if (list1.readInt() != 0)
            null = true; 
          allowNotification(null);
          param1Parcel2.writeNoException();
          return bool66;
        case 72:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = isNotificationAllowed();
          param1Parcel2.writeNoException();
          param1Int1 = bool48;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 73:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          list1 = list1.createStringArrayList();
          setNotificationList(list1);
          param1Parcel2.writeNoException();
          param1Parcel2.writeStringList(list1);
          return bool66;
        case 74:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          list1 = getNotificationList();
          param1Parcel2.writeNoException();
          param1Parcel2.writeStringList(list1);
          return bool66;
        case 75:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = isNotificationList(list1.readString());
          param1Parcel2.writeNoException();
          param1Int1 = bool49;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 76:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          list1 = list1.createStringArrayList();
          removeNotificationList(list1);
          param1Parcel2.writeNoException();
          param1Parcel2.writeStringList(list1);
          return bool66;
        case 77:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          list1 = list1.createStringArrayList();
          addNotificationList(list1);
          param1Parcel2.writeNoException();
          param1Parcel2.writeStringList(list1);
          return bool66;
        case 78:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = setCustomLauncher(list1.readString());
          param1Parcel2.writeNoException();
          param1Int1 = bool50;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 79:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = clearCustomLauncher();
          param1Parcel2.writeNoException();
          param1Int1 = bool51;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 80:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          str2 = list1.readString();
          null = bool52;
          if (list1.readInt() != 0)
            null = true; 
          controlApp(str2, null);
          param1Parcel2.writeNoException();
          return bool66;
        case 81:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = setLockPassword(list1.readString());
          param1Parcel2.writeNoException();
          param1Int1 = bool53;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 82:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = unlockScreen();
          param1Parcel2.writeNoException();
          param1Int1 = bool54;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 83:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          if (list1.readInt() != 0) {
            null = true;
          } else {
            null = false;
          } 
          null = restoreSlideLock(null);
          param1Parcel2.writeNoException();
          param1Int1 = bool55;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 84:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          list1 = urlWhiteListRead();
          param1Parcel2.writeNoException();
          param1Parcel2.writeStringList(list1);
          return bool66;
        case 85:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          list1 = urlBlackListRead();
          param1Parcel2.writeNoException();
          param1Parcel2.writeStringList(list1);
          return bool66;
        case 86:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = urlWhiteListWrite(list1.createStringArrayList());
          param1Parcel2.writeNoException();
          param1Int1 = bool56;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 87:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = urlBlackListWrite(list1.createStringArrayList());
          param1Parcel2.writeNoException();
          param1Int1 = bool57;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 88:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          list1 = APPIPWhiteListRead();
          param1Parcel2.writeNoException();
          param1Parcel2.writeStringList(list1);
          return bool66;
        case 89:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          list1 = APPIPBlackListRead();
          param1Parcel2.writeNoException();
          param1Parcel2.writeStringList(list1);
          return bool66;
        case 90:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = AddAppWhiteRule(list1.readString());
          param1Parcel2.writeNoException();
          param1Int1 = bool58;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 91:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = AddAppBlackRule(list1.readString());
          param1Parcel2.writeNoException();
          param1Int1 = bool59;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 92:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          if (list1.readInt() != 0) {
            null = true;
          } else {
            null = false;
          } 
          null = SetEnable(null);
          param1Parcel2.writeNoException();
          param1Int1 = bool60;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 93:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = ClearAppRules();
          param1Parcel2.writeNoException();
          param1Int1 = bool61;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 94:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = ClearURLListRules();
          param1Parcel2.writeNoException();
          param1Int1 = bool62;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 95:
          list1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          str1 = getBtStatus();
          param1Parcel2.writeNoException();
          param1Parcel2.writeString(str1);
          return bool66;
        case 96:
          str1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          str1 = getWifiStatus();
          param1Parcel2.writeNoException();
          param1Parcel2.writeString(str1);
          return bool66;
        case 97:
          str1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          if (str1.readInt() != 0) {
            null = true;
          } else {
            null = false;
          } 
          null = setGps(null);
          param1Parcel2.writeNoException();
          param1Int1 = bool63;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 98:
          str1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          masterClearInbulitSD();
          param1Parcel2.writeNoException();
          return bool66;
        case 99:
          str1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          null = updateSystemTime(str1.readString());
          param1Parcel2.writeNoException();
          param1Int1 = bool64;
          if (null)
            param1Int1 = 1; 
          param1Parcel2.writeInt(param1Int1);
          return bool66;
        case 100:
          str1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          MiaSystemSetting(str1.readString(), str1.readInt());
          param1Parcel2.writeNoException();
          return bool66;
        case 101:
          str1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          canDrawOveylays(str1.readString());
          param1Parcel2.writeNoException();
          return bool66;
        case 102:
          str1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
          killApplicationProcess(str1.readString());
          param1Parcel2.writeNoException();
          return bool66;
        case 103:
          break;
      } 
      str1.enforceInterface("android.app.mia.IMiaMdmPolicyService");
      wirteIPV6();
      param1Parcel2.writeNoException();
      return bool66;
    }
    
    private static class Proxy implements IMiaMdmPolicyService {
      private IBinder mRemote;
      
      Proxy(IBinder param2IBinder) {
        this.mRemote = param2IBinder;
      }
      
      public List<String> APPIPBlackListRead() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(89, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.createStringArrayList();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public List<String> APPIPWhiteListRead() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(88, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.createStringArrayList();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean AddAppBlackRule(String param2String) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeString(param2String);
          this.mRemote.transact(91, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean AddAppWhiteRule(String param2String) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeString(param2String);
          this.mRemote.transact(90, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean ClearAppRules() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(93, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean ClearURLListRules() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(94, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void MiaSystemSetting(String param2String, int param2Int) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeString(param2String);
          parcel1.writeInt(param2Int);
          this.mRemote.transact(100, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean SetEnable(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          this.mRemote.transact(92, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
            return param2Boolean;
          } 
          param2Boolean = false;
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void addBluetoothPairingWhitelist(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeStringList(param2List);
          this.mRemote.transact(23, parcel1, parcel2, 0);
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void addDisallowedUninstallPackages(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeStringList(param2List);
          this.mRemote.transact(55, parcel1, parcel2, 0);
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void addInstallPackages(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeStringList(param2List);
          this.mRemote.transact(50, parcel1, parcel2, 0);
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void addNotificationList(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeStringList(param2List);
          this.mRemote.transact(77, parcel1, parcel2, 0);
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void addWifiWhiteList(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeStringList(param2List);
          this.mRemote.transact(10, parcel1, parcel2, 0);
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void allowBluetooth(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          this.mRemote.transact(15, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean allowBluetoothDataTransfer(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          this.mRemote.transact(17, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
            return param2Boolean;
          } 
          param2Boolean = false;
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void allowLocation(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          this.mRemote.transact(26, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void allowNotification(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          this.mRemote.transact(71, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean allowWifi(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          this.mRemote.transact(2, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
            return param2Boolean;
          } 
          param2Boolean = false;
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public IBinder asBinder() {
        return this.mRemote;
      }
      
      public void canDrawOveylays(String param2String) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeString(param2String);
          this.mRemote.transact(101, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean clearCustomLauncher() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(79, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void controlApp(String param2String, boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeString(param2String);
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          this.mRemote.transact(80, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean controlClipboard(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          this.mRemote.transact(35, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
            return param2Boolean;
          } 
          param2Boolean = false;
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean forceLocationService(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          this.mRemote.transact(29, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
            return param2Boolean;
          } 
          param2Boolean = false;
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public List<String> getBluetoothPairingWhitelist() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(20, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.createStringArrayList();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public String getBtStatus() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(95, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readString();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public List<String> getDisallowedUninstallPackageList() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(52, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.createStringArrayList();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public List<String> getInstallPackageWhiteList() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(47, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.createStringArrayList();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public String getInterfaceDescriptor() {
        return "android.app.mia.IMiaMdmPolicyService";
      }
      
      public Bitmap getMiaScreen() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(34, parcel1, parcel2, 0);
          parcel2.readException();
          if (parcel2.readInt() != 0)
            return (Bitmap)Bitmap.CREATOR.createFromParcel(parcel2); 
          return null;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public List<String> getNotificationList() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(74, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.createStringArrayList();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public String getWifiStatus() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(96, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readString();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public List<String> getWifiWhiteList() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(7, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.createStringArrayList();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isBluetoothAllowed() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(16, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isBluetoothDataTransferAllowed() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(18, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isBluetoothPairingControl(String param2String) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeString(param2String);
          this.mRemote.transact(21, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isCoerciveMute() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(38, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isControlBackKey() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(64, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isControlClipboard() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(36, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isControlHomeKey() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(65, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isControlRecentsKey() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(66, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isControlStatus() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(69, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isControlmiaNavigaView() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(67, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isForbidCamera() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(25, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isForbidScreenCaptureKey() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(33, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isForbidTFcard() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(31, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isInstallControl(String param2String) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeString(param2String);
          this.mRemote.transact(48, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isInstallNonMarketAppOpen() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(43, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isLocationAllowed() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(27, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isLocationServiceForced() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(28, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isNotificationAllowed() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(72, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isNotificationList(String param2String) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeString(param2String);
          this.mRemote.transact(75, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isSafeModeAllowed() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(45, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isUninstallControl(String param2String) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeString(param2String);
          this.mRemote.transact(53, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isUsbOnlyCharging() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(12, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isWifiAllowed() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(3, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isWifiControl(String param2String) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeString(param2String);
          this.mRemote.transact(8, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isWifiOpen() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(5, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void killApplicationProcess(String param2String) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeString(param2String);
          this.mRemote.transact(102, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void masterClearInbulitSD() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(98, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void openWifi(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          this.mRemote.transact(4, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void reBoot() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(39, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void removeBluetoothPairingWhitelist(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeStringList(param2List);
          this.mRemote.transact(22, parcel1, parcel2, 0);
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void removeDisallowedUninstallPackages(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeStringList(param2List);
          this.mRemote.transact(54, parcel1, parcel2, 0);
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void removeInstallPackages(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeStringList(param2List);
          this.mRemote.transact(49, parcel1, parcel2, 0);
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void removeNotificationList(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeStringList(param2List);
          this.mRemote.transact(76, parcel1, parcel2, 0);
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void removeWifiWhiteList(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeStringList(param2List);
          this.mRemote.transact(9, parcel1, parcel2, 0);
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void reset() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(40, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean restoreSlideLock(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          this.mRemote.transact(83, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
            return param2Boolean;
          } 
          param2Boolean = false;
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setAdbEnable(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          this.mRemote.transact(13, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setBackKey(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          this.mRemote.transact(60, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setBluetoothPairingWhitelist(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeStringList(param2List);
          this.mRemote.transact(19, parcel1, parcel2, 0);
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setCamera(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          this.mRemote.transact(24, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean setCoerciveMute(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          this.mRemote.transact(37, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
            return param2Boolean;
          } 
          param2Boolean = false;
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean setCustomLauncher(String param2String) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeString(param2String);
          this.mRemote.transact(78, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setDisallowedUninstallPackages(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeStringList(param2List);
          this.mRemote.transact(51, parcel1, parcel2, 0);
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setFullScreen(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          this.mRemote.transact(70, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean setGps(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          this.mRemote.transact(97, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
            return param2Boolean;
          } 
          param2Boolean = false;
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setHomeKey(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          this.mRemote.transact(61, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setInstall(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          this.mRemote.transact(56, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setInstallNonMarketApp(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          this.mRemote.transact(42, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setInstallPackages(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeStringList(param2List);
          this.mRemote.transact(46, parcel1, parcel2, 0);
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean setLockPassword(String param2String) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeString(param2String);
          this.mRemote.transact(81, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setNavigaBar(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          this.mRemote.transact(63, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setNotificationList(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeStringList(param2List);
          this.mRemote.transact(73, parcel1, parcel2, 0);
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean setOnlyCharging(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          this.mRemote.transact(11, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
            return param2Boolean;
          } 
          param2Boolean = false;
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setRecentKey(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          this.mRemote.transact(62, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setReset(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          this.mRemote.transact(41, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setSafeMode(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          this.mRemote.transact(44, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setScreenCaptureKey(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          this.mRemote.transact(32, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setStatusBar(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          this.mRemote.transact(68, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setTFcard(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          this.mRemote.transact(30, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setUninstall(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          this.mRemote.transact(57, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setUsbSettingShow(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          this.mRemote.transact(14, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setWifiWhiteList(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeStringList(param2List);
          this.mRemote.transact(6, parcel1, parcel2, 0);
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void shutDown() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(1, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void silentInstall(String param2String) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeString(param2String);
          this.mRemote.transact(59, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void silentUnInstall(String param2String) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeString(param2String);
          this.mRemote.transact(58, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean unlockScreen() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(82, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean updateSystemTime(String param2String) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeString(param2String);
          this.mRemote.transact(99, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public List<String> urlBlackListRead() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(85, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.createStringArrayList();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean urlBlackListWrite(List<String> param2List) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeStringList(param2List);
          this.mRemote.transact(87, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public List<String> urlWhiteListRead() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(84, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.createStringArrayList();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean urlWhiteListWrite(List<String> param2List) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          parcel1.writeStringList(param2List);
          this.mRemote.transact(86, parcel1, parcel2, 0);
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void wirteIPV6() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
          this.mRemote.transact(103, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
    }
  }
  
  private static class Proxy implements IMiaMdmPolicyService {
    private IBinder mRemote;
    
    Proxy(IBinder param1IBinder) {
      this.mRemote = param1IBinder;
    }
    
    public List<String> APPIPBlackListRead() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(89, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.createStringArrayList();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public List<String> APPIPWhiteListRead() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(88, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.createStringArrayList();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean AddAppBlackRule(String param1String) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeString(param1String);
        this.mRemote.transact(91, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean AddAppWhiteRule(String param1String) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeString(param1String);
        this.mRemote.transact(90, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean ClearAppRules() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(93, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean ClearURLListRules() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(94, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void MiaSystemSetting(String param1String, int param1Int) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeString(param1String);
        parcel1.writeInt(param1Int);
        this.mRemote.transact(100, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean SetEnable(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        this.mRemote.transact(92, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
          return param1Boolean;
        } 
        param1Boolean = false;
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void addBluetoothPairingWhitelist(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeStringList(param1List);
        this.mRemote.transact(23, parcel1, parcel2, 0);
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void addDisallowedUninstallPackages(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeStringList(param1List);
        this.mRemote.transact(55, parcel1, parcel2, 0);
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void addInstallPackages(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeStringList(param1List);
        this.mRemote.transact(50, parcel1, parcel2, 0);
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void addNotificationList(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeStringList(param1List);
        this.mRemote.transact(77, parcel1, parcel2, 0);
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void addWifiWhiteList(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeStringList(param1List);
        this.mRemote.transact(10, parcel1, parcel2, 0);
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void allowBluetooth(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        this.mRemote.transact(15, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean allowBluetoothDataTransfer(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        this.mRemote.transact(17, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
          return param1Boolean;
        } 
        param1Boolean = false;
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void allowLocation(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        this.mRemote.transact(26, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void allowNotification(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        this.mRemote.transact(71, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean allowWifi(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        this.mRemote.transact(2, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
          return param1Boolean;
        } 
        param1Boolean = false;
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public IBinder asBinder() {
      return this.mRemote;
    }
    
    public void canDrawOveylays(String param1String) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeString(param1String);
        this.mRemote.transact(101, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean clearCustomLauncher() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(79, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void controlApp(String param1String, boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeString(param1String);
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        this.mRemote.transact(80, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean controlClipboard(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        this.mRemote.transact(35, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
          return param1Boolean;
        } 
        param1Boolean = false;
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean forceLocationService(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        this.mRemote.transact(29, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
          return param1Boolean;
        } 
        param1Boolean = false;
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public List<String> getBluetoothPairingWhitelist() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(20, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.createStringArrayList();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public String getBtStatus() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(95, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readString();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public List<String> getDisallowedUninstallPackageList() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(52, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.createStringArrayList();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public List<String> getInstallPackageWhiteList() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(47, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.createStringArrayList();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public String getInterfaceDescriptor() {
      return "android.app.mia.IMiaMdmPolicyService";
    }
    
    public Bitmap getMiaScreen() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(34, parcel1, parcel2, 0);
        parcel2.readException();
        if (parcel2.readInt() != 0)
          return (Bitmap)Bitmap.CREATOR.createFromParcel(parcel2); 
        return null;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public List<String> getNotificationList() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(74, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.createStringArrayList();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public String getWifiStatus() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(96, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readString();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public List<String> getWifiWhiteList() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(7, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.createStringArrayList();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isBluetoothAllowed() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(16, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isBluetoothDataTransferAllowed() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(18, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isBluetoothPairingControl(String param1String) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeString(param1String);
        this.mRemote.transact(21, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isCoerciveMute() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(38, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isControlBackKey() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(64, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isControlClipboard() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(36, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isControlHomeKey() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(65, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isControlRecentsKey() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(66, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isControlStatus() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(69, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isControlmiaNavigaView() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(67, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isForbidCamera() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(25, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isForbidScreenCaptureKey() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(33, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isForbidTFcard() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(31, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isInstallControl(String param1String) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeString(param1String);
        this.mRemote.transact(48, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isInstallNonMarketAppOpen() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(43, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isLocationAllowed() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(27, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isLocationServiceForced() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(28, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isNotificationAllowed() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(72, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isNotificationList(String param1String) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeString(param1String);
        this.mRemote.transact(75, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isSafeModeAllowed() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(45, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isUninstallControl(String param1String) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeString(param1String);
        this.mRemote.transact(53, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isUsbOnlyCharging() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(12, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isWifiAllowed() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(3, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isWifiControl(String param1String) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeString(param1String);
        this.mRemote.transact(8, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isWifiOpen() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(5, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void killApplicationProcess(String param1String) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeString(param1String);
        this.mRemote.transact(102, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void masterClearInbulitSD() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(98, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void openWifi(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        this.mRemote.transact(4, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void reBoot() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(39, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void removeBluetoothPairingWhitelist(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeStringList(param1List);
        this.mRemote.transact(22, parcel1, parcel2, 0);
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void removeDisallowedUninstallPackages(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeStringList(param1List);
        this.mRemote.transact(54, parcel1, parcel2, 0);
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void removeInstallPackages(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeStringList(param1List);
        this.mRemote.transact(49, parcel1, parcel2, 0);
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void removeNotificationList(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeStringList(param1List);
        this.mRemote.transact(76, parcel1, parcel2, 0);
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void removeWifiWhiteList(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeStringList(param1List);
        this.mRemote.transact(9, parcel1, parcel2, 0);
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void reset() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(40, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean restoreSlideLock(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        this.mRemote.transact(83, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
          return param1Boolean;
        } 
        param1Boolean = false;
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setAdbEnable(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        this.mRemote.transact(13, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setBackKey(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        this.mRemote.transact(60, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setBluetoothPairingWhitelist(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeStringList(param1List);
        this.mRemote.transact(19, parcel1, parcel2, 0);
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setCamera(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        this.mRemote.transact(24, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean setCoerciveMute(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        this.mRemote.transact(37, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
          return param1Boolean;
        } 
        param1Boolean = false;
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean setCustomLauncher(String param1String) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeString(param1String);
        this.mRemote.transact(78, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setDisallowedUninstallPackages(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeStringList(param1List);
        this.mRemote.transact(51, parcel1, parcel2, 0);
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setFullScreen(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        this.mRemote.transact(70, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean setGps(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        this.mRemote.transact(97, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
          return param1Boolean;
        } 
        param1Boolean = false;
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setHomeKey(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        this.mRemote.transact(61, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setInstall(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        this.mRemote.transact(56, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setInstallNonMarketApp(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        this.mRemote.transact(42, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setInstallPackages(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeStringList(param1List);
        this.mRemote.transact(46, parcel1, parcel2, 0);
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean setLockPassword(String param1String) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeString(param1String);
        this.mRemote.transact(81, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setNavigaBar(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        this.mRemote.transact(63, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setNotificationList(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeStringList(param1List);
        this.mRemote.transact(73, parcel1, parcel2, 0);
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean setOnlyCharging(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        this.mRemote.transact(11, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
          return param1Boolean;
        } 
        param1Boolean = false;
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setRecentKey(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        this.mRemote.transact(62, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setReset(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        this.mRemote.transact(41, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setSafeMode(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        this.mRemote.transact(44, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setScreenCaptureKey(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        this.mRemote.transact(32, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setStatusBar(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        this.mRemote.transact(68, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setTFcard(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        this.mRemote.transact(30, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setUninstall(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        this.mRemote.transact(57, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setUsbSettingShow(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        this.mRemote.transact(14, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setWifiWhiteList(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeStringList(param1List);
        this.mRemote.transact(6, parcel1, parcel2, 0);
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void shutDown() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(1, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void silentInstall(String param1String) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeString(param1String);
        this.mRemote.transact(59, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void silentUnInstall(String param1String) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeString(param1String);
        this.mRemote.transact(58, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean unlockScreen() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(82, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean updateSystemTime(String param1String) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeString(param1String);
        this.mRemote.transact(99, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public List<String> urlBlackListRead() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(85, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.createStringArrayList();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean urlBlackListWrite(List<String> param1List) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeStringList(param1List);
        this.mRemote.transact(87, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public List<String> urlWhiteListRead() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(84, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.createStringArrayList();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean urlWhiteListWrite(List<String> param1List) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        parcel1.writeStringList(param1List);
        this.mRemote.transact(86, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void wirteIPV6() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.mia.IMiaMdmPolicyService");
        this.mRemote.transact(103, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
}


/* Location:              C:\Users\Tonyha7\Desktop\huovink_-mdm_catch_for_-lenovo-master\lspirer\lspirer\master-new\app\libs\Lenovo_Frameworks.jar!\android\app\mia\IMiaMdmPolicyService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */