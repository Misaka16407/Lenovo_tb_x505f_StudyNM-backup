package android.app.csdk;

import android.content.ComponentName;
import android.graphics.Bitmap;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import java.util.ArrayList;
import java.util.List;

public interface ICSDKManagerService extends IInterface {
  List<String> APPIPWhiteListRead() throws RemoteException;
  
  boolean AddAppBlackRule(String paramString) throws RemoteException;
  
  boolean AddAppWhiteRule(String paramString) throws RemoteException;
  
  boolean ClearAppRules() throws RemoteException;
  
  boolean ClearIpHostRules() throws RemoteException;
  
  boolean ClearRules() throws RemoteException;
  
  boolean SetEnable(boolean paramBoolean) throws RemoteException;
  
  boolean WriteToFile() throws RemoteException;
  
  boolean aCLK(String paramString1, String paramString2, String paramString3) throws RemoteException;
  
  void activateLicense(String paramString1, String paramString2, String paramString3) throws RemoteException;
  
  void addAppManageBlackList_v3(List<String> paramList) throws RemoteException;
  
  void addAppManageWhiteList_v3(List<String> paramList) throws RemoteException;
  
  void addAutostartPackageBlackList(List<String> paramList) throws RemoteException;
  
  void addInstallPackageBlackList(List<String> paramList) throws RemoteException;
  
  void addInstallPackageWhiteList(List<String> paramList) throws RemoteException;
  
  void addNetworkAccessBlacklist(List<String> paramList) throws RemoteException;
  
  void addNetworkAccessWhitelist(List<String> paramList) throws RemoteException;
  
  boolean addSSID(String paramString1, String paramString2, int paramInt, boolean paramBoolean) throws RemoteException;
  
  void addUninstallPackageBlackList(List<String> paramList) throws RemoteException;
  
  void addUninstallPackageWhiteList(List<String> paramList) throws RemoteException;
  
  void allowBluetooth(boolean paramBoolean) throws RemoteException;
  
  boolean allowBluetoothDataTransfer(boolean paramBoolean) throws RemoteException;
  
  void allowCamera(boolean paramBoolean) throws RemoteException;
  
  void allowNavigaBar(boolean paramBoolean) throws RemoteException;
  
  void allowPowerKey(boolean paramBoolean) throws RemoteException;
  
  void allowTFcard(boolean paramBoolean) throws RemoteException;
  
  void allowVolumeKey(boolean paramBoolean) throws RemoteException;
  
  boolean appWhiteListWrite(List<String> paramList) throws RemoteException;
  
  Bitmap captureScreen() throws RemoteException;
  
  void controlApp(String paramString, boolean paramBoolean) throws RemoteException;
  
  boolean deactivateLicense(String paramString1, String paramString2, String paramString3) throws RemoteException;
  
  void disableApplicationManage_v3(boolean paramBoolean) throws RemoteException;
  
  void disableAutostart(boolean paramBoolean) throws RemoteException;
  
  boolean disableBluetooth(boolean paramBoolean) throws RemoteException;
  
  void disableBluetoothShare(boolean paramBoolean) throws RemoteException;
  
  boolean disableCamera(boolean paramBoolean) throws RemoteException;
  
  void disableFactoryReset(boolean paramBoolean) throws RemoteException;
  
  boolean disableHiddenGame(boolean paramBoolean) throws RemoteException;
  
  void disableInstallation(boolean paramBoolean) throws RemoteException;
  
  boolean disableLocation(boolean paramBoolean) throws RemoteException;
  
  boolean disableLockScreenNotification(boolean paramBoolean) throws RemoteException;
  
  void disableMultiUser(boolean paramBoolean) throws RemoteException;
  
  void disableStatusBarNotification(boolean paramBoolean) throws RemoteException;
  
  boolean disableStatusBarPanel(boolean paramBoolean) throws RemoteException;
  
  void disableTabletMasterAutostart(boolean paramBoolean) throws RemoteException;
  
  void disableUnInstallation(boolean paramBoolean) throws RemoteException;
  
  boolean disableWifi(boolean paramBoolean) throws RemoteException;
  
  boolean disableWifiDirect(boolean paramBoolean) throws RemoteException;
  
  boolean disallowAPN_v3(boolean paramBoolean) throws RemoteException;
  
  boolean disallowAirplaneMode_v3(boolean paramBoolean) throws RemoteException;
  
  void disallowAutoDateAndTime_V3(boolean paramBoolean) throws RemoteException;
  
  boolean disallowBluetoothShare_v3(boolean paramBoolean) throws RemoteException;
  
  boolean disallowBluetooth_v3(boolean paramBoolean) throws RemoteException;
  
  boolean disallowData_v3(boolean paramBoolean) throws RemoteException;
  
  void disallowFactoryReset_v3(boolean paramBoolean) throws RemoteException;
  
  boolean disallowLocation_v3(boolean paramBoolean) throws RemoteException;
  
  boolean disallowLockScreenMode_v3(boolean paramBoolean) throws RemoteException;
  
  void disallowLockScreenNotification_v3(boolean paramBoolean) throws RemoteException;
  
  void disallowMultiUser_v3(boolean paramBoolean) throws RemoteException;
  
  boolean disallowSIMcard_v3(boolean paramBoolean) throws RemoteException;
  
  void disallowSetAlarmVolume_v3(boolean paramBoolean) throws RemoteException;
  
  void disallowSetBootTime_V3(boolean paramBoolean) throws RemoteException;
  
  void disallowSetBrightness_v3(boolean paramBoolean) throws RemoteException;
  
  void disallowSetInputMethod_v3(String paramString, boolean paramBoolean) throws RemoteException;
  
  void disallowSetMediaVolume_v3(boolean paramBoolean) throws RemoteException;
  
  void disallowSetNotificationVolume_v3(boolean paramBoolean) throws RemoteException;
  
  void disallowSetShutDownTime_V3(boolean paramBoolean) throws RemoteException;
  
  void disallowSetSleepTimeout_V3(boolean paramBoolean) throws RemoteException;
  
  void disallowSetSysDate_v3(boolean paramBoolean) throws RemoteException;
  
  void disallowSetSysTimeZone_v3(boolean paramBoolean) throws RemoteException;
  
  void disallowSetSysTime_v3(boolean paramBoolean) throws RemoteException;
  
  void disallowSwitchLauncher_v3(boolean paramBoolean) throws RemoteException;
  
  boolean disallowUsbDebugging_v3(boolean paramBoolean) throws RemoteException;
  
  boolean disallowUsbMode_v3(boolean paramBoolean) throws RemoteException;
  
  boolean disallowWIFIAccessPoint_v3(boolean paramBoolean) throws RemoteException;
  
  boolean disallowWifiDirect_v3(boolean paramBoolean) throws RemoteException;
  
  boolean disallowWifiHotspot_v3(boolean paramBoolean) throws RemoteException;
  
  boolean disallowWifi_v3(boolean paramBoolean) throws RemoteException;
  
  boolean disallowWifiadvancesettings_v3(boolean paramBoolean) throws RemoteException;
  
  boolean disallowedBluetoothtethering_v3(boolean paramBoolean) throws RemoteException;
  
  boolean disallowedUSBtethering_v3(boolean paramBoolean) throws RemoteException;
  
  void enableAirplaneMode(boolean paramBoolean) throws RemoteException;
  
  void enableAllUnkownsources_v3(boolean paramBoolean) throws RemoteException;
  
  boolean enableAutoBrightness(boolean paramBoolean) throws RemoteException;
  
  boolean enableBluetooth_v3(boolean paramBoolean) throws RemoteException;
  
  boolean enableBluetoothtethering_v3(boolean paramBoolean) throws RemoteException;
  
  void enableCaptureScreen_v3(boolean paramBoolean) throws RemoteException;
  
  boolean enableData(boolean paramBoolean) throws RemoteException;
  
  boolean enableData_v3(boolean paramBoolean) throws RemoteException;
  
  boolean enableDevMode(boolean paramBoolean) throws RemoteException;
  
  void enableDevMode_v3(boolean paramBoolean) throws RemoteException;
  
  boolean enableLocation_v3(boolean paramBoolean) throws RemoteException;
  
  boolean enableMassStorage(boolean paramBoolean) throws RemoteException;
  
  void enableNetworkAccess(boolean paramBoolean) throws RemoteException;
  
  boolean enableSIM(boolean paramBoolean) throws RemoteException;
  
  void enableSearch_v3(boolean paramBoolean) throws RemoteException;
  
  boolean enableSystemAutoUpdate(boolean paramBoolean) throws RemoteException;
  
  boolean enableUSBtethering_v3(boolean paramBoolean) throws RemoteException;
  
  void enableUnkownsources_v3(String paramString, boolean paramBoolean) throws RemoteException;
  
  boolean enableUsbDebugging(boolean paramBoolean) throws RemoteException;
  
  boolean enableWIFIcaptive_v3(boolean paramBoolean) throws RemoteException;
  
  boolean enableWifiHotspot_v3(boolean paramBoolean) throws RemoteException;
  
  boolean enableWifi_v3(boolean paramBoolean) throws RemoteException;
  
  List<String> forceStopPackageWhiteListRead() throws RemoteException;
  
  boolean forceStopPackageWhiteListWrite(List<String> paramList) throws RemoteException;
  
  void fullScreenForever(boolean paramBoolean) throws RemoteException;
  
  List<String> getAppBlackRules() throws RemoteException;
  
  List<String> getAppManageBlackList_v3() throws RemoteException;
  
  List<String> getAppManageWhiteList_v3() throws RemoteException;
  
  List<String> getAutostartPackageBlackList() throws RemoteException;
  
  String getBtStatus() throws RemoteException;
  
  boolean getCustomCHARGE() throws RemoteException;
  
  boolean getCustomFASTBOOT() throws RemoteException;
  
  boolean getCustomHARDRST() throws RemoteException;
  
  boolean getCustomOTG() throws RemoteException;
  
  boolean getCustomRecovery_v3() throws RemoteException;
  
  boolean getCustomSDUPDATE() throws RemoteException;
  
  boolean getCustomSplashPath() throws RemoteException;
  
  String getDeviceInfo(int paramInt) throws RemoteException;
  
  List<String> getDisplayBlacklist_v3() throws RemoteException;
  
  List<String> getInstallPackageBlackList() throws RemoteException;
  
  List<String> getInstallPackageWhiteList() throws RemoteException;
  
  Bitmap getMiaScreen() throws RemoteException;
  
  List<String> getNetworkAccessBlacklist() throws RemoteException;
  
  List<String> getNetworkAccessWhitelist() throws RemoteException;
  
  List<String> getUninstallPackageBlackList() throws RemoteException;
  
  List<String> getUninstallPackageWhiteList() throws RemoteException;
  
  String getWifiStatus() throws RemoteException;
  
  boolean hideBackSoftKey(boolean paramBoolean) throws RemoteException;
  
  boolean hideHomeSoftKey(boolean paramBoolean) throws RemoteException;
  
  boolean hideMenuSoftKey(boolean paramBoolean) throws RemoteException;
  
  void hideNavigationBar(boolean paramBoolean) throws RemoteException;
  
  boolean hideStatusBar(boolean paramBoolean) throws RemoteException;
  
  boolean hideUsbMenu(boolean paramBoolean) throws RemoteException;
  
  void installPackage(String paramString) throws RemoteException;
  
  boolean isBackKeyAllowed() throws RemoteException;
  
  boolean isBluetoothAllowed() throws RemoteException;
  
  boolean isBluetoothDataTransferAllowed() throws RemoteException;
  
  boolean isCameraAllowed() throws RemoteException;
  
  boolean isEnable() throws RemoteException;
  
  boolean isHomeKeyAllowed() throws RemoteException;
  
  boolean isLicenseKeyEnabled(String paramString) throws RemoteException;
  
  boolean isLocationAllowed() throws RemoteException;
  
  boolean isNavigaBarAllowed() throws RemoteException;
  
  boolean isNetworkRulesEnabled() throws RemoteException;
  
  boolean isPowerKeyAllowed() throws RemoteException;
  
  boolean isRecentKeyAllowed() throws RemoteException;
  
  boolean isTFcardAllowed() throws RemoteException;
  
  boolean isUsbOnlyCharging() throws RemoteException;
  
  boolean isVolumeKeyAllowed() throws RemoteException;
  
  boolean killApp(String paramString) throws RemoteException;
  
  void killApplicationProcess(String paramString) throws RemoteException;
  
  boolean launchFactoryReset() throws RemoteException;
  
  void masterClearInbulitSD() throws RemoteException;
  
  boolean mobileData(boolean paramBoolean) throws RemoteException;
  
  void putSettingsValue(int paramInt1, int paramInt2, String paramString1, String paramString2) throws RemoteException;
  
  boolean rebootDevice() throws RemoteException;
  
  boolean releaseKeyControl() throws RemoteException;
  
  void removeAppManageBlackList_v3(List<String> paramList) throws RemoteException;
  
  void removeAppManageWhiteList_v3(List<String> paramList) throws RemoteException;
  
  void removeAutostartPackageBlackList(List<String> paramList) throws RemoteException;
  
  void removeDeviceOwner(String paramString) throws RemoteException;
  
  void removeDisplayBlacklist_v3(List<String> paramList) throws RemoteException;
  
  void removeInstallPackageBlackList(List<String> paramList) throws RemoteException;
  
  void removeInstallPackageWhiteList(List<String> paramList) throws RemoteException;
  
  void removeNetworkAccessWhitelist(List<String> paramList) throws RemoteException;
  
  void removeUninstallPackageBlackList(List<String> paramList) throws RemoteException;
  
  void removeUninstallPackageWhiteList(List<String> paramList) throws RemoteException;
  
  boolean requestKeyControl(int paramInt) throws RemoteException;
  
  boolean requestKeyControl_V3(int paramInt, boolean paramBoolean) throws RemoteException;
  
  void setAlarmVolumeValue_v3(int paramInt) throws RemoteException;
  
  void setAppOpsPermissions(boolean paramBoolean) throws RemoteException;
  
  void setBackKey(boolean paramBoolean) throws RemoteException;
  
  void setBootTime(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, long paramLong) throws RemoteException;
  
  boolean setBrightness(int paramInt) throws RemoteException;
  
  void setComponentEnabled(ComponentName paramComponentName, int paramInt1, int paramInt2) throws RemoteException;
  
  void setCurrentUsbMode(int paramInt) throws RemoteException;
  
  boolean setCustomBootAnim(String paramString) throws RemoteException;
  
  void setCustomCHARGE(boolean paramBoolean) throws RemoteException;
  
  void setCustomFASTBOOT(boolean paramBoolean) throws RemoteException;
  
  void setCustomHARDRST(boolean paramBoolean) throws RemoteException;
  
  void setCustomLauncher(String paramString1, String paramString2) throws RemoteException;
  
  void setCustomOTG(boolean paramBoolean) throws RemoteException;
  
  void setCustomRecovery_v3(boolean paramBoolean) throws RemoteException;
  
  void setCustomSDUPDATE(boolean paramBoolean) throws RemoteException;
  
  boolean setCustomShutAnim(String paramString) throws RemoteException;
  
  void setCustomSplashPath(String paramString) throws RemoteException;
  
  boolean setDefaultAPN_v3(String paramString) throws RemoteException;
  
  boolean setDefaultInputMethod(String paramString) throws RemoteException;
  
  void setDefaultUsbMode(int paramInt) throws RemoteException;
  
  boolean setDeviceOwner(String paramString) throws RemoteException;
  
  boolean setDisplayBlacklist(List<String> paramList, boolean paramBoolean) throws RemoteException;
  
  void setDisplayBlacklist_v3(List<String> paramList) throws RemoteException;
  
  void setGps(boolean paramBoolean) throws RemoteException;
  
  void setHomeKey(boolean paramBoolean) throws RemoteException;
  
  boolean setHttpProxy(String paramString, int paramInt, List<String> paramList) throws RemoteException;
  
  boolean setLauncher(String paramString) throws RemoteException;
  
  boolean setLocationMode(int paramInt) throws RemoteException;
  
  void setLockNone() throws RemoteException;
  
  boolean setLockPassword(String paramString) throws RemoteException;
  
  void setLockSwipe() throws RemoteException;
  
  void setMediaVolumeValue_v3(int paramInt) throws RemoteException;
  
  void setNotificationVolumeValue_v3(int paramInt) throws RemoteException;
  
  void setOTG(boolean paramBoolean) throws RemoteException;
  
  void setPackageEnabled(String paramString, boolean paramBoolean) throws RemoteException;
  
  void setPersistValue(String paramString1, String paramString2) throws RemoteException;
  
  void setPowerLongPressKey(boolean paramBoolean) throws RemoteException;
  
  void setPowerSingleClickKey(boolean paramBoolean) throws RemoteException;
  
  void setRecentKey(boolean paramBoolean) throws RemoteException;
  
  void setRuntimePermissions(boolean paramBoolean) throws RemoteException;
  
  void setSafeModeDisabled(boolean paramBoolean) throws RemoteException;
  
  void setShutDownTime(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, long paramLong) throws RemoteException;
  
  void setSleepTimeout_V3(int paramInt) throws RemoteException;
  
  void setSysDate(int paramInt1, int paramInt2, int paramInt3) throws RemoteException;
  
  void setSysTime(long paramLong) throws RemoteException;
  
  void setTimeZone_v3(String paramString) throws RemoteException;
  
  boolean setUsbOnlyCharging(boolean paramBoolean) throws RemoteException;
  
  void setUserRestriction(String paramString, boolean paramBoolean) throws RemoteException;
  
  void setVolumedownKey(boolean paramBoolean) throws RemoteException;
  
  void setVolumeupKey(boolean paramBoolean) throws RemoteException;
  
  boolean setlockInputMethod(String paramString) throws RemoteException;
  
  boolean shutdownDevice() throws RemoteException;
  
  void silentInstall(String paramString) throws RemoteException;
  
  void silentUnInstall(String paramString) throws RemoteException;
  
  boolean sleepDevice() throws RemoteException;
  
  void uninstallPackage(String paramString, boolean paramBoolean) throws RemoteException;
  
  void unlockScreen() throws RemoteException;
  
  boolean updateSystemTime(String paramString) throws RemoteException;
  
  List<String> urlBlackListRead() throws RemoteException;
  
  boolean urlBlackListWrite(List<String> paramList) throws RemoteException;
  
  List<String> urlWhiteListRead() throws RemoteException;
  
  boolean urlWhiteListWrite(List<String> paramList) throws RemoteException;
  
  boolean wakeupDevice() throws RemoteException;
  
  public static class Default implements ICSDKManagerService {
    public List<String> APPIPWhiteListRead() throws RemoteException {
      return null;
    }
    
    public boolean AddAppBlackRule(String param1String) throws RemoteException {
      return false;
    }
    
    public boolean AddAppWhiteRule(String param1String) throws RemoteException {
      return false;
    }
    
    public boolean ClearAppRules() throws RemoteException {
      return false;
    }
    
    public boolean ClearIpHostRules() throws RemoteException {
      return false;
    }
    
    public boolean ClearRules() throws RemoteException {
      return false;
    }
    
    public boolean SetEnable(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean WriteToFile() throws RemoteException {
      return false;
    }
    
    public boolean aCLK(String param1String1, String param1String2, String param1String3) throws RemoteException {
      return false;
    }
    
    public void activateLicense(String param1String1, String param1String2, String param1String3) throws RemoteException {}
    
    public void addAppManageBlackList_v3(List<String> param1List) throws RemoteException {}
    
    public void addAppManageWhiteList_v3(List<String> param1List) throws RemoteException {}
    
    public void addAutostartPackageBlackList(List<String> param1List) throws RemoteException {}
    
    public void addInstallPackageBlackList(List<String> param1List) throws RemoteException {}
    
    public void addInstallPackageWhiteList(List<String> param1List) throws RemoteException {}
    
    public void addNetworkAccessBlacklist(List<String> param1List) throws RemoteException {}
    
    public void addNetworkAccessWhitelist(List<String> param1List) throws RemoteException {}
    
    public boolean addSSID(String param1String1, String param1String2, int param1Int, boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public void addUninstallPackageBlackList(List<String> param1List) throws RemoteException {}
    
    public void addUninstallPackageWhiteList(List<String> param1List) throws RemoteException {}
    
    public void allowBluetooth(boolean param1Boolean) throws RemoteException {}
    
    public boolean allowBluetoothDataTransfer(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public void allowCamera(boolean param1Boolean) throws RemoteException {}
    
    public void allowNavigaBar(boolean param1Boolean) throws RemoteException {}
    
    public void allowPowerKey(boolean param1Boolean) throws RemoteException {}
    
    public void allowTFcard(boolean param1Boolean) throws RemoteException {}
    
    public void allowVolumeKey(boolean param1Boolean) throws RemoteException {}
    
    public boolean appWhiteListWrite(List<String> param1List) throws RemoteException {
      return false;
    }
    
    public IBinder asBinder() {
      return null;
    }
    
    public Bitmap captureScreen() throws RemoteException {
      return null;
    }
    
    public void controlApp(String param1String, boolean param1Boolean) throws RemoteException {}
    
    public boolean deactivateLicense(String param1String1, String param1String2, String param1String3) throws RemoteException {
      return false;
    }
    
    public void disableApplicationManage_v3(boolean param1Boolean) throws RemoteException {}
    
    public void disableAutostart(boolean param1Boolean) throws RemoteException {}
    
    public boolean disableBluetooth(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public void disableBluetoothShare(boolean param1Boolean) throws RemoteException {}
    
    public boolean disableCamera(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public void disableFactoryReset(boolean param1Boolean) throws RemoteException {}
    
    public boolean disableHiddenGame(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public void disableInstallation(boolean param1Boolean) throws RemoteException {}
    
    public boolean disableLocation(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean disableLockScreenNotification(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public void disableMultiUser(boolean param1Boolean) throws RemoteException {}
    
    public void disableStatusBarNotification(boolean param1Boolean) throws RemoteException {}
    
    public boolean disableStatusBarPanel(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public void disableTabletMasterAutostart(boolean param1Boolean) throws RemoteException {}
    
    public void disableUnInstallation(boolean param1Boolean) throws RemoteException {}
    
    public boolean disableWifi(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean disableWifiDirect(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean disallowAPN_v3(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean disallowAirplaneMode_v3(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public void disallowAutoDateAndTime_V3(boolean param1Boolean) throws RemoteException {}
    
    public boolean disallowBluetoothShare_v3(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean disallowBluetooth_v3(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean disallowData_v3(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public void disallowFactoryReset_v3(boolean param1Boolean) throws RemoteException {}
    
    public boolean disallowLocation_v3(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean disallowLockScreenMode_v3(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public void disallowLockScreenNotification_v3(boolean param1Boolean) throws RemoteException {}
    
    public void disallowMultiUser_v3(boolean param1Boolean) throws RemoteException {}
    
    public boolean disallowSIMcard_v3(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public void disallowSetAlarmVolume_v3(boolean param1Boolean) throws RemoteException {}
    
    public void disallowSetBootTime_V3(boolean param1Boolean) throws RemoteException {}
    
    public void disallowSetBrightness_v3(boolean param1Boolean) throws RemoteException {}
    
    public void disallowSetInputMethod_v3(String param1String, boolean param1Boolean) throws RemoteException {}
    
    public void disallowSetMediaVolume_v3(boolean param1Boolean) throws RemoteException {}
    
    public void disallowSetNotificationVolume_v3(boolean param1Boolean) throws RemoteException {}
    
    public void disallowSetShutDownTime_V3(boolean param1Boolean) throws RemoteException {}
    
    public void disallowSetSleepTimeout_V3(boolean param1Boolean) throws RemoteException {}
    
    public void disallowSetSysDate_v3(boolean param1Boolean) throws RemoteException {}
    
    public void disallowSetSysTimeZone_v3(boolean param1Boolean) throws RemoteException {}
    
    public void disallowSetSysTime_v3(boolean param1Boolean) throws RemoteException {}
    
    public void disallowSwitchLauncher_v3(boolean param1Boolean) throws RemoteException {}
    
    public boolean disallowUsbDebugging_v3(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean disallowUsbMode_v3(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean disallowWIFIAccessPoint_v3(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean disallowWifiDirect_v3(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean disallowWifiHotspot_v3(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean disallowWifi_v3(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean disallowWifiadvancesettings_v3(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean disallowedBluetoothtethering_v3(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean disallowedUSBtethering_v3(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public void enableAirplaneMode(boolean param1Boolean) throws RemoteException {}
    
    public void enableAllUnkownsources_v3(boolean param1Boolean) throws RemoteException {}
    
    public boolean enableAutoBrightness(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean enableBluetooth_v3(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean enableBluetoothtethering_v3(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public void enableCaptureScreen_v3(boolean param1Boolean) throws RemoteException {}
    
    public boolean enableData(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean enableData_v3(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean enableDevMode(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public void enableDevMode_v3(boolean param1Boolean) throws RemoteException {}
    
    public boolean enableLocation_v3(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean enableMassStorage(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public void enableNetworkAccess(boolean param1Boolean) throws RemoteException {}
    
    public boolean enableSIM(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public void enableSearch_v3(boolean param1Boolean) throws RemoteException {}
    
    public boolean enableSystemAutoUpdate(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean enableUSBtethering_v3(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public void enableUnkownsources_v3(String param1String, boolean param1Boolean) throws RemoteException {}
    
    public boolean enableUsbDebugging(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean enableWIFIcaptive_v3(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean enableWifiHotspot_v3(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean enableWifi_v3(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public List<String> forceStopPackageWhiteListRead() throws RemoteException {
      return null;
    }
    
    public boolean forceStopPackageWhiteListWrite(List<String> param1List) throws RemoteException {
      return false;
    }
    
    public void fullScreenForever(boolean param1Boolean) throws RemoteException {}
    
    public List<String> getAppBlackRules() throws RemoteException {
      return null;
    }
    
    public List<String> getAppManageBlackList_v3() throws RemoteException {
      return null;
    }
    
    public List<String> getAppManageWhiteList_v3() throws RemoteException {
      return null;
    }
    
    public List<String> getAutostartPackageBlackList() throws RemoteException {
      return null;
    }
    
    public String getBtStatus() throws RemoteException {
      return null;
    }
    
    public boolean getCustomCHARGE() throws RemoteException {
      return false;
    }
    
    public boolean getCustomFASTBOOT() throws RemoteException {
      return false;
    }
    
    public boolean getCustomHARDRST() throws RemoteException {
      return false;
    }
    
    public boolean getCustomOTG() throws RemoteException {
      return false;
    }
    
    public boolean getCustomRecovery_v3() throws RemoteException {
      return false;
    }
    
    public boolean getCustomSDUPDATE() throws RemoteException {
      return false;
    }
    
    public boolean getCustomSplashPath() throws RemoteException {
      return false;
    }
    
    public String getDeviceInfo(int param1Int) throws RemoteException {
      return null;
    }
    
    public List<String> getDisplayBlacklist_v3() throws RemoteException {
      return null;
    }
    
    public List<String> getInstallPackageBlackList() throws RemoteException {
      return null;
    }
    
    public List<String> getInstallPackageWhiteList() throws RemoteException {
      return null;
    }
    
    public Bitmap getMiaScreen() throws RemoteException {
      return null;
    }
    
    public List<String> getNetworkAccessBlacklist() throws RemoteException {
      return null;
    }
    
    public List<String> getNetworkAccessWhitelist() throws RemoteException {
      return null;
    }
    
    public List<String> getUninstallPackageBlackList() throws RemoteException {
      return null;
    }
    
    public List<String> getUninstallPackageWhiteList() throws RemoteException {
      return null;
    }
    
    public String getWifiStatus() throws RemoteException {
      return null;
    }
    
    public boolean hideBackSoftKey(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean hideHomeSoftKey(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean hideMenuSoftKey(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public void hideNavigationBar(boolean param1Boolean) throws RemoteException {}
    
    public boolean hideStatusBar(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public boolean hideUsbMenu(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public void installPackage(String param1String) throws RemoteException {}
    
    public boolean isBackKeyAllowed() throws RemoteException {
      return false;
    }
    
    public boolean isBluetoothAllowed() throws RemoteException {
      return false;
    }
    
    public boolean isBluetoothDataTransferAllowed() throws RemoteException {
      return false;
    }
    
    public boolean isCameraAllowed() throws RemoteException {
      return false;
    }
    
    public boolean isEnable() throws RemoteException {
      return false;
    }
    
    public boolean isHomeKeyAllowed() throws RemoteException {
      return false;
    }
    
    public boolean isLicenseKeyEnabled(String param1String) throws RemoteException {
      return false;
    }
    
    public boolean isLocationAllowed() throws RemoteException {
      return false;
    }
    
    public boolean isNavigaBarAllowed() throws RemoteException {
      return false;
    }
    
    public boolean isNetworkRulesEnabled() throws RemoteException {
      return false;
    }
    
    public boolean isPowerKeyAllowed() throws RemoteException {
      return false;
    }
    
    public boolean isRecentKeyAllowed() throws RemoteException {
      return false;
    }
    
    public boolean isTFcardAllowed() throws RemoteException {
      return false;
    }
    
    public boolean isUsbOnlyCharging() throws RemoteException {
      return false;
    }
    
    public boolean isVolumeKeyAllowed() throws RemoteException {
      return false;
    }
    
    public boolean killApp(String param1String) throws RemoteException {
      return false;
    }
    
    public void killApplicationProcess(String param1String) throws RemoteException {}
    
    public boolean launchFactoryReset() throws RemoteException {
      return false;
    }
    
    public void masterClearInbulitSD() throws RemoteException {}
    
    public boolean mobileData(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public void putSettingsValue(int param1Int1, int param1Int2, String param1String1, String param1String2) throws RemoteException {}
    
    public boolean rebootDevice() throws RemoteException {
      return false;
    }
    
    public boolean releaseKeyControl() throws RemoteException {
      return false;
    }
    
    public void removeAppManageBlackList_v3(List<String> param1List) throws RemoteException {}
    
    public void removeAppManageWhiteList_v3(List<String> param1List) throws RemoteException {}
    
    public void removeAutostartPackageBlackList(List<String> param1List) throws RemoteException {}
    
    public void removeDeviceOwner(String param1String) throws RemoteException {}
    
    public void removeDisplayBlacklist_v3(List<String> param1List) throws RemoteException {}
    
    public void removeInstallPackageBlackList(List<String> param1List) throws RemoteException {}
    
    public void removeInstallPackageWhiteList(List<String> param1List) throws RemoteException {}
    
    public void removeNetworkAccessWhitelist(List<String> param1List) throws RemoteException {}
    
    public void removeUninstallPackageBlackList(List<String> param1List) throws RemoteException {}
    
    public void removeUninstallPackageWhiteList(List<String> param1List) throws RemoteException {}
    
    public boolean requestKeyControl(int param1Int) throws RemoteException {
      return false;
    }
    
    public boolean requestKeyControl_V3(int param1Int, boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public void setAlarmVolumeValue_v3(int param1Int) throws RemoteException {}
    
    public void setAppOpsPermissions(boolean param1Boolean) throws RemoteException {}
    
    public void setBackKey(boolean param1Boolean) throws RemoteException {}
    
    public void setBootTime(boolean param1Boolean, int param1Int1, int param1Int2, int param1Int3, long param1Long) throws RemoteException {}
    
    public boolean setBrightness(int param1Int) throws RemoteException {
      return false;
    }
    
    public void setComponentEnabled(ComponentName param1ComponentName, int param1Int1, int param1Int2) throws RemoteException {}
    
    public void setCurrentUsbMode(int param1Int) throws RemoteException {}
    
    public boolean setCustomBootAnim(String param1String) throws RemoteException {
      return false;
    }
    
    public void setCustomCHARGE(boolean param1Boolean) throws RemoteException {}
    
    public void setCustomFASTBOOT(boolean param1Boolean) throws RemoteException {}
    
    public void setCustomHARDRST(boolean param1Boolean) throws RemoteException {}
    
    public void setCustomLauncher(String param1String1, String param1String2) throws RemoteException {}
    
    public void setCustomOTG(boolean param1Boolean) throws RemoteException {}
    
    public void setCustomRecovery_v3(boolean param1Boolean) throws RemoteException {}
    
    public void setCustomSDUPDATE(boolean param1Boolean) throws RemoteException {}
    
    public boolean setCustomShutAnim(String param1String) throws RemoteException {
      return false;
    }
    
    public void setCustomSplashPath(String param1String) throws RemoteException {}
    
    public boolean setDefaultAPN_v3(String param1String) throws RemoteException {
      return false;
    }
    
    public boolean setDefaultInputMethod(String param1String) throws RemoteException {
      return false;
    }
    
    public void setDefaultUsbMode(int param1Int) throws RemoteException {}
    
    public boolean setDeviceOwner(String param1String) throws RemoteException {
      return false;
    }
    
    public boolean setDisplayBlacklist(List<String> param1List, boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public void setDisplayBlacklist_v3(List<String> param1List) throws RemoteException {}
    
    public void setGps(boolean param1Boolean) throws RemoteException {}
    
    public void setHomeKey(boolean param1Boolean) throws RemoteException {}
    
    public boolean setHttpProxy(String param1String, int param1Int, List<String> param1List) throws RemoteException {
      return false;
    }
    
    public boolean setLauncher(String param1String) throws RemoteException {
      return false;
    }
    
    public boolean setLocationMode(int param1Int) throws RemoteException {
      return false;
    }
    
    public void setLockNone() throws RemoteException {}
    
    public boolean setLockPassword(String param1String) throws RemoteException {
      return false;
    }
    
    public void setLockSwipe() throws RemoteException {}
    
    public void setMediaVolumeValue_v3(int param1Int) throws RemoteException {}
    
    public void setNotificationVolumeValue_v3(int param1Int) throws RemoteException {}
    
    public void setOTG(boolean param1Boolean) throws RemoteException {}
    
    public void setPackageEnabled(String param1String, boolean param1Boolean) throws RemoteException {}
    
    public void setPersistValue(String param1String1, String param1String2) throws RemoteException {}
    
    public void setPowerLongPressKey(boolean param1Boolean) throws RemoteException {}
    
    public void setPowerSingleClickKey(boolean param1Boolean) throws RemoteException {}
    
    public void setRecentKey(boolean param1Boolean) throws RemoteException {}
    
    public void setRuntimePermissions(boolean param1Boolean) throws RemoteException {}
    
    public void setSafeModeDisabled(boolean param1Boolean) throws RemoteException {}
    
    public void setShutDownTime(boolean param1Boolean, int param1Int1, int param1Int2, int param1Int3, long param1Long) throws RemoteException {}
    
    public void setSleepTimeout_V3(int param1Int) throws RemoteException {}
    
    public void setSysDate(int param1Int1, int param1Int2, int param1Int3) throws RemoteException {}
    
    public void setSysTime(long param1Long) throws RemoteException {}
    
    public void setTimeZone_v3(String param1String) throws RemoteException {}
    
    public boolean setUsbOnlyCharging(boolean param1Boolean) throws RemoteException {
      return false;
    }
    
    public void setUserRestriction(String param1String, boolean param1Boolean) throws RemoteException {}
    
    public void setVolumedownKey(boolean param1Boolean) throws RemoteException {}
    
    public void setVolumeupKey(boolean param1Boolean) throws RemoteException {}
    
    public boolean setlockInputMethod(String param1String) throws RemoteException {
      return false;
    }
    
    public boolean shutdownDevice() throws RemoteException {
      return false;
    }
    
    public void silentInstall(String param1String) throws RemoteException {}
    
    public void silentUnInstall(String param1String) throws RemoteException {}
    
    public boolean sleepDevice() throws RemoteException {
      return false;
    }
    
    public void uninstallPackage(String param1String, boolean param1Boolean) throws RemoteException {}
    
    public void unlockScreen() throws RemoteException {}
    
    public boolean updateSystemTime(String param1String) throws RemoteException {
      return false;
    }
    
    public List<String> urlBlackListRead() throws RemoteException {
      return null;
    }
    
    public boolean urlBlackListWrite(List<String> param1List) throws RemoteException {
      return false;
    }
    
    public List<String> urlWhiteListRead() throws RemoteException {
      return null;
    }
    
    public boolean urlWhiteListWrite(List<String> param1List) throws RemoteException {
      return false;
    }
    
    public boolean wakeupDevice() throws RemoteException {
      return false;
    }
  }
  
  public static abstract class Stub extends Binder implements ICSDKManagerService {
    private static final String DESCRIPTOR = "android.app.csdk.ICSDKManagerService";
    
    static final int TRANSACTION_APPIPWhiteListRead = 227;
    
    static final int TRANSACTION_AddAppBlackRule = 228;
    
    static final int TRANSACTION_AddAppWhiteRule = 226;
    
    static final int TRANSACTION_ClearAppRules = 230;
    
    static final int TRANSACTION_ClearIpHostRules = 225;
    
    static final int TRANSACTION_ClearRules = 231;
    
    static final int TRANSACTION_SetEnable = 219;
    
    static final int TRANSACTION_WriteToFile = 232;
    
    static final int TRANSACTION_aCLK = 134;
    
    static final int TRANSACTION_activateLicense = 132;
    
    static final int TRANSACTION_addAppManageBlackList_v3 = 50;
    
    static final int TRANSACTION_addAppManageWhiteList_v3 = 47;
    
    static final int TRANSACTION_addAutostartPackageBlackList = 75;
    
    static final int TRANSACTION_addInstallPackageBlackList = 64;
    
    static final int TRANSACTION_addInstallPackageWhiteList = 61;
    
    static final int TRANSACTION_addNetworkAccessBlacklist = 39;
    
    static final int TRANSACTION_addNetworkAccessWhitelist = 37;
    
    static final int TRANSACTION_addSSID = 93;
    
    static final int TRANSACTION_addUninstallPackageBlackList = 70;
    
    static final int TRANSACTION_addUninstallPackageWhiteList = 67;
    
    static final int TRANSACTION_allowBluetooth = 194;
    
    static final int TRANSACTION_allowBluetoothDataTransfer = 207;
    
    static final int TRANSACTION_allowCamera = 177;
    
    static final int TRANSACTION_allowNavigaBar = 182;
    
    static final int TRANSACTION_allowPowerKey = 190;
    
    static final int TRANSACTION_allowTFcard = 175;
    
    static final int TRANSACTION_allowVolumeKey = 192;
    
    static final int TRANSACTION_appWhiteListWrite = 233;
    
    static final int TRANSACTION_captureScreen = 19;
    
    static final int TRANSACTION_controlApp = 209;
    
    static final int TRANSACTION_deactivateLicense = 133;
    
    static final int TRANSACTION_disableApplicationManage_v3 = 58;
    
    static final int TRANSACTION_disableAutostart = 74;
    
    static final int TRANSACTION_disableBluetooth = 87;
    
    static final int TRANSACTION_disableBluetoothShare = 92;
    
    static final int TRANSACTION_disableCamera = 29;
    
    static final int TRANSACTION_disableFactoryReset = 23;
    
    static final int TRANSACTION_disableHiddenGame = 147;
    
    static final int TRANSACTION_disableInstallation = 56;
    
    static final int TRANSACTION_disableLocation = 31;
    
    static final int TRANSACTION_disableLockScreenNotification = 127;
    
    static final int TRANSACTION_disableMultiUser = 27;
    
    static final int TRANSACTION_disableStatusBarNotification = 126;
    
    static final int TRANSACTION_disableStatusBarPanel = 120;
    
    static final int TRANSACTION_disableTabletMasterAutostart = 73;
    
    static final int TRANSACTION_disableUnInstallation = 57;
    
    static final int TRANSACTION_disableWifi = 88;
    
    static final int TRANSACTION_disableWifiDirect = 86;
    
    static final int TRANSACTION_disallowAPN_v3 = 96;
    
    static final int TRANSACTION_disallowAirplaneMode_v3 = 115;
    
    static final int TRANSACTION_disallowAutoDateAndTime_V3 = 166;
    
    static final int TRANSACTION_disallowBluetoothShare_v3 = 108;
    
    static final int TRANSACTION_disallowBluetooth_v3 = 101;
    
    static final int TRANSACTION_disallowData_v3 = 106;
    
    static final int TRANSACTION_disallowFactoryReset_v3 = 24;
    
    static final int TRANSACTION_disallowLocation_v3 = 118;
    
    static final int TRANSACTION_disallowLockScreenMode_v3 = 172;
    
    static final int TRANSACTION_disallowLockScreenNotification_v3 = 152;
    
    static final int TRANSACTION_disallowMultiUser_v3 = 28;
    
    static final int TRANSACTION_disallowSIMcard_v3 = 98;
    
    static final int TRANSACTION_disallowSetAlarmVolume_v3 = 160;
    
    static final int TRANSACTION_disallowSetBootTime_V3 = 164;
    
    static final int TRANSACTION_disallowSetBrightness_v3 = 161;
    
    static final int TRANSACTION_disallowSetInputMethod_v3 = 154;
    
    static final int TRANSACTION_disallowSetMediaVolume_v3 = 156;
    
    static final int TRANSACTION_disallowSetNotificationVolume_v3 = 158;
    
    static final int TRANSACTION_disallowSetShutDownTime_V3 = 165;
    
    static final int TRANSACTION_disallowSetSleepTimeout_V3 = 163;
    
    static final int TRANSACTION_disallowSetSysDate_v3 = 139;
    
    static final int TRANSACTION_disallowSetSysTimeZone_v3 = 141;
    
    static final int TRANSACTION_disallowSetSysTime_v3 = 137;
    
    static final int TRANSACTION_disallowSwitchLauncher_v3 = 153;
    
    static final int TRANSACTION_disallowUsbDebugging_v3 = 170;
    
    static final int TRANSACTION_disallowUsbMode_v3 = 99;
    
    static final int TRANSACTION_disallowWIFIAccessPoint_v3 = 97;
    
    static final int TRANSACTION_disallowWifiDirect_v3 = 100;
    
    static final int TRANSACTION_disallowWifiHotspot_v3 = 110;
    
    static final int TRANSACTION_disallowWifi_v3 = 103;
    
    static final int TRANSACTION_disallowWifiadvancesettings_v3 = 105;
    
    static final int TRANSACTION_disallowedBluetoothtethering_v3 = 114;
    
    static final int TRANSACTION_disallowedUSBtethering_v3 = 112;
    
    static final int TRANSACTION_enableAirplaneMode = 144;
    
    static final int TRANSACTION_enableAllUnkownsources_v3 = 174;
    
    static final int TRANSACTION_enableAutoBrightness = 142;
    
    static final int TRANSACTION_enableBluetooth_v3 = 102;
    
    static final int TRANSACTION_enableBluetoothtethering_v3 = 113;
    
    static final int TRANSACTION_enableCaptureScreen_v3 = 20;
    
    static final int TRANSACTION_enableData = 90;
    
    static final int TRANSACTION_enableData_v3 = 107;
    
    static final int TRANSACTION_enableDevMode = 25;
    
    static final int TRANSACTION_enableDevMode_v3 = 173;
    
    static final int TRANSACTION_enableLocation_v3 = 117;
    
    static final int TRANSACTION_enableMassStorage = 91;
    
    static final int TRANSACTION_enableNetworkAccess = 41;
    
    static final int TRANSACTION_enableSIM = 89;
    
    static final int TRANSACTION_enableSearch_v3 = 171;
    
    static final int TRANSACTION_enableSystemAutoUpdate = 26;
    
    static final int TRANSACTION_enableUSBtethering_v3 = 111;
    
    static final int TRANSACTION_enableUnkownsources_v3 = 169;
    
    static final int TRANSACTION_enableUsbDebugging = 83;
    
    static final int TRANSACTION_enableWIFIcaptive_v3 = 116;
    
    static final int TRANSACTION_enableWifiHotspot_v3 = 109;
    
    static final int TRANSACTION_enableWifi_v3 = 104;
    
    static final int TRANSACTION_forceStopPackageWhiteListRead = 211;
    
    static final int TRANSACTION_forceStopPackageWhiteListWrite = 210;
    
    static final int TRANSACTION_fullScreenForever = 125;
    
    static final int TRANSACTION_getAppBlackRules = 229;
    
    static final int TRANSACTION_getAppManageBlackList_v3 = 51;
    
    static final int TRANSACTION_getAppManageWhiteList_v3 = 48;
    
    static final int TRANSACTION_getAutostartPackageBlackList = 76;
    
    static final int TRANSACTION_getBtStatus = 203;
    
    static final int TRANSACTION_getCustomCHARGE = 14;
    
    static final int TRANSACTION_getCustomFASTBOOT = 6;
    
    static final int TRANSACTION_getCustomHARDRST = 12;
    
    static final int TRANSACTION_getCustomOTG = 4;
    
    static final int TRANSACTION_getCustomRecovery_v3 = 8;
    
    static final int TRANSACTION_getCustomSDUPDATE = 10;
    
    static final int TRANSACTION_getCustomSplashPath = 2;
    
    static final int TRANSACTION_getDeviceInfo = 32;
    
    static final int TRANSACTION_getDisplayBlacklist_v3 = 45;
    
    static final int TRANSACTION_getInstallPackageBlackList = 65;
    
    static final int TRANSACTION_getInstallPackageWhiteList = 62;
    
    static final int TRANSACTION_getMiaScreen = 213;
    
    static final int TRANSACTION_getNetworkAccessBlacklist = 40;
    
    static final int TRANSACTION_getNetworkAccessWhitelist = 38;
    
    static final int TRANSACTION_getUninstallPackageBlackList = 71;
    
    static final int TRANSACTION_getUninstallPackageWhiteList = 68;
    
    static final int TRANSACTION_getWifiStatus = 204;
    
    static final int TRANSACTION_hideBackSoftKey = 121;
    
    static final int TRANSACTION_hideHomeSoftKey = 122;
    
    static final int TRANSACTION_hideMenuSoftKey = 123;
    
    static final int TRANSACTION_hideNavigationBar = 124;
    
    static final int TRANSACTION_hideStatusBar = 119;
    
    static final int TRANSACTION_hideUsbMenu = 82;
    
    static final int TRANSACTION_installPackage = 59;
    
    static final int TRANSACTION_isBackKeyAllowed = 187;
    
    static final int TRANSACTION_isBluetoothAllowed = 195;
    
    static final int TRANSACTION_isBluetoothDataTransferAllowed = 208;
    
    static final int TRANSACTION_isCameraAllowed = 178;
    
    static final int TRANSACTION_isEnable = 220;
    
    static final int TRANSACTION_isHomeKeyAllowed = 188;
    
    static final int TRANSACTION_isLicenseKeyEnabled = 135;
    
    static final int TRANSACTION_isLocationAllowed = 197;
    
    static final int TRANSACTION_isNavigaBarAllowed = 186;
    
    static final int TRANSACTION_isNetworkRulesEnabled = 42;
    
    static final int TRANSACTION_isPowerKeyAllowed = 191;
    
    static final int TRANSACTION_isRecentKeyAllowed = 189;
    
    static final int TRANSACTION_isTFcardAllowed = 176;
    
    static final int TRANSACTION_isUsbOnlyCharging = 199;
    
    static final int TRANSACTION_isVolumeKeyAllowed = 193;
    
    static final int TRANSACTION_killApp = 181;
    
    static final int TRANSACTION_killApplicationProcess = 206;
    
    static final int TRANSACTION_launchFactoryReset = 22;
    
    static final int TRANSACTION_masterClearInbulitSD = 205;
    
    static final int TRANSACTION_mobileData = 218;
    
    static final int TRANSACTION_putSettingsValue = 168;
    
    static final int TRANSACTION_rebootDevice = 18;
    
    static final int TRANSACTION_releaseKeyControl = 35;
    
    static final int TRANSACTION_removeAppManageBlackList_v3 = 52;
    
    static final int TRANSACTION_removeAppManageWhiteList_v3 = 49;
    
    static final int TRANSACTION_removeAutostartPackageBlackList = 77;
    
    static final int TRANSACTION_removeDeviceOwner = 80;
    
    static final int TRANSACTION_removeDisplayBlacklist_v3 = 46;
    
    static final int TRANSACTION_removeInstallPackageBlackList = 66;
    
    static final int TRANSACTION_removeInstallPackageWhiteList = 63;
    
    static final int TRANSACTION_removeNetworkAccessWhitelist = 36;
    
    static final int TRANSACTION_removeUninstallPackageBlackList = 72;
    
    static final int TRANSACTION_removeUninstallPackageWhiteList = 69;
    
    static final int TRANSACTION_requestKeyControl = 33;
    
    static final int TRANSACTION_requestKeyControl_V3 = 34;
    
    static final int TRANSACTION_setAlarmVolumeValue_v3 = 159;
    
    static final int TRANSACTION_setAppOpsPermissions = 55;
    
    static final int TRANSACTION_setBackKey = 183;
    
    static final int TRANSACTION_setBootTime = 145;
    
    static final int TRANSACTION_setBrightness = 143;
    
    static final int TRANSACTION_setComponentEnabled = 78;
    
    static final int TRANSACTION_setCurrentUsbMode = 84;
    
    static final int TRANSACTION_setCustomBootAnim = 128;
    
    static final int TRANSACTION_setCustomCHARGE = 13;
    
    static final int TRANSACTION_setCustomFASTBOOT = 5;
    
    static final int TRANSACTION_setCustomHARDRST = 11;
    
    static final int TRANSACTION_setCustomLauncher = 131;
    
    static final int TRANSACTION_setCustomOTG = 3;
    
    static final int TRANSACTION_setCustomRecovery_v3 = 7;
    
    static final int TRANSACTION_setCustomSDUPDATE = 9;
    
    static final int TRANSACTION_setCustomShutAnim = 129;
    
    static final int TRANSACTION_setCustomSplashPath = 1;
    
    static final int TRANSACTION_setDefaultAPN_v3 = 95;
    
    static final int TRANSACTION_setDefaultInputMethod = 151;
    
    static final int TRANSACTION_setDefaultUsbMode = 85;
    
    static final int TRANSACTION_setDeviceOwner = 79;
    
    static final int TRANSACTION_setDisplayBlacklist = 43;
    
    static final int TRANSACTION_setDisplayBlacklist_v3 = 44;
    
    static final int TRANSACTION_setGps = 196;
    
    static final int TRANSACTION_setHomeKey = 184;
    
    static final int TRANSACTION_setHttpProxy = 94;
    
    static final int TRANSACTION_setLauncher = 130;
    
    static final int TRANSACTION_setLocationMode = 148;
    
    static final int TRANSACTION_setLockNone = 149;
    
    static final int TRANSACTION_setLockPassword = 202;
    
    static final int TRANSACTION_setLockSwipe = 150;
    
    static final int TRANSACTION_setMediaVolumeValue_v3 = 155;
    
    static final int TRANSACTION_setNotificationVolumeValue_v3 = 157;
    
    static final int TRANSACTION_setOTG = 212;
    
    static final int TRANSACTION_setPackageEnabled = 81;
    
    static final int TRANSACTION_setPersistValue = 167;
    
    static final int TRANSACTION_setPowerLongPressKey = 214;
    
    static final int TRANSACTION_setPowerSingleClickKey = 215;
    
    static final int TRANSACTION_setRecentKey = 185;
    
    static final int TRANSACTION_setRuntimePermissions = 53;
    
    static final int TRANSACTION_setSafeModeDisabled = 21;
    
    static final int TRANSACTION_setShutDownTime = 146;
    
    static final int TRANSACTION_setSleepTimeout_V3 = 162;
    
    static final int TRANSACTION_setSysDate = 138;
    
    static final int TRANSACTION_setSysTime = 136;
    
    static final int TRANSACTION_setTimeZone_v3 = 140;
    
    static final int TRANSACTION_setUsbOnlyCharging = 198;
    
    static final int TRANSACTION_setUserRestriction = 30;
    
    static final int TRANSACTION_setVolumedownKey = 216;
    
    static final int TRANSACTION_setVolumeupKey = 217;
    
    static final int TRANSACTION_setlockInputMethod = 54;
    
    static final int TRANSACTION_shutdownDevice = 15;
    
    static final int TRANSACTION_silentInstall = 180;
    
    static final int TRANSACTION_silentUnInstall = 179;
    
    static final int TRANSACTION_sleepDevice = 16;
    
    static final int TRANSACTION_uninstallPackage = 60;
    
    static final int TRANSACTION_unlockScreen = 201;
    
    static final int TRANSACTION_updateSystemTime = 200;
    
    static final int TRANSACTION_urlBlackListRead = 224;
    
    static final int TRANSACTION_urlBlackListWrite = 223;
    
    static final int TRANSACTION_urlWhiteListRead = 222;
    
    static final int TRANSACTION_urlWhiteListWrite = 221;
    
    static final int TRANSACTION_wakeupDevice = 17;
    
    public Stub() {
      attachInterface(this, "android.app.csdk.ICSDKManagerService");
    }
    
    public static ICSDKManagerService asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("android.app.csdk.ICSDKManagerService");
      return (iInterface != null && iInterface instanceof ICSDKManagerService) ? (ICSDKManagerService)iInterface : new Proxy(param1IBinder);
    }
    
    public static ICSDKManagerService getDefaultImpl() {
      return Proxy.sDefaultImpl;
    }
    
    public static String getDefaultTransactionName(int param1Int) {
      switch (param1Int) {
        default:
          return null;
        case 233:
          return "appWhiteListWrite";
        case 232:
          return "WriteToFile";
        case 231:
          return "ClearRules";
        case 230:
          return "ClearAppRules";
        case 229:
          return "getAppBlackRules";
        case 228:
          return "AddAppBlackRule";
        case 227:
          return "APPIPWhiteListRead";
        case 226:
          return "AddAppWhiteRule";
        case 225:
          return "ClearIpHostRules";
        case 224:
          return "urlBlackListRead";
        case 223:
          return "urlBlackListWrite";
        case 222:
          return "urlWhiteListRead";
        case 221:
          return "urlWhiteListWrite";
        case 220:
          return "isEnable";
        case 219:
          return "SetEnable";
        case 218:
          return "mobileData";
        case 217:
          return "setVolumeupKey";
        case 216:
          return "setVolumedownKey";
        case 215:
          return "setPowerSingleClickKey";
        case 214:
          return "setPowerLongPressKey";
        case 213:
          return "getMiaScreen";
        case 212:
          return "setOTG";
        case 211:
          return "forceStopPackageWhiteListRead";
        case 210:
          return "forceStopPackageWhiteListWrite";
        case 209:
          return "controlApp";
        case 208:
          return "isBluetoothDataTransferAllowed";
        case 207:
          return "allowBluetoothDataTransfer";
        case 206:
          return "killApplicationProcess";
        case 205:
          return "masterClearInbulitSD";
        case 204:
          return "getWifiStatus";
        case 203:
          return "getBtStatus";
        case 202:
          return "setLockPassword";
        case 201:
          return "unlockScreen";
        case 200:
          return "updateSystemTime";
        case 199:
          return "isUsbOnlyCharging";
        case 198:
          return "setUsbOnlyCharging";
        case 197:
          return "isLocationAllowed";
        case 196:
          return "setGps";
        case 195:
          return "isBluetoothAllowed";
        case 194:
          return "allowBluetooth";
        case 193:
          return "isVolumeKeyAllowed";
        case 192:
          return "allowVolumeKey";
        case 191:
          return "isPowerKeyAllowed";
        case 190:
          return "allowPowerKey";
        case 189:
          return "isRecentKeyAllowed";
        case 188:
          return "isHomeKeyAllowed";
        case 187:
          return "isBackKeyAllowed";
        case 186:
          return "isNavigaBarAllowed";
        case 185:
          return "setRecentKey";
        case 184:
          return "setHomeKey";
        case 183:
          return "setBackKey";
        case 182:
          return "allowNavigaBar";
        case 181:
          return "killApp";
        case 180:
          return "silentInstall";
        case 179:
          return "silentUnInstall";
        case 178:
          return "isCameraAllowed";
        case 177:
          return "allowCamera";
        case 176:
          return "isTFcardAllowed";
        case 175:
          return "allowTFcard";
        case 174:
          return "enableAllUnkownsources_v3";
        case 173:
          return "enableDevMode_v3";
        case 172:
          return "disallowLockScreenMode_v3";
        case 171:
          return "enableSearch_v3";
        case 170:
          return "disallowUsbDebugging_v3";
        case 169:
          return "enableUnkownsources_v3";
        case 168:
          return "putSettingsValue";
        case 167:
          return "setPersistValue";
        case 166:
          return "disallowAutoDateAndTime_V3";
        case 165:
          return "disallowSetShutDownTime_V3";
        case 164:
          return "disallowSetBootTime_V3";
        case 163:
          return "disallowSetSleepTimeout_V3";
        case 162:
          return "setSleepTimeout_V3";
        case 161:
          return "disallowSetBrightness_v3";
        case 160:
          return "disallowSetAlarmVolume_v3";
        case 159:
          return "setAlarmVolumeValue_v3";
        case 158:
          return "disallowSetNotificationVolume_v3";
        case 157:
          return "setNotificationVolumeValue_v3";
        case 156:
          return "disallowSetMediaVolume_v3";
        case 155:
          return "setMediaVolumeValue_v3";
        case 154:
          return "disallowSetInputMethod_v3";
        case 153:
          return "disallowSwitchLauncher_v3";
        case 152:
          return "disallowLockScreenNotification_v3";
        case 151:
          return "setDefaultInputMethod";
        case 150:
          return "setLockSwipe";
        case 149:
          return "setLockNone";
        case 148:
          return "setLocationMode";
        case 147:
          return "disableHiddenGame";
        case 146:
          return "setShutDownTime";
        case 145:
          return "setBootTime";
        case 144:
          return "enableAirplaneMode";
        case 143:
          return "setBrightness";
        case 142:
          return "enableAutoBrightness";
        case 141:
          return "disallowSetSysTimeZone_v3";
        case 140:
          return "setTimeZone_v3";
        case 139:
          return "disallowSetSysDate_v3";
        case 138:
          return "setSysDate";
        case 137:
          return "disallowSetSysTime_v3";
        case 136:
          return "setSysTime";
        case 135:
          return "isLicenseKeyEnabled";
        case 134:
          return "aCLK";
        case 133:
          return "deactivateLicense";
        case 132:
          return "activateLicense";
        case 131:
          return "setCustomLauncher";
        case 130:
          return "setLauncher";
        case 129:
          return "setCustomShutAnim";
        case 128:
          return "setCustomBootAnim";
        case 127:
          return "disableLockScreenNotification";
        case 126:
          return "disableStatusBarNotification";
        case 125:
          return "fullScreenForever";
        case 124:
          return "hideNavigationBar";
        case 123:
          return "hideMenuSoftKey";
        case 122:
          return "hideHomeSoftKey";
        case 121:
          return "hideBackSoftKey";
        case 120:
          return "disableStatusBarPanel";
        case 119:
          return "hideStatusBar";
        case 118:
          return "disallowLocation_v3";
        case 117:
          return "enableLocation_v3";
        case 116:
          return "enableWIFIcaptive_v3";
        case 115:
          return "disallowAirplaneMode_v3";
        case 114:
          return "disallowedBluetoothtethering_v3";
        case 113:
          return "enableBluetoothtethering_v3";
        case 112:
          return "disallowedUSBtethering_v3";
        case 111:
          return "enableUSBtethering_v3";
        case 110:
          return "disallowWifiHotspot_v3";
        case 109:
          return "enableWifiHotspot_v3";
        case 108:
          return "disallowBluetoothShare_v3";
        case 107:
          return "enableData_v3";
        case 106:
          return "disallowData_v3";
        case 105:
          return "disallowWifiadvancesettings_v3";
        case 104:
          return "enableWifi_v3";
        case 103:
          return "disallowWifi_v3";
        case 102:
          return "enableBluetooth_v3";
        case 101:
          return "disallowBluetooth_v3";
        case 100:
          return "disallowWifiDirect_v3";
        case 99:
          return "disallowUsbMode_v3";
        case 98:
          return "disallowSIMcard_v3";
        case 97:
          return "disallowWIFIAccessPoint_v3";
        case 96:
          return "disallowAPN_v3";
        case 95:
          return "setDefaultAPN_v3";
        case 94:
          return "setHttpProxy";
        case 93:
          return "addSSID";
        case 92:
          return "disableBluetoothShare";
        case 91:
          return "enableMassStorage";
        case 90:
          return "enableData";
        case 89:
          return "enableSIM";
        case 88:
          return "disableWifi";
        case 87:
          return "disableBluetooth";
        case 86:
          return "disableWifiDirect";
        case 85:
          return "setDefaultUsbMode";
        case 84:
          return "setCurrentUsbMode";
        case 83:
          return "enableUsbDebugging";
        case 82:
          return "hideUsbMenu";
        case 81:
          return "setPackageEnabled";
        case 80:
          return "removeDeviceOwner";
        case 79:
          return "setDeviceOwner";
        case 78:
          return "setComponentEnabled";
        case 77:
          return "removeAutostartPackageBlackList";
        case 76:
          return "getAutostartPackageBlackList";
        case 75:
          return "addAutostartPackageBlackList";
        case 74:
          return "disableAutostart";
        case 73:
          return "disableTabletMasterAutostart";
        case 72:
          return "removeUninstallPackageBlackList";
        case 71:
          return "getUninstallPackageBlackList";
        case 70:
          return "addUninstallPackageBlackList";
        case 69:
          return "removeUninstallPackageWhiteList";
        case 68:
          return "getUninstallPackageWhiteList";
        case 67:
          return "addUninstallPackageWhiteList";
        case 66:
          return "removeInstallPackageBlackList";
        case 65:
          return "getInstallPackageBlackList";
        case 64:
          return "addInstallPackageBlackList";
        case 63:
          return "removeInstallPackageWhiteList";
        case 62:
          return "getInstallPackageWhiteList";
        case 61:
          return "addInstallPackageWhiteList";
        case 60:
          return "uninstallPackage";
        case 59:
          return "installPackage";
        case 58:
          return "disableApplicationManage_v3";
        case 57:
          return "disableUnInstallation";
        case 56:
          return "disableInstallation";
        case 55:
          return "setAppOpsPermissions";
        case 54:
          return "setlockInputMethod";
        case 53:
          return "setRuntimePermissions";
        case 52:
          return "removeAppManageBlackList_v3";
        case 51:
          return "getAppManageBlackList_v3";
        case 50:
          return "addAppManageBlackList_v3";
        case 49:
          return "removeAppManageWhiteList_v3";
        case 48:
          return "getAppManageWhiteList_v3";
        case 47:
          return "addAppManageWhiteList_v3";
        case 46:
          return "removeDisplayBlacklist_v3";
        case 45:
          return "getDisplayBlacklist_v3";
        case 44:
          return "setDisplayBlacklist_v3";
        case 43:
          return "setDisplayBlacklist";
        case 42:
          return "isNetworkRulesEnabled";
        case 41:
          return "enableNetworkAccess";
        case 40:
          return "getNetworkAccessBlacklist";
        case 39:
          return "addNetworkAccessBlacklist";
        case 38:
          return "getNetworkAccessWhitelist";
        case 37:
          return "addNetworkAccessWhitelist";
        case 36:
          return "removeNetworkAccessWhitelist";
        case 35:
          return "releaseKeyControl";
        case 34:
          return "requestKeyControl_V3";
        case 33:
          return "requestKeyControl";
        case 32:
          return "getDeviceInfo";
        case 31:
          return "disableLocation";
        case 30:
          return "setUserRestriction";
        case 29:
          return "disableCamera";
        case 28:
          return "disallowMultiUser_v3";
        case 27:
          return "disableMultiUser";
        case 26:
          return "enableSystemAutoUpdate";
        case 25:
          return "enableDevMode";
        case 24:
          return "disallowFactoryReset_v3";
        case 23:
          return "disableFactoryReset";
        case 22:
          return "launchFactoryReset";
        case 21:
          return "setSafeModeDisabled";
        case 20:
          return "enableCaptureScreen_v3";
        case 19:
          return "captureScreen";
        case 18:
          return "rebootDevice";
        case 17:
          return "wakeupDevice";
        case 16:
          return "sleepDevice";
        case 15:
          return "shutdownDevice";
        case 14:
          return "getCustomCHARGE";
        case 13:
          return "setCustomCHARGE";
        case 12:
          return "getCustomHARDRST";
        case 11:
          return "setCustomHARDRST";
        case 10:
          return "getCustomSDUPDATE";
        case 9:
          return "setCustomSDUPDATE";
        case 8:
          return "getCustomRecovery_v3";
        case 7:
          return "setCustomRecovery_v3";
        case 6:
          return "getCustomFASTBOOT";
        case 5:
          return "setCustomFASTBOOT";
        case 4:
          return "getCustomOTG";
        case 3:
          return "setCustomOTG";
        case 2:
          return "getCustomSplashPath";
        case 1:
          break;
      } 
      return "setCustomSplashPath";
    }
    
    public static boolean setDefaultImpl(ICSDKManagerService param1ICSDKManagerService) {
      if (Proxy.sDefaultImpl == null && param1ICSDKManagerService != null) {
        Proxy.sDefaultImpl = param1ICSDKManagerService;
        return true;
      } 
      return false;
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public String getTransactionName(int param1Int) {
      return getDefaultTransactionName(param1Int);
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      boolean bool1 = false;
      boolean bool2 = false;
      boolean bool3 = false;
      boolean bool4 = false;
      boolean bool5 = false;
      boolean bool6 = false;
      boolean bool7 = false;
      boolean bool8 = false;
      boolean bool9 = false;
      boolean bool10 = false;
      boolean bool11 = false;
      boolean bool12 = false;
      boolean bool13 = false;
      boolean bool14 = false;
      boolean bool15 = false;
      boolean bool16 = false;
      boolean bool17 = false;
      boolean bool18 = false;
      boolean bool19 = false;
      boolean bool20 = false;
      boolean bool21 = false;
      boolean bool22 = false;
      boolean bool23 = false;
      boolean bool24 = false;
      boolean bool25 = false;
      boolean bool26 = false;
      boolean bool27 = false;
      boolean bool28 = false;
      boolean bool29 = false;
      boolean bool30 = false;
      boolean bool31 = false;
      boolean bool32 = false;
      boolean bool33 = false;
      boolean bool34 = false;
      boolean bool35 = false;
      boolean bool36 = false;
      boolean bool37 = false;
      boolean bool38 = false;
      boolean bool39 = false;
      boolean bool40 = false;
      boolean bool41 = false;
      boolean bool42 = false;
      boolean bool43 = false;
      boolean bool44 = false;
      boolean bool45 = false;
      boolean bool46 = false;
      boolean bool47 = false;
      boolean bool48 = false;
      boolean bool49 = false;
      boolean bool50 = false;
      boolean bool51 = false;
      boolean bool52 = false;
      boolean bool53 = false;
      boolean bool54 = false;
      boolean bool55 = false;
      boolean bool56 = false;
      boolean bool57 = false;
      boolean bool58 = false;
      boolean bool59 = false;
      boolean bool60 = false;
      boolean bool61 = false;
      boolean bool62 = false;
      boolean bool63 = false;
      boolean bool64 = false;
      boolean bool65 = false;
      boolean bool66 = false;
      boolean bool67 = false;
      boolean bool68 = false;
      boolean bool69 = false;
      boolean bool70 = false;
      boolean bool71 = false;
      boolean bool72 = false;
      boolean bool73 = false;
      boolean bool74 = false;
      boolean bool75 = false;
      boolean bool76 = false;
      boolean bool77 = false;
      boolean bool78 = false;
      boolean bool79 = false;
      boolean bool80 = false;
      boolean bool81 = false;
      boolean bool82 = false;
      boolean bool83 = false;
      boolean bool84 = false;
      boolean bool85 = false;
      boolean bool86 = false;
      boolean bool87 = false;
      boolean bool88 = false;
      boolean bool89 = false;
      boolean bool90 = false;
      boolean bool91 = false;
      boolean bool92 = false;
      boolean bool93 = false;
      boolean bool94 = false;
      boolean bool95 = false;
      boolean bool96 = false;
      boolean bool97 = false;
      boolean bool98 = false;
      boolean bool99 = false;
      boolean bool100 = false;
      boolean bool101 = false;
      boolean bool102 = false;
      boolean bool103 = false;
      boolean bool104 = false;
      boolean bool105 = false;
      boolean bool106 = false;
      boolean bool107 = false;
      boolean bool108 = false;
      boolean bool109 = false;
      boolean bool110 = false;
      boolean bool111 = false;
      boolean bool112 = false;
      boolean bool113 = false;
      null = false;
      boolean bool114 = true;
      if (param1Int1 != 1598968902) {
        boolean bool118;
        int k;
        boolean bool117;
        int j;
        boolean bool116;
        int i;
        boolean bool115;
        ArrayList<String> arrayList2;
        List<String> list3;
        Bitmap bitmap2;
        List<String> list2;
        String str2;
        ArrayList<String> arrayList1;
        List<String> list1;
        String str1;
        Bitmap bitmap1;
        String str4;
        ArrayList<String> arrayList3;
        String str3;
        String str5;
        switch (param1Int1) {
          default:
            return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
          case 233:
            param1Parcel1.enforceInterface("android.app.csdk.ICSDKManagerService");
            arrayList2 = param1Parcel1.createStringArrayList();
            bool118 = appWhiteListWrite(arrayList2);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            param1Parcel2.writeStringList(arrayList2);
            return bool114;
          case 232:
            arrayList2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = WriteToFile();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 231:
            arrayList2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = ClearRules();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 230:
            arrayList2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = ClearAppRules();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 229:
            arrayList2.enforceInterface("android.app.csdk.ICSDKManagerService");
            list3 = getAppBlackRules();
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list3);
            return bool114;
          case 228:
            list3.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = AddAppBlackRule(list3.readString());
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 227:
            list3.enforceInterface("android.app.csdk.ICSDKManagerService");
            list3 = APPIPWhiteListRead();
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list3);
            return bool114;
          case 226:
            list3.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = AddAppWhiteRule(list3.readString());
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 225:
            list3.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = ClearIpHostRules();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 224:
            list3.enforceInterface("android.app.csdk.ICSDKManagerService");
            list3 = urlBlackListRead();
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list3);
            return bool114;
          case 223:
            list3.enforceInterface("android.app.csdk.ICSDKManagerService");
            list3 = list3.createStringArrayList();
            bool118 = urlBlackListWrite(list3);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            param1Parcel2.writeStringList(list3);
            return bool114;
          case 222:
            list3.enforceInterface("android.app.csdk.ICSDKManagerService");
            list3 = urlWhiteListRead();
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list3);
            return bool114;
          case 221:
            list3.enforceInterface("android.app.csdk.ICSDKManagerService");
            list3 = list3.createStringArrayList();
            bool118 = urlWhiteListWrite(list3);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            param1Parcel2.writeStringList(list3);
            return bool114;
          case 220:
            list3.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = isEnable();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 219:
            list3.enforceInterface("android.app.csdk.ICSDKManagerService");
            if (list3.readInt() != 0)
              null = true; 
            bool118 = SetEnable(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 218:
            list3.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool1;
            if (list3.readInt() != 0)
              null = true; 
            bool118 = mobileData(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 217:
            list3.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool2;
            if (list3.readInt() != 0)
              null = true; 
            setVolumeupKey(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 216:
            list3.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool3;
            if (list3.readInt() != 0)
              null = true; 
            setVolumedownKey(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 215:
            list3.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool4;
            if (list3.readInt() != 0)
              null = true; 
            setPowerSingleClickKey(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 214:
            list3.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool5;
            if (list3.readInt() != 0)
              null = true; 
            setPowerLongPressKey(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 213:
            list3.enforceInterface("android.app.csdk.ICSDKManagerService");
            bitmap2 = getMiaScreen();
            param1Parcel2.writeNoException();
            if (bitmap2 != null) {
              param1Parcel2.writeInt(1);
              bitmap2.writeToParcel(param1Parcel2, 1);
              return bool114;
            } 
            param1Parcel2.writeInt(0);
            return bool114;
          case 212:
            bitmap2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool6;
            if (bitmap2.readInt() != 0)
              null = true; 
            setOTG(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 211:
            bitmap2.enforceInterface("android.app.csdk.ICSDKManagerService");
            list2 = forceStopPackageWhiteListRead();
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list2);
            return bool114;
          case 210:
            list2.enforceInterface("android.app.csdk.ICSDKManagerService");
            list2 = list2.createStringArrayList();
            bool118 = forceStopPackageWhiteListWrite(list2);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            param1Parcel2.writeStringList(list2);
            return bool114;
          case 209:
            list2.enforceInterface("android.app.csdk.ICSDKManagerService");
            str4 = list2.readString();
            null = bool7;
            if (list2.readInt() != 0)
              null = true; 
            controlApp(str4, null);
            param1Parcel2.writeNoException();
            return bool114;
          case 208:
            list2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = isBluetoothDataTransferAllowed();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 207:
            list2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool8;
            if (list2.readInt() != 0)
              null = true; 
            bool118 = allowBluetoothDataTransfer(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 206:
            list2.enforceInterface("android.app.csdk.ICSDKManagerService");
            killApplicationProcess(list2.readString());
            param1Parcel2.writeNoException();
            return bool114;
          case 205:
            list2.enforceInterface("android.app.csdk.ICSDKManagerService");
            masterClearInbulitSD();
            param1Parcel2.writeNoException();
            return bool114;
          case 204:
            list2.enforceInterface("android.app.csdk.ICSDKManagerService");
            str2 = getWifiStatus();
            param1Parcel2.writeNoException();
            param1Parcel2.writeString(str2);
            return bool114;
          case 203:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            str2 = getBtStatus();
            param1Parcel2.writeNoException();
            param1Parcel2.writeString(str2);
            return bool114;
          case 202:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = setLockPassword(str2.readString());
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 201:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            unlockScreen();
            param1Parcel2.writeNoException();
            return bool114;
          case 200:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = updateSystemTime(str2.readString());
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 199:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = isUsbOnlyCharging();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 198:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool9;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = setUsbOnlyCharging(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 197:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = isLocationAllowed();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 196:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool10;
            if (str2.readInt() != 0)
              null = true; 
            setGps(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 195:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = isBluetoothAllowed();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 194:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool11;
            if (str2.readInt() != 0)
              null = true; 
            allowBluetooth(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 193:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = isVolumeKeyAllowed();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 192:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool12;
            if (str2.readInt() != 0)
              null = true; 
            allowVolumeKey(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 191:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = isPowerKeyAllowed();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 190:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool13;
            if (str2.readInt() != 0)
              null = true; 
            allowPowerKey(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 189:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = isRecentKeyAllowed();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 188:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = isHomeKeyAllowed();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 187:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = isBackKeyAllowed();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 186:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = isNavigaBarAllowed();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 185:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool14;
            if (str2.readInt() != 0)
              null = true; 
            setRecentKey(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 184:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool15;
            if (str2.readInt() != 0)
              null = true; 
            setHomeKey(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 183:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool16;
            if (str2.readInt() != 0)
              null = true; 
            setBackKey(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 182:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool17;
            if (str2.readInt() != 0)
              null = true; 
            allowNavigaBar(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 181:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = killApp(str2.readString());
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 180:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            silentInstall(str2.readString());
            param1Parcel2.writeNoException();
            return bool114;
          case 179:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            silentUnInstall(str2.readString());
            param1Parcel2.writeNoException();
            return bool114;
          case 178:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = isCameraAllowed();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 177:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool18;
            if (str2.readInt() != 0)
              null = true; 
            allowCamera(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 176:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = isTFcardAllowed();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 175:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool19;
            if (str2.readInt() != 0)
              null = true; 
            allowTFcard(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 174:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool20;
            if (str2.readInt() != 0)
              null = true; 
            enableAllUnkownsources_v3(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 173:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool21;
            if (str2.readInt() != 0)
              null = true; 
            enableDevMode_v3(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 172:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool22;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = disallowLockScreenMode_v3(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 171:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool23;
            if (str2.readInt() != 0)
              null = true; 
            enableSearch_v3(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 170:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool24;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = disallowUsbDebugging_v3(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 169:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            str4 = str2.readString();
            null = bool25;
            if (str2.readInt() != 0)
              null = true; 
            enableUnkownsources_v3(str4, null);
            param1Parcel2.writeNoException();
            return bool114;
          case 168:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            putSettingsValue(str2.readInt(), str2.readInt(), str2.readString(), str2.readString());
            param1Parcel2.writeNoException();
            return bool114;
          case 167:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            setPersistValue(str2.readString(), str2.readString());
            param1Parcel2.writeNoException();
            return bool114;
          case 166:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool26;
            if (str2.readInt() != 0)
              null = true; 
            disallowAutoDateAndTime_V3(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 165:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool27;
            if (str2.readInt() != 0)
              null = true; 
            disallowSetShutDownTime_V3(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 164:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool28;
            if (str2.readInt() != 0)
              null = true; 
            disallowSetBootTime_V3(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 163:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool29;
            if (str2.readInt() != 0)
              null = true; 
            disallowSetSleepTimeout_V3(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 162:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            setSleepTimeout_V3(str2.readInt());
            param1Parcel2.writeNoException();
            return bool114;
          case 161:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool30;
            if (str2.readInt() != 0)
              null = true; 
            disallowSetBrightness_v3(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 160:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool31;
            if (str2.readInt() != 0)
              null = true; 
            disallowSetAlarmVolume_v3(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 159:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            setAlarmVolumeValue_v3(str2.readInt());
            param1Parcel2.writeNoException();
            return bool114;
          case 158:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool32;
            if (str2.readInt() != 0)
              null = true; 
            disallowSetNotificationVolume_v3(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 157:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            setNotificationVolumeValue_v3(str2.readInt());
            param1Parcel2.writeNoException();
            return bool114;
          case 156:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool33;
            if (str2.readInt() != 0)
              null = true; 
            disallowSetMediaVolume_v3(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 155:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            setMediaVolumeValue_v3(str2.readInt());
            param1Parcel2.writeNoException();
            return bool114;
          case 154:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            str4 = str2.readString();
            null = bool34;
            if (str2.readInt() != 0)
              null = true; 
            disallowSetInputMethod_v3(str4, null);
            param1Parcel2.writeNoException();
            return bool114;
          case 153:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool35;
            if (str2.readInt() != 0)
              null = true; 
            disallowSwitchLauncher_v3(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 152:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool36;
            if (str2.readInt() != 0)
              null = true; 
            disallowLockScreenNotification_v3(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 151:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = setDefaultInputMethod(str2.readString());
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 150:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            setLockSwipe();
            param1Parcel2.writeNoException();
            return bool114;
          case 149:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            setLockNone();
            param1Parcel2.writeNoException();
            return bool114;
          case 148:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = setLocationMode(str2.readInt());
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 147:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool37;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = disableHiddenGame(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 146:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            if (str2.readInt() != 0) {
              null = true;
            } else {
              null = false;
            } 
            setShutDownTime(null, str2.readInt(), str2.readInt(), str2.readInt(), str2.readLong());
            param1Parcel2.writeNoException();
            return bool114;
          case 145:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            if (str2.readInt() != 0) {
              null = true;
            } else {
              null = false;
            } 
            setBootTime(null, str2.readInt(), str2.readInt(), str2.readInt(), str2.readLong());
            param1Parcel2.writeNoException();
            return bool114;
          case 144:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool38;
            if (str2.readInt() != 0)
              null = true; 
            enableAirplaneMode(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 143:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = setBrightness(str2.readInt());
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 142:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool39;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = enableAutoBrightness(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 141:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool40;
            if (str2.readInt() != 0)
              null = true; 
            disallowSetSysTimeZone_v3(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 140:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            setTimeZone_v3(str2.readString());
            param1Parcel2.writeNoException();
            return bool114;
          case 139:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool41;
            if (str2.readInt() != 0)
              null = true; 
            disallowSetSysDate_v3(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 138:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            setSysDate(str2.readInt(), str2.readInt(), str2.readInt());
            param1Parcel2.writeNoException();
            return bool114;
          case 137:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool42;
            if (str2.readInt() != 0)
              null = true; 
            disallowSetSysTime_v3(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 136:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            setSysTime(str2.readLong());
            param1Parcel2.writeNoException();
            return bool114;
          case 135:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = isLicenseKeyEnabled(str2.readString());
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 134:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = aCLK(str2.readString(), str2.readString(), str2.readString());
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 133:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = deactivateLicense(str2.readString(), str2.readString(), str2.readString());
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 132:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            activateLicense(str2.readString(), str2.readString(), str2.readString());
            param1Parcel2.writeNoException();
            return bool114;
          case 131:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            setCustomLauncher(str2.readString(), str2.readString());
            param1Parcel2.writeNoException();
            return bool114;
          case 130:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = setLauncher(str2.readString());
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 129:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = setCustomShutAnim(str2.readString());
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 128:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = setCustomBootAnim(str2.readString());
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 127:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool43;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = disableLockScreenNotification(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 126:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool44;
            if (str2.readInt() != 0)
              null = true; 
            disableStatusBarNotification(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 125:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool45;
            if (str2.readInt() != 0)
              null = true; 
            fullScreenForever(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 124:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool46;
            if (str2.readInt() != 0)
              null = true; 
            hideNavigationBar(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 123:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool47;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = hideMenuSoftKey(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 122:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool48;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = hideHomeSoftKey(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 121:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool49;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = hideBackSoftKey(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 120:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool50;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = disableStatusBarPanel(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 119:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool51;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = hideStatusBar(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 118:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool52;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = disallowLocation_v3(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 117:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool53;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = enableLocation_v3(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 116:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool54;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = enableWIFIcaptive_v3(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 115:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool55;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = disallowAirplaneMode_v3(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 114:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool56;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = disallowedBluetoothtethering_v3(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 113:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool57;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = enableBluetoothtethering_v3(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 112:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool58;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = disallowedUSBtethering_v3(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 111:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool59;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = enableUSBtethering_v3(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 110:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool60;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = disallowWifiHotspot_v3(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 109:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool61;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = enableWifiHotspot_v3(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 108:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool62;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = disallowBluetoothShare_v3(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 107:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool63;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = enableData_v3(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 106:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool64;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = disallowData_v3(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 105:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool65;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = disallowWifiadvancesettings_v3(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 104:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool66;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = enableWifi_v3(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 103:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool67;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = disallowWifi_v3(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 102:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool68;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = enableBluetooth_v3(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 101:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool69;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = disallowBluetooth_v3(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 100:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool70;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = disallowWifiDirect_v3(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 99:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool71;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = disallowUsbMode_v3(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 98:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool72;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = disallowSIMcard_v3(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 97:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool73;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = disallowWIFIAccessPoint_v3(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 96:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool74;
            if (str2.readInt() != 0)
              null = true; 
            bool118 = disallowAPN_v3(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 95:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool118 = setDefaultAPN_v3(str2.readString());
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool118);
            return bool114;
          case 94:
            str2.enforceInterface("android.app.csdk.ICSDKManagerService");
            str4 = str2.readString();
            k = str2.readInt();
            arrayList1 = str2.createStringArrayList();
            bool117 = setHttpProxy(str4, k, arrayList1);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool117);
            param1Parcel2.writeStringList(arrayList1);
            return bool114;
          case 93:
            arrayList1.enforceInterface("android.app.csdk.ICSDKManagerService");
            str4 = arrayList1.readString();
            str5 = arrayList1.readString();
            j = arrayList1.readInt();
            null = bool75;
            if (arrayList1.readInt() != 0)
              null = true; 
            bool116 = addSSID(str4, str5, j, null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool116);
            return bool114;
          case 92:
            arrayList1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool76;
            if (arrayList1.readInt() != 0)
              null = true; 
            disableBluetoothShare(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 91:
            arrayList1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool77;
            if (arrayList1.readInt() != 0)
              null = true; 
            bool116 = enableMassStorage(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool116);
            return bool114;
          case 90:
            arrayList1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool78;
            if (arrayList1.readInt() != 0)
              null = true; 
            bool116 = enableData(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool116);
            return bool114;
          case 89:
            arrayList1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool79;
            if (arrayList1.readInt() != 0)
              null = true; 
            bool116 = enableSIM(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool116);
            return bool114;
          case 88:
            arrayList1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool80;
            if (arrayList1.readInt() != 0)
              null = true; 
            bool116 = disableWifi(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool116);
            return bool114;
          case 87:
            arrayList1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool81;
            if (arrayList1.readInt() != 0)
              null = true; 
            bool116 = disableBluetooth(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool116);
            return bool114;
          case 86:
            arrayList1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool82;
            if (arrayList1.readInt() != 0)
              null = true; 
            bool116 = disableWifiDirect(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool116);
            return bool114;
          case 85:
            arrayList1.enforceInterface("android.app.csdk.ICSDKManagerService");
            setDefaultUsbMode(arrayList1.readInt());
            param1Parcel2.writeNoException();
            return bool114;
          case 84:
            arrayList1.enforceInterface("android.app.csdk.ICSDKManagerService");
            setCurrentUsbMode(arrayList1.readInt());
            param1Parcel2.writeNoException();
            return bool114;
          case 83:
            arrayList1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool83;
            if (arrayList1.readInt() != 0)
              null = true; 
            bool116 = enableUsbDebugging(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool116);
            return bool114;
          case 82:
            arrayList1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool84;
            if (arrayList1.readInt() != 0)
              null = true; 
            bool116 = hideUsbMenu(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool116);
            return bool114;
          case 81:
            arrayList1.enforceInterface("android.app.csdk.ICSDKManagerService");
            str4 = arrayList1.readString();
            null = bool85;
            if (arrayList1.readInt() != 0)
              null = true; 
            setPackageEnabled(str4, null);
            param1Parcel2.writeNoException();
            return bool114;
          case 80:
            arrayList1.enforceInterface("android.app.csdk.ICSDKManagerService");
            removeDeviceOwner(arrayList1.readString());
            param1Parcel2.writeNoException();
            return bool114;
          case 79:
            arrayList1.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool116 = setDeviceOwner(arrayList1.readString());
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool116);
            return bool114;
          case 78:
            arrayList1.enforceInterface("android.app.csdk.ICSDKManagerService");
            if (arrayList1.readInt() != 0) {
              ComponentName componentName = (ComponentName)ComponentName.CREATOR.createFromParcel((Parcel)arrayList1);
            } else {
              str4 = null;
            } 
            setComponentEnabled((ComponentName)str4, arrayList1.readInt(), arrayList1.readInt());
            param1Parcel2.writeNoException();
            return bool114;
          case 77:
            arrayList1.enforceInterface("android.app.csdk.ICSDKManagerService");
            arrayList1 = arrayList1.createStringArrayList();
            removeAutostartPackageBlackList(arrayList1);
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(arrayList1);
            return bool114;
          case 76:
            arrayList1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = getAutostartPackageBlackList();
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 75:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = list1.createStringArrayList();
            addAutostartPackageBlackList(list1);
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 74:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool86;
            if (list1.readInt() != 0)
              null = true; 
            disableAutostart(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 73:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool87;
            if (list1.readInt() != 0)
              null = true; 
            disableTabletMasterAutostart(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 72:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = list1.createStringArrayList();
            removeUninstallPackageBlackList(list1);
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 71:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = getUninstallPackageBlackList();
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 70:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = list1.createStringArrayList();
            addUninstallPackageBlackList(list1);
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 69:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = list1.createStringArrayList();
            removeUninstallPackageWhiteList(list1);
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 68:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = getUninstallPackageWhiteList();
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 67:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = list1.createStringArrayList();
            addUninstallPackageWhiteList(list1);
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 66:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = list1.createStringArrayList();
            removeInstallPackageBlackList(list1);
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 65:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = getInstallPackageBlackList();
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 64:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = list1.createStringArrayList();
            addInstallPackageBlackList(list1);
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 63:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = list1.createStringArrayList();
            removeInstallPackageWhiteList(list1);
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 62:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = getInstallPackageWhiteList();
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 61:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = list1.createStringArrayList();
            addInstallPackageWhiteList(list1);
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 60:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            str4 = list1.readString();
            null = bool88;
            if (list1.readInt() != 0)
              null = true; 
            uninstallPackage(str4, null);
            param1Parcel2.writeNoException();
            return bool114;
          case 59:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            installPackage(list1.readString());
            param1Parcel2.writeNoException();
            return bool114;
          case 58:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool89;
            if (list1.readInt() != 0)
              null = true; 
            disableApplicationManage_v3(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 57:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool90;
            if (list1.readInt() != 0)
              null = true; 
            disableUnInstallation(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 56:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool91;
            if (list1.readInt() != 0)
              null = true; 
            disableInstallation(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 55:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool92;
            if (list1.readInt() != 0)
              null = true; 
            setAppOpsPermissions(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 54:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool116 = setlockInputMethod(list1.readString());
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool116);
            return bool114;
          case 53:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool93;
            if (list1.readInt() != 0)
              null = true; 
            setRuntimePermissions(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 52:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = list1.createStringArrayList();
            removeAppManageBlackList_v3(list1);
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 51:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = getAppManageBlackList_v3();
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 50:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = list1.createStringArrayList();
            addAppManageBlackList_v3(list1);
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 49:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = list1.createStringArrayList();
            removeAppManageWhiteList_v3(list1);
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 48:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = getAppManageWhiteList_v3();
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 47:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = list1.createStringArrayList();
            addAppManageWhiteList_v3(list1);
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 46:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = list1.createStringArrayList();
            removeDisplayBlacklist_v3(list1);
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 45:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = getDisplayBlacklist_v3();
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 44:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = list1.createStringArrayList();
            setDisplayBlacklist_v3(list1);
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 43:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            arrayList3 = list1.createStringArrayList();
            null = bool94;
            if (list1.readInt() != 0)
              null = true; 
            bool116 = setDisplayBlacklist(arrayList3, null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool116);
            param1Parcel2.writeStringList(arrayList3);
            return bool114;
          case 42:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool116 = isNetworkRulesEnabled();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool116);
            return bool114;
          case 41:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool95;
            if (list1.readInt() != 0)
              null = true; 
            enableNetworkAccess(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 40:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = getNetworkAccessBlacklist();
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 39:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = list1.createStringArrayList();
            addNetworkAccessBlacklist(list1);
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 38:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = getNetworkAccessWhitelist();
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 37:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = list1.createStringArrayList();
            addNetworkAccessWhitelist(list1);
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 36:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            list1 = list1.createStringArrayList();
            removeNetworkAccessWhitelist(list1);
            param1Parcel2.writeNoException();
            param1Parcel2.writeStringList(list1);
            return bool114;
          case 35:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool116 = releaseKeyControl();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool116);
            return bool114;
          case 34:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            i = list1.readInt();
            null = bool96;
            if (list1.readInt() != 0)
              null = true; 
            bool115 = requestKeyControl_V3(i, null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool115);
            return bool114;
          case 33:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool115 = requestKeyControl(list1.readInt());
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool115);
            return bool114;
          case 32:
            list1.enforceInterface("android.app.csdk.ICSDKManagerService");
            str1 = getDeviceInfo(list1.readInt());
            param1Parcel2.writeNoException();
            param1Parcel2.writeString(str1);
            return bool114;
          case 31:
            str1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool97;
            if (str1.readInt() != 0)
              null = true; 
            bool115 = disableLocation(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool115);
            return bool114;
          case 30:
            str1.enforceInterface("android.app.csdk.ICSDKManagerService");
            str3 = str1.readString();
            null = bool98;
            if (str1.readInt() != 0)
              null = true; 
            setUserRestriction(str3, null);
            param1Parcel2.writeNoException();
            return bool114;
          case 29:
            str1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool99;
            if (str1.readInt() != 0)
              null = true; 
            bool115 = disableCamera(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool115);
            return bool114;
          case 28:
            str1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool100;
            if (str1.readInt() != 0)
              null = true; 
            disallowMultiUser_v3(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 27:
            str1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool101;
            if (str1.readInt() != 0)
              null = true; 
            disableMultiUser(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 26:
            str1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool102;
            if (str1.readInt() != 0)
              null = true; 
            bool115 = enableSystemAutoUpdate(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool115);
            return bool114;
          case 25:
            str1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool103;
            if (str1.readInt() != 0)
              null = true; 
            bool115 = enableDevMode(null);
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool115);
            return bool114;
          case 24:
            str1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool104;
            if (str1.readInt() != 0)
              null = true; 
            disallowFactoryReset_v3(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 23:
            str1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool105;
            if (str1.readInt() != 0)
              null = true; 
            disableFactoryReset(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 22:
            str1.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool115 = launchFactoryReset();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool115);
            return bool114;
          case 21:
            str1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool106;
            if (str1.readInt() != 0)
              null = true; 
            setSafeModeDisabled(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 20:
            str1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool107;
            if (str1.readInt() != 0)
              null = true; 
            enableCaptureScreen_v3(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 19:
            str1.enforceInterface("android.app.csdk.ICSDKManagerService");
            bitmap1 = captureScreen();
            param1Parcel2.writeNoException();
            if (bitmap1 != null) {
              param1Parcel2.writeInt(1);
              bitmap1.writeToParcel(param1Parcel2, 1);
              return bool114;
            } 
            param1Parcel2.writeInt(0);
            return bool114;
          case 18:
            bitmap1.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool115 = rebootDevice();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool115);
            return bool114;
          case 17:
            bitmap1.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool115 = wakeupDevice();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool115);
            return bool114;
          case 16:
            bitmap1.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool115 = sleepDevice();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool115);
            return bool114;
          case 15:
            bitmap1.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool115 = shutdownDevice();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool115);
            return bool114;
          case 14:
            bitmap1.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool115 = getCustomCHARGE();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool115);
            return bool114;
          case 13:
            bitmap1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool108;
            if (bitmap1.readInt() != 0)
              null = true; 
            setCustomCHARGE(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 12:
            bitmap1.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool115 = getCustomHARDRST();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool115);
            return bool114;
          case 11:
            bitmap1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool109;
            if (bitmap1.readInt() != 0)
              null = true; 
            setCustomHARDRST(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 10:
            bitmap1.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool115 = getCustomSDUPDATE();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool115);
            return bool114;
          case 9:
            bitmap1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool110;
            if (bitmap1.readInt() != 0)
              null = true; 
            setCustomSDUPDATE(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 8:
            bitmap1.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool115 = getCustomRecovery_v3();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool115);
            return bool114;
          case 7:
            bitmap1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool111;
            if (bitmap1.readInt() != 0)
              null = true; 
            setCustomRecovery_v3(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 6:
            bitmap1.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool115 = getCustomFASTBOOT();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool115);
            return bool114;
          case 5:
            bitmap1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool112;
            if (bitmap1.readInt() != 0)
              null = true; 
            setCustomFASTBOOT(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 4:
            bitmap1.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool115 = getCustomOTG();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool115);
            return bool114;
          case 3:
            bitmap1.enforceInterface("android.app.csdk.ICSDKManagerService");
            null = bool113;
            if (bitmap1.readInt() != 0)
              null = true; 
            setCustomOTG(null);
            param1Parcel2.writeNoException();
            return bool114;
          case 2:
            bitmap1.enforceInterface("android.app.csdk.ICSDKManagerService");
            bool115 = getCustomSplashPath();
            param1Parcel2.writeNoException();
            param1Parcel2.writeInt(bool115);
            return bool114;
          case 1:
            break;
        } 
        bitmap1.enforceInterface("android.app.csdk.ICSDKManagerService");
        setCustomSplashPath(bitmap1.readString());
        param1Parcel2.writeNoException();
        return bool114;
      } 
      param1Parcel2.writeString("android.app.csdk.ICSDKManagerService");
      return bool114;
    }
    
    private static class Proxy implements ICSDKManagerService {
      public static ICSDKManagerService sDefaultImpl;
      
      private IBinder mRemote;
      
      Proxy(IBinder param2IBinder) {
        this.mRemote = param2IBinder;
      }
      
      public List<String> APPIPWhiteListRead() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(227, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
            return ICSDKManagerService.Stub.getDefaultImpl().APPIPWhiteListRead(); 
          parcel2.readException();
          return parcel2.createStringArrayList();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean AddAppBlackRule(String param2String) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          if (!this.mRemote.transact(228, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().AddAppBlackRule(param2String);
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean AddAppWhiteRule(String param2String) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          if (!this.mRemote.transact(226, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().AddAppWhiteRule(param2String);
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean ClearAppRules() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(230, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().ClearAppRules();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean ClearIpHostRules() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(225, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().ClearIpHostRules();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean ClearRules() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(231, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().ClearRules();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean SetEnable(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(219, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().SetEnable(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean WriteToFile() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(232, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().WriteToFile();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean aCLK(String param2String1, String param2String2, String param2String3) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String1);
          parcel1.writeString(param2String2);
          parcel1.writeString(param2String3);
          if (!this.mRemote.transact(134, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().aCLK(param2String1, param2String2, param2String3);
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void activateLicense(String param2String1, String param2String2, String param2String3) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String1);
          parcel1.writeString(param2String2);
          parcel1.writeString(param2String3);
          if (!this.mRemote.transact(132, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().activateLicense(param2String1, param2String2, param2String3);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void addAppManageBlackList_v3(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeStringList(param2List);
          if (!this.mRemote.transact(50, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().addAppManageBlackList_v3(param2List);
            return;
          } 
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void addAppManageWhiteList_v3(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeStringList(param2List);
          if (!this.mRemote.transact(47, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().addAppManageWhiteList_v3(param2List);
            return;
          } 
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void addAutostartPackageBlackList(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeStringList(param2List);
          if (!this.mRemote.transact(75, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().addAutostartPackageBlackList(param2List);
            return;
          } 
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void addInstallPackageBlackList(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeStringList(param2List);
          if (!this.mRemote.transact(64, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().addInstallPackageBlackList(param2List);
            return;
          } 
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void addInstallPackageWhiteList(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeStringList(param2List);
          if (!this.mRemote.transact(61, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().addInstallPackageWhiteList(param2List);
            return;
          } 
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void addNetworkAccessBlacklist(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeStringList(param2List);
          if (!this.mRemote.transact(39, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().addNetworkAccessBlacklist(param2List);
            return;
          } 
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void addNetworkAccessWhitelist(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeStringList(param2List);
          if (!this.mRemote.transact(37, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().addNetworkAccessWhitelist(param2List);
            return;
          } 
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean addSSID(String param2String1, String param2String2, int param2Int, boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          boolean bool1;
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String1);
          parcel1.writeString(param2String2);
          parcel1.writeInt(param2Int);
          if (param2Boolean) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          parcel1.writeInt(bool1);
          if (!this.mRemote.transact(93, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().addSSID(param2String1, param2String2, param2Int, param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          param2Int = parcel2.readInt();
          if (param2Int != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void addUninstallPackageBlackList(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeStringList(param2List);
          if (!this.mRemote.transact(70, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().addUninstallPackageBlackList(param2List);
            return;
          } 
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void addUninstallPackageWhiteList(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeStringList(param2List);
          if (!this.mRemote.transact(67, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().addUninstallPackageWhiteList(param2List);
            return;
          } 
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void allowBluetooth(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(194, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().allowBluetooth(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean allowBluetoothDataTransfer(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(207, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().allowBluetoothDataTransfer(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void allowCamera(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(177, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().allowCamera(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void allowNavigaBar(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(182, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().allowNavigaBar(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void allowPowerKey(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(190, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().allowPowerKey(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void allowTFcard(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(175, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().allowTFcard(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void allowVolumeKey(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(192, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().allowVolumeKey(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean appWhiteListWrite(List<String> param2List) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeStringList(param2List);
          if (!this.mRemote.transact(233, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().appWhiteListWrite(param2List);
            return bool;
          } 
          parcel2.readException();
          if (parcel2.readInt() != 0)
            bool = true; 
          parcel2.readStringList(param2List);
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public IBinder asBinder() {
        return this.mRemote;
      }
      
      public Bitmap captureScreen() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          Bitmap bitmap;
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(19, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bitmap = ICSDKManagerService.Stub.getDefaultImpl().captureScreen();
            return bitmap;
          } 
          parcel2.readException();
          if (parcel2.readInt() != 0) {
            bitmap = (Bitmap)Bitmap.CREATOR.createFromParcel(parcel2);
          } else {
            bitmap = null;
          } 
          return bitmap;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void controlApp(String param2String, boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(209, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().controlApp(param2String, param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean deactivateLicense(String param2String1, String param2String2, String param2String3) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String1);
          parcel1.writeString(param2String2);
          parcel1.writeString(param2String3);
          if (!this.mRemote.transact(133, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().deactivateLicense(param2String1, param2String2, param2String3);
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void disableApplicationManage_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(58, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().disableApplicationManage_v3(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void disableAutostart(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(74, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().disableAutostart(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disableBluetooth(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(87, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().disableBluetooth(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void disableBluetoothShare(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(92, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().disableBluetoothShare(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disableCamera(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(29, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().disableCamera(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void disableFactoryReset(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(23, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().disableFactoryReset(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disableHiddenGame(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(147, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().disableHiddenGame(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void disableInstallation(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(56, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().disableInstallation(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disableLocation(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(31, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().disableLocation(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disableLockScreenNotification(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(127, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().disableLockScreenNotification(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void disableMultiUser(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(27, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().disableMultiUser(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void disableStatusBarNotification(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(126, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().disableStatusBarNotification(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disableStatusBarPanel(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(120, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().disableStatusBarPanel(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void disableTabletMasterAutostart(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(73, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().disableTabletMasterAutostart(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void disableUnInstallation(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(57, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().disableUnInstallation(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disableWifi(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(88, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().disableWifi(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disableWifiDirect(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(86, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().disableWifiDirect(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disallowAPN_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(96, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowAPN_v3(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disallowAirplaneMode_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(115, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowAirplaneMode_v3(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void disallowAutoDateAndTime_V3(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(166, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().disallowAutoDateAndTime_V3(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disallowBluetoothShare_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(108, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowBluetoothShare_v3(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disallowBluetooth_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(101, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowBluetooth_v3(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disallowData_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(106, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowData_v3(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void disallowFactoryReset_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(24, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().disallowFactoryReset_v3(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disallowLocation_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(118, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowLocation_v3(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disallowLockScreenMode_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(172, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowLockScreenMode_v3(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void disallowLockScreenNotification_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(152, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().disallowLockScreenNotification_v3(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void disallowMultiUser_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(28, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().disallowMultiUser_v3(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disallowSIMcard_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(98, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowSIMcard_v3(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void disallowSetAlarmVolume_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(160, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().disallowSetAlarmVolume_v3(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void disallowSetBootTime_V3(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(164, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().disallowSetBootTime_V3(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void disallowSetBrightness_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(161, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().disallowSetBrightness_v3(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void disallowSetInputMethod_v3(String param2String, boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(154, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().disallowSetInputMethod_v3(param2String, param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void disallowSetMediaVolume_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(156, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().disallowSetMediaVolume_v3(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void disallowSetNotificationVolume_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(158, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().disallowSetNotificationVolume_v3(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void disallowSetShutDownTime_V3(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(165, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().disallowSetShutDownTime_V3(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void disallowSetSleepTimeout_V3(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(163, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().disallowSetSleepTimeout_V3(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void disallowSetSysDate_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(139, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().disallowSetSysDate_v3(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void disallowSetSysTimeZone_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(141, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().disallowSetSysTimeZone_v3(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void disallowSetSysTime_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(137, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().disallowSetSysTime_v3(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void disallowSwitchLauncher_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(153, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().disallowSwitchLauncher_v3(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disallowUsbDebugging_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(170, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowUsbDebugging_v3(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disallowUsbMode_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(99, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowUsbMode_v3(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disallowWIFIAccessPoint_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(97, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowWIFIAccessPoint_v3(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disallowWifiDirect_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(100, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowWifiDirect_v3(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disallowWifiHotspot_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(110, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowWifiHotspot_v3(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disallowWifi_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(103, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowWifi_v3(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disallowWifiadvancesettings_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(105, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowWifiadvancesettings_v3(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disallowedBluetoothtethering_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(114, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowedBluetoothtethering_v3(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disallowedUSBtethering_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(112, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowedUSBtethering_v3(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void enableAirplaneMode(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(144, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().enableAirplaneMode(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void enableAllUnkownsources_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(174, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().enableAllUnkownsources_v3(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean enableAutoBrightness(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(142, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableAutoBrightness(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean enableBluetooth_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(102, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableBluetooth_v3(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean enableBluetoothtethering_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(113, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableBluetoothtethering_v3(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void enableCaptureScreen_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(20, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().enableCaptureScreen_v3(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean enableData(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(90, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableData(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean enableData_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(107, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableData_v3(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean enableDevMode(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(25, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableDevMode(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void enableDevMode_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(173, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().enableDevMode_v3(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean enableLocation_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(117, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableLocation_v3(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean enableMassStorage(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(91, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableMassStorage(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void enableNetworkAccess(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(41, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().enableNetworkAccess(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean enableSIM(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(89, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableSIM(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void enableSearch_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(171, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().enableSearch_v3(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean enableSystemAutoUpdate(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(26, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableSystemAutoUpdate(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean enableUSBtethering_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(111, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableUSBtethering_v3(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void enableUnkownsources_v3(String param2String, boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(169, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().enableUnkownsources_v3(param2String, param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean enableUsbDebugging(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(83, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableUsbDebugging(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean enableWIFIcaptive_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(116, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableWIFIcaptive_v3(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean enableWifiHotspot_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(109, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableWifiHotspot_v3(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean enableWifi_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(104, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableWifi_v3(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public List<String> forceStopPackageWhiteListRead() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(211, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
            return ICSDKManagerService.Stub.getDefaultImpl().forceStopPackageWhiteListRead(); 
          parcel2.readException();
          return parcel2.createStringArrayList();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean forceStopPackageWhiteListWrite(List<String> param2List) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeStringList(param2List);
          if (!this.mRemote.transact(210, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().forceStopPackageWhiteListWrite(param2List);
            return bool;
          } 
          parcel2.readException();
          if (parcel2.readInt() != 0)
            bool = true; 
          parcel2.readStringList(param2List);
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void fullScreenForever(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(125, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().fullScreenForever(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public List<String> getAppBlackRules() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(229, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
            return ICSDKManagerService.Stub.getDefaultImpl().getAppBlackRules(); 
          parcel2.readException();
          return parcel2.createStringArrayList();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public List<String> getAppManageBlackList_v3() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(51, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
            return ICSDKManagerService.Stub.getDefaultImpl().getAppManageBlackList_v3(); 
          parcel2.readException();
          return parcel2.createStringArrayList();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public List<String> getAppManageWhiteList_v3() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(48, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
            return ICSDKManagerService.Stub.getDefaultImpl().getAppManageWhiteList_v3(); 
          parcel2.readException();
          return parcel2.createStringArrayList();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public List<String> getAutostartPackageBlackList() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(76, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
            return ICSDKManagerService.Stub.getDefaultImpl().getAutostartPackageBlackList(); 
          parcel2.readException();
          return parcel2.createStringArrayList();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public String getBtStatus() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(203, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
            return ICSDKManagerService.Stub.getDefaultImpl().getBtStatus(); 
          parcel2.readException();
          return parcel2.readString();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean getCustomCHARGE() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(14, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().getCustomCHARGE();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean getCustomFASTBOOT() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(6, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().getCustomFASTBOOT();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean getCustomHARDRST() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(12, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().getCustomHARDRST();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean getCustomOTG() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(4, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().getCustomOTG();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean getCustomRecovery_v3() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(8, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().getCustomRecovery_v3();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean getCustomSDUPDATE() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(10, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().getCustomSDUPDATE();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean getCustomSplashPath() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(2, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().getCustomSplashPath();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public String getDeviceInfo(int param2Int) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeInt(param2Int);
          if (!this.mRemote.transact(32, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
            return ICSDKManagerService.Stub.getDefaultImpl().getDeviceInfo(param2Int); 
          parcel2.readException();
          return parcel2.readString();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public List<String> getDisplayBlacklist_v3() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(45, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
            return ICSDKManagerService.Stub.getDefaultImpl().getDisplayBlacklist_v3(); 
          parcel2.readException();
          return parcel2.createStringArrayList();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public List<String> getInstallPackageBlackList() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(65, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
            return ICSDKManagerService.Stub.getDefaultImpl().getInstallPackageBlackList(); 
          parcel2.readException();
          return parcel2.createStringArrayList();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public List<String> getInstallPackageWhiteList() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(62, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
            return ICSDKManagerService.Stub.getDefaultImpl().getInstallPackageWhiteList(); 
          parcel2.readException();
          return parcel2.createStringArrayList();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public String getInterfaceDescriptor() {
        return "android.app.csdk.ICSDKManagerService";
      }
      
      public Bitmap getMiaScreen() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          Bitmap bitmap;
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(213, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bitmap = ICSDKManagerService.Stub.getDefaultImpl().getMiaScreen();
            return bitmap;
          } 
          parcel2.readException();
          if (parcel2.readInt() != 0) {
            bitmap = (Bitmap)Bitmap.CREATOR.createFromParcel(parcel2);
          } else {
            bitmap = null;
          } 
          return bitmap;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public List<String> getNetworkAccessBlacklist() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(40, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
            return ICSDKManagerService.Stub.getDefaultImpl().getNetworkAccessBlacklist(); 
          parcel2.readException();
          return parcel2.createStringArrayList();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public List<String> getNetworkAccessWhitelist() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(38, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
            return ICSDKManagerService.Stub.getDefaultImpl().getNetworkAccessWhitelist(); 
          parcel2.readException();
          return parcel2.createStringArrayList();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public List<String> getUninstallPackageBlackList() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(71, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
            return ICSDKManagerService.Stub.getDefaultImpl().getUninstallPackageBlackList(); 
          parcel2.readException();
          return parcel2.createStringArrayList();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public List<String> getUninstallPackageWhiteList() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(68, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
            return ICSDKManagerService.Stub.getDefaultImpl().getUninstallPackageWhiteList(); 
          parcel2.readException();
          return parcel2.createStringArrayList();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public String getWifiStatus() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(204, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
            return ICSDKManagerService.Stub.getDefaultImpl().getWifiStatus(); 
          parcel2.readException();
          return parcel2.readString();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean hideBackSoftKey(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(121, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().hideBackSoftKey(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean hideHomeSoftKey(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(122, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().hideHomeSoftKey(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean hideMenuSoftKey(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(123, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().hideMenuSoftKey(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void hideNavigationBar(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(124, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().hideNavigationBar(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean hideStatusBar(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(119, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().hideStatusBar(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean hideUsbMenu(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(82, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().hideUsbMenu(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void installPackage(String param2String) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          if (!this.mRemote.transact(59, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().installPackage(param2String);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isBackKeyAllowed() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(187, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().isBackKeyAllowed();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isBluetoothAllowed() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(195, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().isBluetoothAllowed();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isBluetoothDataTransferAllowed() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(208, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().isBluetoothDataTransferAllowed();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isCameraAllowed() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(178, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().isCameraAllowed();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isEnable() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(220, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().isEnable();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isHomeKeyAllowed() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(188, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().isHomeKeyAllowed();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isLicenseKeyEnabled(String param2String) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          if (!this.mRemote.transact(135, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().isLicenseKeyEnabled(param2String);
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isLocationAllowed() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(197, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().isLocationAllowed();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isNavigaBarAllowed() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(186, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().isNavigaBarAllowed();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isNetworkRulesEnabled() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(42, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().isNetworkRulesEnabled();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isPowerKeyAllowed() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(191, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().isPowerKeyAllowed();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isRecentKeyAllowed() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(189, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().isRecentKeyAllowed();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isTFcardAllowed() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(176, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().isTFcardAllowed();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isUsbOnlyCharging() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(199, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().isUsbOnlyCharging();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean isVolumeKeyAllowed() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(193, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().isVolumeKeyAllowed();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean killApp(String param2String) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          if (!this.mRemote.transact(181, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().killApp(param2String);
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void killApplicationProcess(String param2String) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          if (!this.mRemote.transact(206, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().killApplicationProcess(param2String);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean launchFactoryReset() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(22, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().launchFactoryReset();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void masterClearInbulitSD() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(205, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().masterClearInbulitSD();
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean mobileData(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(218, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().mobileData(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void putSettingsValue(int param2Int1, int param2Int2, String param2String1, String param2String2) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeInt(param2Int1);
          parcel1.writeInt(param2Int2);
          parcel1.writeString(param2String1);
          parcel1.writeString(param2String2);
          if (!this.mRemote.transact(168, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().putSettingsValue(param2Int1, param2Int2, param2String1, param2String2);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean rebootDevice() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(18, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().rebootDevice();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean releaseKeyControl() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(35, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().releaseKeyControl();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void removeAppManageBlackList_v3(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeStringList(param2List);
          if (!this.mRemote.transact(52, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().removeAppManageBlackList_v3(param2List);
            return;
          } 
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void removeAppManageWhiteList_v3(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeStringList(param2List);
          if (!this.mRemote.transact(49, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().removeAppManageWhiteList_v3(param2List);
            return;
          } 
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void removeAutostartPackageBlackList(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeStringList(param2List);
          if (!this.mRemote.transact(77, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().removeAutostartPackageBlackList(param2List);
            return;
          } 
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void removeDeviceOwner(String param2String) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          if (!this.mRemote.transact(80, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().removeDeviceOwner(param2String);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void removeDisplayBlacklist_v3(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeStringList(param2List);
          if (!this.mRemote.transact(46, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().removeDisplayBlacklist_v3(param2List);
            return;
          } 
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void removeInstallPackageBlackList(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeStringList(param2List);
          if (!this.mRemote.transact(66, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().removeInstallPackageBlackList(param2List);
            return;
          } 
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void removeInstallPackageWhiteList(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeStringList(param2List);
          if (!this.mRemote.transact(63, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().removeInstallPackageWhiteList(param2List);
            return;
          } 
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void removeNetworkAccessWhitelist(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeStringList(param2List);
          if (!this.mRemote.transact(36, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().removeNetworkAccessWhitelist(param2List);
            return;
          } 
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void removeUninstallPackageBlackList(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeStringList(param2List);
          if (!this.mRemote.transact(72, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().removeUninstallPackageBlackList(param2List);
            return;
          } 
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void removeUninstallPackageWhiteList(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeStringList(param2List);
          if (!this.mRemote.transact(69, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().removeUninstallPackageWhiteList(param2List);
            return;
          } 
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean requestKeyControl(int param2Int) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeInt(param2Int);
          if (!this.mRemote.transact(33, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().requestKeyControl(param2Int);
            return bool;
          } 
          parcel2.readException();
          param2Int = parcel2.readInt();
          if (param2Int != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean requestKeyControl_V3(int param2Int, boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          boolean bool1;
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeInt(param2Int);
          if (param2Boolean) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          parcel1.writeInt(bool1);
          if (!this.mRemote.transact(34, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().requestKeyControl_V3(param2Int, param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          param2Int = parcel2.readInt();
          if (param2Int != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setAlarmVolumeValue_v3(int param2Int) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeInt(param2Int);
          if (!this.mRemote.transact(159, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setAlarmVolumeValue_v3(param2Int);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setAppOpsPermissions(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(55, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setAppOpsPermissions(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setBackKey(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(183, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setBackKey(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setBootTime(boolean param2Boolean, int param2Int1, int param2Int2, int param2Int3, long param2Long) throws RemoteException {
        Exception exception;
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          try {
            parcel1.writeInt(param2Int1);
            try {
              parcel1.writeInt(param2Int2);
              try {
                parcel1.writeInt(param2Int3);
                try {
                  parcel1.writeLong(param2Long);
                  try {
                    if (!this.mRemote.transact(145, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
                      ICSDKManagerService.Stub.getDefaultImpl().setBootTime(param2Boolean, param2Int1, param2Int2, param2Int3, param2Long);
                      parcel2.recycle();
                      parcel1.recycle();
                      return;
                    } 
                    parcel2.readException();
                    parcel2.recycle();
                    parcel1.recycle();
                    return;
                  } finally {}
                } finally {}
              } finally {}
            } finally {}
          } finally {}
        } finally {}
        parcel2.recycle();
        parcel1.recycle();
        throw exception;
      }
      
      public boolean setBrightness(int param2Int) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeInt(param2Int);
          if (!this.mRemote.transact(143, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().setBrightness(param2Int);
            return bool;
          } 
          parcel2.readException();
          param2Int = parcel2.readInt();
          if (param2Int != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setComponentEnabled(ComponentName param2ComponentName, int param2Int1, int param2Int2) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2ComponentName != null) {
            parcel1.writeInt(1);
            param2ComponentName.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          parcel1.writeInt(param2Int1);
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
        parcel2.readException();
        parcel2.recycle();
        parcel1.recycle();
      }
      
      public void setCurrentUsbMode(int param2Int) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeInt(param2Int);
          if (!this.mRemote.transact(84, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setCurrentUsbMode(param2Int);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean setCustomBootAnim(String param2String) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          if (!this.mRemote.transact(128, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().setCustomBootAnim(param2String);
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setCustomCHARGE(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(13, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setCustomCHARGE(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setCustomFASTBOOT(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(5, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setCustomFASTBOOT(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setCustomHARDRST(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(11, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setCustomHARDRST(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setCustomLauncher(String param2String1, String param2String2) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String1);
          parcel1.writeString(param2String2);
          if (!this.mRemote.transact(131, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setCustomLauncher(param2String1, param2String2);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setCustomOTG(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(3, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setCustomOTG(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setCustomRecovery_v3(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(7, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setCustomRecovery_v3(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setCustomSDUPDATE(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(9, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setCustomSDUPDATE(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean setCustomShutAnim(String param2String) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          if (!this.mRemote.transact(129, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().setCustomShutAnim(param2String);
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setCustomSplashPath(String param2String) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          if (!this.mRemote.transact(1, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setCustomSplashPath(param2String);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean setDefaultAPN_v3(String param2String) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          if (!this.mRemote.transact(95, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().setDefaultAPN_v3(param2String);
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean setDefaultInputMethod(String param2String) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          if (!this.mRemote.transact(151, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().setDefaultInputMethod(param2String);
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setDefaultUsbMode(int param2Int) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeInt(param2Int);
          if (!this.mRemote.transact(85, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setDefaultUsbMode(param2Int);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean setDeviceOwner(String param2String) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          if (!this.mRemote.transact(79, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().setDeviceOwner(param2String);
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean setDisplayBlacklist(List<String> param2List, boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          boolean bool1;
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeStringList(param2List);
          if (param2Boolean) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          parcel1.writeInt(bool1);
          if (!this.mRemote.transact(43, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().setDisplayBlacklist(param2List, param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          if (parcel2.readInt() != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          parcel2.readStringList(param2List);
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setDisplayBlacklist_v3(List<String> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeStringList(param2List);
          if (!this.mRemote.transact(44, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setDisplayBlacklist_v3(param2List);
            return;
          } 
          parcel2.readException();
          parcel2.readStringList(param2List);
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setGps(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(196, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setGps(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setHomeKey(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(184, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setHomeKey(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean setHttpProxy(String param2String, int param2Int, List<String> param2List) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          parcel1.writeInt(param2Int);
          parcel1.writeStringList(param2List);
          if (!this.mRemote.transact(94, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().setHttpProxy(param2String, param2Int, param2List);
            return bool;
          } 
          parcel2.readException();
          if (parcel2.readInt() != 0)
            bool = true; 
          parcel2.readStringList(param2List);
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean setLauncher(String param2String) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          if (!this.mRemote.transact(130, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().setLauncher(param2String);
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean setLocationMode(int param2Int) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeInt(param2Int);
          if (!this.mRemote.transact(148, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().setLocationMode(param2Int);
            return bool;
          } 
          parcel2.readException();
          param2Int = parcel2.readInt();
          if (param2Int != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setLockNone() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(149, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setLockNone();
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean setLockPassword(String param2String) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          if (!this.mRemote.transact(202, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().setLockPassword(param2String);
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setLockSwipe() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(150, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setLockSwipe();
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setMediaVolumeValue_v3(int param2Int) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeInt(param2Int);
          if (!this.mRemote.transact(155, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setMediaVolumeValue_v3(param2Int);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setNotificationVolumeValue_v3(int param2Int) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeInt(param2Int);
          if (!this.mRemote.transact(157, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setNotificationVolumeValue_v3(param2Int);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setOTG(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(212, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setOTG(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setPackageEnabled(String param2String, boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(81, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setPackageEnabled(param2String, param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setPersistValue(String param2String1, String param2String2) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String1);
          parcel1.writeString(param2String2);
          if (!this.mRemote.transact(167, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setPersistValue(param2String1, param2String2);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setPowerLongPressKey(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(214, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setPowerLongPressKey(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setPowerSingleClickKey(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(215, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setPowerSingleClickKey(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setRecentKey(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(185, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setRecentKey(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setRuntimePermissions(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(53, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setRuntimePermissions(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setSafeModeDisabled(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(21, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setSafeModeDisabled(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setShutDownTime(boolean param2Boolean, int param2Int1, int param2Int2, int param2Int3, long param2Long) throws RemoteException {
        Exception exception;
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          try {
            parcel1.writeInt(param2Int1);
            try {
              parcel1.writeInt(param2Int2);
              try {
                parcel1.writeInt(param2Int3);
                try {
                  parcel1.writeLong(param2Long);
                  try {
                    if (!this.mRemote.transact(146, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
                      ICSDKManagerService.Stub.getDefaultImpl().setShutDownTime(param2Boolean, param2Int1, param2Int2, param2Int3, param2Long);
                      parcel2.recycle();
                      parcel1.recycle();
                      return;
                    } 
                    parcel2.readException();
                    parcel2.recycle();
                    parcel1.recycle();
                    return;
                  } finally {}
                } finally {}
              } finally {}
            } finally {}
          } finally {}
        } finally {}
        parcel2.recycle();
        parcel1.recycle();
        throw exception;
      }
      
      public void setSleepTimeout_V3(int param2Int) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeInt(param2Int);
          if (!this.mRemote.transact(162, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setSleepTimeout_V3(param2Int);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setSysDate(int param2Int1, int param2Int2, int param2Int3) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeInt(param2Int1);
          parcel1.writeInt(param2Int2);
          parcel1.writeInt(param2Int3);
          if (!this.mRemote.transact(138, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setSysDate(param2Int1, param2Int2, param2Int3);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setSysTime(long param2Long) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeLong(param2Long);
          if (!this.mRemote.transact(136, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setSysTime(param2Long);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setTimeZone_v3(String param2String) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          if (!this.mRemote.transact(140, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setTimeZone_v3(param2String);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean setUsbOnlyCharging(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean) {
            i = 1;
          } else {
            i = 0;
          } 
          parcel1.writeInt(i);
          if (!this.mRemote.transact(198, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            param2Boolean = ICSDKManagerService.Stub.getDefaultImpl().setUsbOnlyCharging(param2Boolean);
            return param2Boolean;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0) {
            param2Boolean = bool;
          } else {
            param2Boolean = false;
          } 
          return param2Boolean;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setUserRestriction(String param2String, boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(30, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setUserRestriction(param2String, param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setVolumedownKey(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(216, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setVolumedownKey(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void setVolumeupKey(boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(217, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().setVolumeupKey(param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean setlockInputMethod(String param2String) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          if (!this.mRemote.transact(54, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().setlockInputMethod(param2String);
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean shutdownDevice() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(15, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().shutdownDevice();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void silentInstall(String param2String) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          if (!this.mRemote.transact(180, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().silentInstall(param2String);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void silentUnInstall(String param2String) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          if (!this.mRemote.transact(179, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().silentUnInstall(param2String);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean sleepDevice() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(16, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().sleepDevice();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void uninstallPackage(String param2String, boolean param2Boolean) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          if (param2Boolean)
            bool = true; 
          parcel1.writeInt(bool);
          if (!this.mRemote.transact(60, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().uninstallPackage(param2String, param2Boolean);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void unlockScreen() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(201, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            ICSDKManagerService.Stub.getDefaultImpl().unlockScreen();
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean updateSystemTime(String param2String) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeString(param2String);
          if (!this.mRemote.transact(200, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().updateSystemTime(param2String);
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public List<String> urlBlackListRead() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(224, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
            return ICSDKManagerService.Stub.getDefaultImpl().urlBlackListRead(); 
          parcel2.readException();
          return parcel2.createStringArrayList();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean urlBlackListWrite(List<String> param2List) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeStringList(param2List);
          if (!this.mRemote.transact(223, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().urlBlackListWrite(param2List);
            return bool;
          } 
          parcel2.readException();
          if (parcel2.readInt() != 0)
            bool = true; 
          parcel2.readStringList(param2List);
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public List<String> urlWhiteListRead() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(222, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
            return ICSDKManagerService.Stub.getDefaultImpl().urlWhiteListRead(); 
          parcel2.readException();
          return parcel2.createStringArrayList();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean urlWhiteListWrite(List<String> param2List) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          parcel1.writeStringList(param2List);
          if (!this.mRemote.transact(221, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().urlWhiteListWrite(param2List);
            return bool;
          } 
          parcel2.readException();
          if (parcel2.readInt() != 0)
            bool = true; 
          parcel2.readStringList(param2List);
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean wakeupDevice() throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
          if (!this.mRemote.transact(17, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
            bool = ICSDKManagerService.Stub.getDefaultImpl().wakeupDevice();
            return bool;
          } 
          parcel2.readException();
          int i = parcel2.readInt();
          if (i != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
    }
  }
  
  private static class Proxy implements ICSDKManagerService {
    public static ICSDKManagerService sDefaultImpl;
    
    private IBinder mRemote;
    
    Proxy(IBinder param1IBinder) {
      this.mRemote = param1IBinder;
    }
    
    public List<String> APPIPWhiteListRead() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(227, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
          return ICSDKManagerService.Stub.getDefaultImpl().APPIPWhiteListRead(); 
        parcel2.readException();
        return parcel2.createStringArrayList();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean AddAppBlackRule(String param1String) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        if (!this.mRemote.transact(228, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().AddAppBlackRule(param1String);
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean AddAppWhiteRule(String param1String) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        if (!this.mRemote.transact(226, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().AddAppWhiteRule(param1String);
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean ClearAppRules() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(230, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().ClearAppRules();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean ClearIpHostRules() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(225, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().ClearIpHostRules();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean ClearRules() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(231, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().ClearRules();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean SetEnable(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(219, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().SetEnable(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean WriteToFile() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(232, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().WriteToFile();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean aCLK(String param1String1, String param1String2, String param1String3) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String1);
        parcel1.writeString(param1String2);
        parcel1.writeString(param1String3);
        if (!this.mRemote.transact(134, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().aCLK(param1String1, param1String2, param1String3);
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void activateLicense(String param1String1, String param1String2, String param1String3) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String1);
        parcel1.writeString(param1String2);
        parcel1.writeString(param1String3);
        if (!this.mRemote.transact(132, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().activateLicense(param1String1, param1String2, param1String3);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void addAppManageBlackList_v3(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeStringList(param1List);
        if (!this.mRemote.transact(50, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().addAppManageBlackList_v3(param1List);
          return;
        } 
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void addAppManageWhiteList_v3(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeStringList(param1List);
        if (!this.mRemote.transact(47, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().addAppManageWhiteList_v3(param1List);
          return;
        } 
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void addAutostartPackageBlackList(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeStringList(param1List);
        if (!this.mRemote.transact(75, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().addAutostartPackageBlackList(param1List);
          return;
        } 
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void addInstallPackageBlackList(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeStringList(param1List);
        if (!this.mRemote.transact(64, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().addInstallPackageBlackList(param1List);
          return;
        } 
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void addInstallPackageWhiteList(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeStringList(param1List);
        if (!this.mRemote.transact(61, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().addInstallPackageWhiteList(param1List);
          return;
        } 
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void addNetworkAccessBlacklist(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeStringList(param1List);
        if (!this.mRemote.transact(39, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().addNetworkAccessBlacklist(param1List);
          return;
        } 
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void addNetworkAccessWhitelist(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeStringList(param1List);
        if (!this.mRemote.transact(37, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().addNetworkAccessWhitelist(param1List);
          return;
        } 
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean addSSID(String param1String1, String param1String2, int param1Int, boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        boolean bool1;
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String1);
        parcel1.writeString(param1String2);
        parcel1.writeInt(param1Int);
        if (param1Boolean) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        parcel1.writeInt(bool1);
        if (!this.mRemote.transact(93, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().addSSID(param1String1, param1String2, param1Int, param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        param1Int = parcel2.readInt();
        if (param1Int != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void addUninstallPackageBlackList(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeStringList(param1List);
        if (!this.mRemote.transact(70, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().addUninstallPackageBlackList(param1List);
          return;
        } 
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void addUninstallPackageWhiteList(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeStringList(param1List);
        if (!this.mRemote.transact(67, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().addUninstallPackageWhiteList(param1List);
          return;
        } 
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void allowBluetooth(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(194, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().allowBluetooth(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean allowBluetoothDataTransfer(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(207, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().allowBluetoothDataTransfer(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void allowCamera(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(177, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().allowCamera(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void allowNavigaBar(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(182, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().allowNavigaBar(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void allowPowerKey(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(190, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().allowPowerKey(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void allowTFcard(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(175, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().allowTFcard(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void allowVolumeKey(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(192, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().allowVolumeKey(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean appWhiteListWrite(List<String> param1List) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeStringList(param1List);
        if (!this.mRemote.transact(233, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().appWhiteListWrite(param1List);
          return bool;
        } 
        parcel2.readException();
        if (parcel2.readInt() != 0)
          bool = true; 
        parcel2.readStringList(param1List);
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public IBinder asBinder() {
      return this.mRemote;
    }
    
    public Bitmap captureScreen() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        Bitmap bitmap;
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(19, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bitmap = ICSDKManagerService.Stub.getDefaultImpl().captureScreen();
          return bitmap;
        } 
        parcel2.readException();
        if (parcel2.readInt() != 0) {
          bitmap = (Bitmap)Bitmap.CREATOR.createFromParcel(parcel2);
        } else {
          bitmap = null;
        } 
        return bitmap;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void controlApp(String param1String, boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(209, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().controlApp(param1String, param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean deactivateLicense(String param1String1, String param1String2, String param1String3) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String1);
        parcel1.writeString(param1String2);
        parcel1.writeString(param1String3);
        if (!this.mRemote.transact(133, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().deactivateLicense(param1String1, param1String2, param1String3);
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void disableApplicationManage_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(58, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().disableApplicationManage_v3(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void disableAutostart(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(74, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().disableAutostart(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disableBluetooth(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(87, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().disableBluetooth(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void disableBluetoothShare(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(92, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().disableBluetoothShare(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disableCamera(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(29, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().disableCamera(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void disableFactoryReset(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(23, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().disableFactoryReset(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disableHiddenGame(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(147, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().disableHiddenGame(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void disableInstallation(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(56, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().disableInstallation(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disableLocation(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(31, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().disableLocation(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disableLockScreenNotification(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(127, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().disableLockScreenNotification(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void disableMultiUser(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(27, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().disableMultiUser(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void disableStatusBarNotification(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(126, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().disableStatusBarNotification(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disableStatusBarPanel(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(120, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().disableStatusBarPanel(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void disableTabletMasterAutostart(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(73, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().disableTabletMasterAutostart(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void disableUnInstallation(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(57, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().disableUnInstallation(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disableWifi(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(88, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().disableWifi(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disableWifiDirect(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(86, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().disableWifiDirect(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disallowAPN_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(96, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowAPN_v3(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disallowAirplaneMode_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(115, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowAirplaneMode_v3(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void disallowAutoDateAndTime_V3(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(166, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().disallowAutoDateAndTime_V3(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disallowBluetoothShare_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(108, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowBluetoothShare_v3(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disallowBluetooth_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(101, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowBluetooth_v3(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disallowData_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(106, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowData_v3(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void disallowFactoryReset_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(24, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().disallowFactoryReset_v3(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disallowLocation_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(118, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowLocation_v3(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disallowLockScreenMode_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(172, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowLockScreenMode_v3(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void disallowLockScreenNotification_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(152, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().disallowLockScreenNotification_v3(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void disallowMultiUser_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(28, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().disallowMultiUser_v3(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disallowSIMcard_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(98, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowSIMcard_v3(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void disallowSetAlarmVolume_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(160, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().disallowSetAlarmVolume_v3(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void disallowSetBootTime_V3(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(164, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().disallowSetBootTime_V3(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void disallowSetBrightness_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(161, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().disallowSetBrightness_v3(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void disallowSetInputMethod_v3(String param1String, boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(154, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().disallowSetInputMethod_v3(param1String, param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void disallowSetMediaVolume_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(156, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().disallowSetMediaVolume_v3(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void disallowSetNotificationVolume_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(158, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().disallowSetNotificationVolume_v3(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void disallowSetShutDownTime_V3(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(165, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().disallowSetShutDownTime_V3(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void disallowSetSleepTimeout_V3(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(163, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().disallowSetSleepTimeout_V3(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void disallowSetSysDate_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(139, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().disallowSetSysDate_v3(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void disallowSetSysTimeZone_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(141, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().disallowSetSysTimeZone_v3(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void disallowSetSysTime_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(137, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().disallowSetSysTime_v3(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void disallowSwitchLauncher_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(153, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().disallowSwitchLauncher_v3(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disallowUsbDebugging_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(170, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowUsbDebugging_v3(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disallowUsbMode_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(99, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowUsbMode_v3(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disallowWIFIAccessPoint_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(97, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowWIFIAccessPoint_v3(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disallowWifiDirect_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(100, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowWifiDirect_v3(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disallowWifiHotspot_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(110, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowWifiHotspot_v3(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disallowWifi_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(103, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowWifi_v3(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disallowWifiadvancesettings_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(105, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowWifiadvancesettings_v3(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disallowedBluetoothtethering_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(114, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowedBluetoothtethering_v3(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disallowedUSBtethering_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(112, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().disallowedUSBtethering_v3(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void enableAirplaneMode(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(144, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().enableAirplaneMode(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void enableAllUnkownsources_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(174, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().enableAllUnkownsources_v3(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean enableAutoBrightness(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(142, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableAutoBrightness(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean enableBluetooth_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(102, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableBluetooth_v3(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean enableBluetoothtethering_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(113, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableBluetoothtethering_v3(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void enableCaptureScreen_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(20, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().enableCaptureScreen_v3(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean enableData(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(90, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableData(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean enableData_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(107, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableData_v3(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean enableDevMode(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(25, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableDevMode(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void enableDevMode_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(173, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().enableDevMode_v3(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean enableLocation_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(117, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableLocation_v3(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean enableMassStorage(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(91, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableMassStorage(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void enableNetworkAccess(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(41, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().enableNetworkAccess(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean enableSIM(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(89, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableSIM(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void enableSearch_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(171, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().enableSearch_v3(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean enableSystemAutoUpdate(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(26, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableSystemAutoUpdate(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean enableUSBtethering_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(111, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableUSBtethering_v3(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void enableUnkownsources_v3(String param1String, boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(169, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().enableUnkownsources_v3(param1String, param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean enableUsbDebugging(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(83, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableUsbDebugging(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean enableWIFIcaptive_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(116, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableWIFIcaptive_v3(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean enableWifiHotspot_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(109, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableWifiHotspot_v3(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean enableWifi_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(104, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().enableWifi_v3(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public List<String> forceStopPackageWhiteListRead() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(211, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
          return ICSDKManagerService.Stub.getDefaultImpl().forceStopPackageWhiteListRead(); 
        parcel2.readException();
        return parcel2.createStringArrayList();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean forceStopPackageWhiteListWrite(List<String> param1List) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeStringList(param1List);
        if (!this.mRemote.transact(210, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().forceStopPackageWhiteListWrite(param1List);
          return bool;
        } 
        parcel2.readException();
        if (parcel2.readInt() != 0)
          bool = true; 
        parcel2.readStringList(param1List);
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void fullScreenForever(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(125, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().fullScreenForever(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public List<String> getAppBlackRules() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(229, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
          return ICSDKManagerService.Stub.getDefaultImpl().getAppBlackRules(); 
        parcel2.readException();
        return parcel2.createStringArrayList();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public List<String> getAppManageBlackList_v3() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(51, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
          return ICSDKManagerService.Stub.getDefaultImpl().getAppManageBlackList_v3(); 
        parcel2.readException();
        return parcel2.createStringArrayList();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public List<String> getAppManageWhiteList_v3() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(48, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
          return ICSDKManagerService.Stub.getDefaultImpl().getAppManageWhiteList_v3(); 
        parcel2.readException();
        return parcel2.createStringArrayList();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public List<String> getAutostartPackageBlackList() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(76, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
          return ICSDKManagerService.Stub.getDefaultImpl().getAutostartPackageBlackList(); 
        parcel2.readException();
        return parcel2.createStringArrayList();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public String getBtStatus() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(203, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
          return ICSDKManagerService.Stub.getDefaultImpl().getBtStatus(); 
        parcel2.readException();
        return parcel2.readString();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean getCustomCHARGE() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(14, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().getCustomCHARGE();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean getCustomFASTBOOT() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(6, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().getCustomFASTBOOT();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean getCustomHARDRST() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(12, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().getCustomHARDRST();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean getCustomOTG() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(4, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().getCustomOTG();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean getCustomRecovery_v3() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(8, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().getCustomRecovery_v3();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean getCustomSDUPDATE() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(10, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().getCustomSDUPDATE();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean getCustomSplashPath() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(2, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().getCustomSplashPath();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public String getDeviceInfo(int param1Int) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeInt(param1Int);
        if (!this.mRemote.transact(32, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
          return ICSDKManagerService.Stub.getDefaultImpl().getDeviceInfo(param1Int); 
        parcel2.readException();
        return parcel2.readString();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public List<String> getDisplayBlacklist_v3() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(45, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
          return ICSDKManagerService.Stub.getDefaultImpl().getDisplayBlacklist_v3(); 
        parcel2.readException();
        return parcel2.createStringArrayList();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public List<String> getInstallPackageBlackList() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(65, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
          return ICSDKManagerService.Stub.getDefaultImpl().getInstallPackageBlackList(); 
        parcel2.readException();
        return parcel2.createStringArrayList();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public List<String> getInstallPackageWhiteList() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(62, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
          return ICSDKManagerService.Stub.getDefaultImpl().getInstallPackageWhiteList(); 
        parcel2.readException();
        return parcel2.createStringArrayList();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public String getInterfaceDescriptor() {
      return "android.app.csdk.ICSDKManagerService";
    }
    
    public Bitmap getMiaScreen() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        Bitmap bitmap;
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(213, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bitmap = ICSDKManagerService.Stub.getDefaultImpl().getMiaScreen();
          return bitmap;
        } 
        parcel2.readException();
        if (parcel2.readInt() != 0) {
          bitmap = (Bitmap)Bitmap.CREATOR.createFromParcel(parcel2);
        } else {
          bitmap = null;
        } 
        return bitmap;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public List<String> getNetworkAccessBlacklist() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(40, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
          return ICSDKManagerService.Stub.getDefaultImpl().getNetworkAccessBlacklist(); 
        parcel2.readException();
        return parcel2.createStringArrayList();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public List<String> getNetworkAccessWhitelist() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(38, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
          return ICSDKManagerService.Stub.getDefaultImpl().getNetworkAccessWhitelist(); 
        parcel2.readException();
        return parcel2.createStringArrayList();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public List<String> getUninstallPackageBlackList() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(71, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
          return ICSDKManagerService.Stub.getDefaultImpl().getUninstallPackageBlackList(); 
        parcel2.readException();
        return parcel2.createStringArrayList();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public List<String> getUninstallPackageWhiteList() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(68, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
          return ICSDKManagerService.Stub.getDefaultImpl().getUninstallPackageWhiteList(); 
        parcel2.readException();
        return parcel2.createStringArrayList();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public String getWifiStatus() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(204, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
          return ICSDKManagerService.Stub.getDefaultImpl().getWifiStatus(); 
        parcel2.readException();
        return parcel2.readString();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean hideBackSoftKey(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(121, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().hideBackSoftKey(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean hideHomeSoftKey(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(122, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().hideHomeSoftKey(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean hideMenuSoftKey(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(123, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().hideMenuSoftKey(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void hideNavigationBar(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(124, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().hideNavigationBar(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean hideStatusBar(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(119, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().hideStatusBar(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean hideUsbMenu(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(82, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().hideUsbMenu(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void installPackage(String param1String) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        if (!this.mRemote.transact(59, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().installPackage(param1String);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isBackKeyAllowed() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(187, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().isBackKeyAllowed();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isBluetoothAllowed() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(195, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().isBluetoothAllowed();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isBluetoothDataTransferAllowed() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(208, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().isBluetoothDataTransferAllowed();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isCameraAllowed() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(178, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().isCameraAllowed();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isEnable() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(220, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().isEnable();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isHomeKeyAllowed() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(188, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().isHomeKeyAllowed();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isLicenseKeyEnabled(String param1String) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        if (!this.mRemote.transact(135, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().isLicenseKeyEnabled(param1String);
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isLocationAllowed() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(197, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().isLocationAllowed();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isNavigaBarAllowed() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(186, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().isNavigaBarAllowed();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isNetworkRulesEnabled() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(42, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().isNetworkRulesEnabled();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isPowerKeyAllowed() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(191, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().isPowerKeyAllowed();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isRecentKeyAllowed() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(189, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().isRecentKeyAllowed();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isTFcardAllowed() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(176, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().isTFcardAllowed();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isUsbOnlyCharging() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(199, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().isUsbOnlyCharging();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean isVolumeKeyAllowed() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(193, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().isVolumeKeyAllowed();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean killApp(String param1String) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        if (!this.mRemote.transact(181, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().killApp(param1String);
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void killApplicationProcess(String param1String) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        if (!this.mRemote.transact(206, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().killApplicationProcess(param1String);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean launchFactoryReset() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(22, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().launchFactoryReset();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void masterClearInbulitSD() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(205, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().masterClearInbulitSD();
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean mobileData(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(218, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().mobileData(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void putSettingsValue(int param1Int1, int param1Int2, String param1String1, String param1String2) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeInt(param1Int1);
        parcel1.writeInt(param1Int2);
        parcel1.writeString(param1String1);
        parcel1.writeString(param1String2);
        if (!this.mRemote.transact(168, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().putSettingsValue(param1Int1, param1Int2, param1String1, param1String2);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean rebootDevice() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(18, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().rebootDevice();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean releaseKeyControl() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(35, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().releaseKeyControl();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void removeAppManageBlackList_v3(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeStringList(param1List);
        if (!this.mRemote.transact(52, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().removeAppManageBlackList_v3(param1List);
          return;
        } 
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void removeAppManageWhiteList_v3(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeStringList(param1List);
        if (!this.mRemote.transact(49, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().removeAppManageWhiteList_v3(param1List);
          return;
        } 
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void removeAutostartPackageBlackList(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeStringList(param1List);
        if (!this.mRemote.transact(77, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().removeAutostartPackageBlackList(param1List);
          return;
        } 
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void removeDeviceOwner(String param1String) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        if (!this.mRemote.transact(80, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().removeDeviceOwner(param1String);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void removeDisplayBlacklist_v3(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeStringList(param1List);
        if (!this.mRemote.transact(46, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().removeDisplayBlacklist_v3(param1List);
          return;
        } 
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void removeInstallPackageBlackList(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeStringList(param1List);
        if (!this.mRemote.transact(66, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().removeInstallPackageBlackList(param1List);
          return;
        } 
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void removeInstallPackageWhiteList(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeStringList(param1List);
        if (!this.mRemote.transact(63, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().removeInstallPackageWhiteList(param1List);
          return;
        } 
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void removeNetworkAccessWhitelist(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeStringList(param1List);
        if (!this.mRemote.transact(36, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().removeNetworkAccessWhitelist(param1List);
          return;
        } 
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void removeUninstallPackageBlackList(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeStringList(param1List);
        if (!this.mRemote.transact(72, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().removeUninstallPackageBlackList(param1List);
          return;
        } 
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void removeUninstallPackageWhiteList(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeStringList(param1List);
        if (!this.mRemote.transact(69, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().removeUninstallPackageWhiteList(param1List);
          return;
        } 
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean requestKeyControl(int param1Int) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeInt(param1Int);
        if (!this.mRemote.transact(33, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().requestKeyControl(param1Int);
          return bool;
        } 
        parcel2.readException();
        param1Int = parcel2.readInt();
        if (param1Int != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean requestKeyControl_V3(int param1Int, boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        boolean bool1;
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeInt(param1Int);
        if (param1Boolean) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        parcel1.writeInt(bool1);
        if (!this.mRemote.transact(34, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().requestKeyControl_V3(param1Int, param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        param1Int = parcel2.readInt();
        if (param1Int != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setAlarmVolumeValue_v3(int param1Int) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeInt(param1Int);
        if (!this.mRemote.transact(159, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setAlarmVolumeValue_v3(param1Int);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setAppOpsPermissions(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(55, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setAppOpsPermissions(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setBackKey(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(183, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setBackKey(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setBootTime(boolean param1Boolean, int param1Int1, int param1Int2, int param1Int3, long param1Long) throws RemoteException {
      Exception exception;
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        try {
          parcel1.writeInt(param1Int1);
          try {
            parcel1.writeInt(param1Int2);
            try {
              parcel1.writeInt(param1Int3);
              try {
                parcel1.writeLong(param1Long);
                try {
                  if (!this.mRemote.transact(145, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
                    ICSDKManagerService.Stub.getDefaultImpl().setBootTime(param1Boolean, param1Int1, param1Int2, param1Int3, param1Long);
                    parcel2.recycle();
                    parcel1.recycle();
                    return;
                  } 
                  parcel2.readException();
                  parcel2.recycle();
                  parcel1.recycle();
                  return;
                } finally {}
              } finally {}
            } finally {}
          } finally {}
        } finally {}
      } finally {}
      parcel2.recycle();
      parcel1.recycle();
      throw exception;
    }
    
    public boolean setBrightness(int param1Int) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeInt(param1Int);
        if (!this.mRemote.transact(143, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().setBrightness(param1Int);
          return bool;
        } 
        parcel2.readException();
        param1Int = parcel2.readInt();
        if (param1Int != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setComponentEnabled(ComponentName param1ComponentName, int param1Int1, int param1Int2) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1ComponentName != null) {
          parcel1.writeInt(1);
          param1ComponentName.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        parcel1.writeInt(param1Int1);
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
      parcel2.readException();
      parcel2.recycle();
      parcel1.recycle();
    }
    
    public void setCurrentUsbMode(int param1Int) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeInt(param1Int);
        if (!this.mRemote.transact(84, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setCurrentUsbMode(param1Int);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean setCustomBootAnim(String param1String) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        if (!this.mRemote.transact(128, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().setCustomBootAnim(param1String);
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setCustomCHARGE(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(13, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setCustomCHARGE(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setCustomFASTBOOT(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(5, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setCustomFASTBOOT(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setCustomHARDRST(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(11, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setCustomHARDRST(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setCustomLauncher(String param1String1, String param1String2) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String1);
        parcel1.writeString(param1String2);
        if (!this.mRemote.transact(131, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setCustomLauncher(param1String1, param1String2);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setCustomOTG(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(3, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setCustomOTG(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setCustomRecovery_v3(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(7, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setCustomRecovery_v3(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setCustomSDUPDATE(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(9, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setCustomSDUPDATE(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean setCustomShutAnim(String param1String) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        if (!this.mRemote.transact(129, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().setCustomShutAnim(param1String);
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setCustomSplashPath(String param1String) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        if (!this.mRemote.transact(1, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setCustomSplashPath(param1String);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean setDefaultAPN_v3(String param1String) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        if (!this.mRemote.transact(95, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().setDefaultAPN_v3(param1String);
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean setDefaultInputMethod(String param1String) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        if (!this.mRemote.transact(151, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().setDefaultInputMethod(param1String);
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setDefaultUsbMode(int param1Int) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeInt(param1Int);
        if (!this.mRemote.transact(85, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setDefaultUsbMode(param1Int);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean setDeviceOwner(String param1String) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        if (!this.mRemote.transact(79, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().setDeviceOwner(param1String);
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean setDisplayBlacklist(List<String> param1List, boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        boolean bool1;
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeStringList(param1List);
        if (param1Boolean) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        parcel1.writeInt(bool1);
        if (!this.mRemote.transact(43, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().setDisplayBlacklist(param1List, param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        if (parcel2.readInt() != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        parcel2.readStringList(param1List);
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setDisplayBlacklist_v3(List<String> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeStringList(param1List);
        if (!this.mRemote.transact(44, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setDisplayBlacklist_v3(param1List);
          return;
        } 
        parcel2.readException();
        parcel2.readStringList(param1List);
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setGps(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(196, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setGps(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setHomeKey(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(184, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setHomeKey(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean setHttpProxy(String param1String, int param1Int, List<String> param1List) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        parcel1.writeInt(param1Int);
        parcel1.writeStringList(param1List);
        if (!this.mRemote.transact(94, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().setHttpProxy(param1String, param1Int, param1List);
          return bool;
        } 
        parcel2.readException();
        if (parcel2.readInt() != 0)
          bool = true; 
        parcel2.readStringList(param1List);
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean setLauncher(String param1String) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        if (!this.mRemote.transact(130, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().setLauncher(param1String);
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean setLocationMode(int param1Int) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeInt(param1Int);
        if (!this.mRemote.transact(148, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().setLocationMode(param1Int);
          return bool;
        } 
        parcel2.readException();
        param1Int = parcel2.readInt();
        if (param1Int != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setLockNone() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(149, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setLockNone();
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean setLockPassword(String param1String) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        if (!this.mRemote.transact(202, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().setLockPassword(param1String);
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setLockSwipe() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(150, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setLockSwipe();
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setMediaVolumeValue_v3(int param1Int) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeInt(param1Int);
        if (!this.mRemote.transact(155, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setMediaVolumeValue_v3(param1Int);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setNotificationVolumeValue_v3(int param1Int) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeInt(param1Int);
        if (!this.mRemote.transact(157, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setNotificationVolumeValue_v3(param1Int);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setOTG(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(212, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setOTG(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setPackageEnabled(String param1String, boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(81, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setPackageEnabled(param1String, param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setPersistValue(String param1String1, String param1String2) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String1);
        parcel1.writeString(param1String2);
        if (!this.mRemote.transact(167, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setPersistValue(param1String1, param1String2);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setPowerLongPressKey(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(214, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setPowerLongPressKey(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setPowerSingleClickKey(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(215, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setPowerSingleClickKey(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setRecentKey(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(185, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setRecentKey(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setRuntimePermissions(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(53, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setRuntimePermissions(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setSafeModeDisabled(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(21, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setSafeModeDisabled(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setShutDownTime(boolean param1Boolean, int param1Int1, int param1Int2, int param1Int3, long param1Long) throws RemoteException {
      Exception exception;
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        try {
          parcel1.writeInt(param1Int1);
          try {
            parcel1.writeInt(param1Int2);
            try {
              parcel1.writeInt(param1Int3);
              try {
                parcel1.writeLong(param1Long);
                try {
                  if (!this.mRemote.transact(146, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
                    ICSDKManagerService.Stub.getDefaultImpl().setShutDownTime(param1Boolean, param1Int1, param1Int2, param1Int3, param1Long);
                    parcel2.recycle();
                    parcel1.recycle();
                    return;
                  } 
                  parcel2.readException();
                  parcel2.recycle();
                  parcel1.recycle();
                  return;
                } finally {}
              } finally {}
            } finally {}
          } finally {}
        } finally {}
      } finally {}
      parcel2.recycle();
      parcel1.recycle();
      throw exception;
    }
    
    public void setSleepTimeout_V3(int param1Int) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeInt(param1Int);
        if (!this.mRemote.transact(162, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setSleepTimeout_V3(param1Int);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setSysDate(int param1Int1, int param1Int2, int param1Int3) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeInt(param1Int1);
        parcel1.writeInt(param1Int2);
        parcel1.writeInt(param1Int3);
        if (!this.mRemote.transact(138, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setSysDate(param1Int1, param1Int2, param1Int3);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setSysTime(long param1Long) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeLong(param1Long);
        if (!this.mRemote.transact(136, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setSysTime(param1Long);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setTimeZone_v3(String param1String) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        if (!this.mRemote.transact(140, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setTimeZone_v3(param1String);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean setUsbOnlyCharging(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean) {
          i = 1;
        } else {
          i = 0;
        } 
        parcel1.writeInt(i);
        if (!this.mRemote.transact(198, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          param1Boolean = ICSDKManagerService.Stub.getDefaultImpl().setUsbOnlyCharging(param1Boolean);
          return param1Boolean;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        return param1Boolean;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setUserRestriction(String param1String, boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(30, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setUserRestriction(param1String, param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setVolumedownKey(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(216, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setVolumedownKey(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void setVolumeupKey(boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(217, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().setVolumeupKey(param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean setlockInputMethod(String param1String) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        if (!this.mRemote.transact(54, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().setlockInputMethod(param1String);
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean shutdownDevice() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(15, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().shutdownDevice();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void silentInstall(String param1String) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        if (!this.mRemote.transact(180, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().silentInstall(param1String);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void silentUnInstall(String param1String) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        if (!this.mRemote.transact(179, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().silentUnInstall(param1String);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean sleepDevice() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(16, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().sleepDevice();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void uninstallPackage(String param1String, boolean param1Boolean) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        if (param1Boolean)
          bool = true; 
        parcel1.writeInt(bool);
        if (!this.mRemote.transact(60, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().uninstallPackage(param1String, param1Boolean);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void unlockScreen() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(201, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          ICSDKManagerService.Stub.getDefaultImpl().unlockScreen();
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean updateSystemTime(String param1String) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeString(param1String);
        if (!this.mRemote.transact(200, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().updateSystemTime(param1String);
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public List<String> urlBlackListRead() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(224, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
          return ICSDKManagerService.Stub.getDefaultImpl().urlBlackListRead(); 
        parcel2.readException();
        return parcel2.createStringArrayList();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean urlBlackListWrite(List<String> param1List) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeStringList(param1List);
        if (!this.mRemote.transact(223, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().urlBlackListWrite(param1List);
          return bool;
        } 
        parcel2.readException();
        if (parcel2.readInt() != 0)
          bool = true; 
        parcel2.readStringList(param1List);
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public List<String> urlWhiteListRead() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(222, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null)
          return ICSDKManagerService.Stub.getDefaultImpl().urlWhiteListRead(); 
        parcel2.readException();
        return parcel2.createStringArrayList();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean urlWhiteListWrite(List<String> param1List) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        parcel1.writeStringList(param1List);
        if (!this.mRemote.transact(221, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().urlWhiteListWrite(param1List);
          return bool;
        } 
        parcel2.readException();
        if (parcel2.readInt() != 0)
          bool = true; 
        parcel2.readStringList(param1List);
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean wakeupDevice() throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.app.csdk.ICSDKManagerService");
        if (!this.mRemote.transact(17, parcel1, parcel2, 0) && ICSDKManagerService.Stub.getDefaultImpl() != null) {
          bool = ICSDKManagerService.Stub.getDefaultImpl().wakeupDevice();
          return bool;
        } 
        parcel2.readException();
        int i = parcel2.readInt();
        if (i != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
}


/* Location:              C:\Users\Tonyha7\Desktop\huovink_-mdm_catch_for_-lenovo-master\lspirer\lspirer\master-new\app\libs\Lenovo_Frameworks.jar!\android\app\csdk\ICSDKManagerService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */