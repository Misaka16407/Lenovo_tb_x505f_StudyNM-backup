package android.app.csdk;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.text.TextUtils;
import android.util.Log;
import java.io.File;
import java.util.List;

public class CSDKManager {
  public static final int LOCKSCREEN_MODE_NONE = 0;
  
  public static final int LOCKSCREEN_MODE_SWIPE = 1;
  
  private static final String TAG = "CSDKManager";
  
  private Context mContext;
  
  private ICSDKManagerService mService;
  
  public CSDKManager(Context paramContext) {
    this.mContext = paramContext;
  }
  
  public static String getLauncherPackageName(Context paramContext, int paramInt) {
    String str;
    Context context = null;
    Intent intent = new Intent("android.intent.action.MAIN");
    intent.addCategory("android.intent.category.HOME");
    ResolveInfo resolveInfo = paramContext.getPackageManager().resolveActivity(intent, 0);
    if (resolveInfo.activityInfo == null)
      return (String)context; 
    paramContext = context;
    if (!resolveInfo.activityInfo.packageName.equals("android")) {
      if (paramInt == 0)
        return resolveInfo.activityInfo.packageName; 
      str = resolveInfo.activityInfo.name;
    } 
    return str;
  }
  
  private ICSDKManagerService getService() throws RemoteException {
    ICSDKManagerService iCSDKManagerService = this.mService;
    if (iCSDKManagerService == null) {
      this.mService = ICSDKManagerService.Stub.asInterface(ServiceManager.getService("csdk"));
      iCSDKManagerService = this.mService;
    } 
    return iCSDKManagerService;
  }
  
  private ICSDKManagerService getService_CLK() throws RemoteException {
    ICSDKManagerService iCSDKManagerService = this.mService;
    if (iCSDKManagerService == null) {
      this.mService = ICSDKManagerService.Stub.asInterface(ServiceManager.getService("csdk"));
      iCSDKManagerService = this.mService;
    } 
    return iCSDKManagerService;
  }
  
  public List<String> APPIPWhiteListRead() {
    try {
      List<String> list = getService().APPIPWhiteListRead();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (List<String>)remoteException;
  }
  
  public boolean AddAppWhiteRule(String paramString) {
    boolean bool;
    try {
      bool = getService().AddAppWhiteRule(paramString);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean ClearAppRules() {
    boolean bool;
    try {
      bool = getService().ClearAppRules();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean ClearIpHostRules() {
    boolean bool;
    try {
      bool = getService().ClearIpHostRules();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean ClearRules() {
    boolean bool;
    try {
      bool = getService().ClearRules();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean SetEnable(boolean paramBoolean) {
    try {
      paramBoolean = getService().SetEnable(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean WriteToFile() {
    boolean bool;
    try {
      bool = getService().WriteToFile();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean aCLK(String paramString) {
    boolean bool2;
    boolean bool1 = false;
    Context context = this.mContext;
    if (context == null) {
      Log.d("CSDKManager", "mContext should be not null!");
      return bool1;
    } 
    try {
      String str1 = context.getPackageName();
      String str2 = (this.mContext.getPackageManager().getPackageInfo(str1, 64)).signatures[0].toCharsString();
      bool2 = getService_CLK().aCLK(paramString, str2, str1);
    } catch (Exception exception) {
      bool2 = bool1;
    } 
    return bool2;
  }
  
  public void activateLicense(String paramString) {
    Context context = this.mContext;
    if (context == null) {
      Log.d("CSDKManager", "mContext should be not null!");
      return;
    } 
    try {
      String str1 = context.getPackageName();
      String str2 = (this.mContext.getPackageManager().getPackageInfo(str1, 64)).signatures[0].toCharsString();
      getService_CLK().activateLicense(paramString, str2, str1);
    } catch (Exception exception) {}
  }
  
  public void addAppManageBlackList_v3(List<String> paramList) {
    try {
      getService().addAppManageBlackList_v3(paramList);
    } catch (RemoteException remoteException) {}
  }
  
  public void addAppManageWhiteList_v3(List<String> paramList) {
    try {
      getService().addAppManageWhiteList_v3(paramList);
    } catch (RemoteException remoteException) {}
  }
  
  public void addAutostartPackageBlackList(List<String> paramList) {
    try {
      getService().addAutostartPackageBlackList(paramList);
    } catch (RemoteException remoteException) {}
  }
  
  public void addInstallPackageBlackList(List<String> paramList) {
    try {
      getService().addInstallPackageBlackList(paramList);
    } catch (RemoteException remoteException) {}
  }
  
  public void addInstallPackageWhiteList(List<String> paramList) {
    try {
      getService().addInstallPackageWhiteList(paramList);
    } catch (RemoteException remoteException) {}
  }
  
  public void addNetworkAccessBlacklist(List<String> paramList) {
    try {
      getService().addNetworkAccessBlacklist(paramList);
    } catch (RemoteException remoteException) {}
  }
  
  public void addNetworkAccessWhitelist(List<String> paramList) {
    try {
      getService().addNetworkAccessWhitelist(paramList);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean addSSID(String paramString1, String paramString2, int paramInt, boolean paramBoolean) {
    try {
      paramBoolean = getService().addSSID(paramString1, paramString2, paramInt, paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public void addUninstallPackageBlackList(List<String> paramList) {
    try {
      getService().addUninstallPackageBlackList(paramList);
    } catch (RemoteException remoteException) {}
  }
  
  public void addUninstallPackageWhiteList(List<String> paramList) {
    try {
      getService().addUninstallPackageWhiteList(paramList);
    } catch (RemoteException remoteException) {}
  }
  
  public void allowBluetooth(boolean paramBoolean) {
    try {
      getService().allowBluetooth(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean allowBluetoothDataTransfer(boolean paramBoolean) {
    boolean bool = false;
    try {
      paramBoolean = getService().allowBluetoothDataTransfer(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = bool;
    } 
    return paramBoolean;
  }
  
  public void allowCamera(boolean paramBoolean) {
    try {
      getService().disableCamera(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void allowNavigaBar(boolean paramBoolean) {
    try {
      getService().allowNavigaBar(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void allowPowerKey(boolean paramBoolean) {
    try {
      getService().allowPowerKey(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void allowTFcard(boolean paramBoolean) {
    try {
      getService().allowTFcard(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void allowVolumeKey(boolean paramBoolean) {
    try {
      getService().allowVolumeKey(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean appWhiteListWrite(List<String> paramList) {
    if (paramList != null) {
      boolean bool1;
      try {
        getService().appWhiteListWrite(paramList);
        bool1 = true;
      } catch (RemoteException remoteException) {
        bool1 = false;
      } 
      return bool1;
    } 
    boolean bool = true;
  }
  
  public Bitmap captureScreen() {
    try {
      Bitmap bitmap = getService().captureScreen();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (Bitmap)remoteException;
  }
  
  public void controlApp(String paramString, boolean paramBoolean) {
    try {
      getService().setPackageEnabled(paramString, paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean deactivateLicense(String paramString) {
    boolean bool2;
    boolean bool1 = false;
    Context context = this.mContext;
    if (context == null) {
      Log.d("CSDKManager", "mContext should be not null!");
      return bool1;
    } 
    try {
      String str2 = context.getPackageName();
      String str1 = (this.mContext.getPackageManager().getPackageInfo(str2, 64)).signatures[0].toCharsString();
      bool2 = getService_CLK().deactivateLicense(paramString, str1, str2);
    } catch (Exception exception) {
      bool2 = bool1;
    } 
    return bool2;
  }
  
  public void disableApplicationManage_v3(boolean paramBoolean) {
    try {
      getService().disableApplicationManage_v3(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void disableAutostart(boolean paramBoolean) {
    try {
      getService().disableAutostart(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean disableBluetooth(boolean paramBoolean) {
    Log.d("CSDKManager", " disableBluetooth");
    try {
      paramBoolean = getService().disableBluetooth(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public void disableBluetoothShare(boolean paramBoolean) {
    try {
      getService().disableBluetoothShare(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean disableCamera(boolean paramBoolean) {
    try {
      paramBoolean = getService().disableCamera(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public void disableFactoryReset(boolean paramBoolean) {
    try {
      getService().disableFactoryReset(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean disableHiddenGame(boolean paramBoolean) {
    try {
      paramBoolean = getService().disableHiddenGame(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public void disableInstallation(boolean paramBoolean) {
    try {
      getService().disableInstallation(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void disableLocation(boolean paramBoolean) {
    try {
      getService().disableLocation(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean disableLockScreenNotification(boolean paramBoolean) {
    try {
      paramBoolean = getService().disableLockScreenNotification(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public void disableMultiUser(boolean paramBoolean) {
    try {
      getService().disableMultiUser(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void disableStatusBarNotification(boolean paramBoolean) {
    try {
      getService().disableStatusBarNotification(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean disableStatusBarPanel(boolean paramBoolean) {
    try {
      paramBoolean = getService().disableStatusBarPanel(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public void disableTabletMasterAutostart(boolean paramBoolean) {
    try {
      getService().disableTabletMasterAutostart(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void disableUnInstallation(boolean paramBoolean) {
    try {
      getService().disableUnInstallation(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean disableWifi(boolean paramBoolean) {
    Log.d("CSDKManager", " disableWifi");
    try {
      paramBoolean = getService().disableWifi(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean disableWifiDirect(boolean paramBoolean) {
    try {
      paramBoolean = getService().disableWifiDirect(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean disallowAPN_v3(boolean paramBoolean) {
    try {
      paramBoolean = getService().disallowAPN_v3(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean disallowAirplaneMode_v3(boolean paramBoolean) {
    try {
      paramBoolean = getService().disallowAirplaneMode_v3(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public void disallowAutoDateAndTime_V3(boolean paramBoolean) {
    try {
      getService().disallowAutoDateAndTime_V3(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean disallowBluetoothShare_v3(boolean paramBoolean) {
    try {
      paramBoolean = getService().disallowBluetoothShare_v3(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean disallowBluetooth_v3(boolean paramBoolean) {
    try {
      paramBoolean = getService().disallowBluetooth_v3(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean disallowData_v3(boolean paramBoolean) {
    try {
      paramBoolean = getService().disallowData_v3(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean disallowDevMode_v3(boolean paramBoolean) {
    return enableDevMode(paramBoolean);
  }
  
  public void disallowFactoryReset_v3(boolean paramBoolean) {
    try {
      getService().disallowFactoryReset_v3(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean disallowLocation_v3(boolean paramBoolean) {
    try {
      paramBoolean = getService().disallowLocation_v3(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean disallowLockScreenMode_v3(boolean paramBoolean) {
    try {
      paramBoolean = getService().disallowLockScreenMode_v3(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public void disallowLockScreenNotification_v3(boolean paramBoolean) {
    try {
      getService().disallowLockScreenNotification_v3(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void disallowMultiUser_v3(boolean paramBoolean) {
    try {
      getService().disallowMultiUser_v3(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean disallowSIMcard_v3(boolean paramBoolean) {
    try {
      paramBoolean = getService().disallowSIMcard_v3(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public void disallowSetAlarmVolume_v3(boolean paramBoolean) {
    try {
      getService().disallowSetAlarmVolume_v3(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void disallowSetBootTime_V3(boolean paramBoolean) {
    try {
      getService().disallowSetBootTime_V3(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void disallowSetBrightness_v3(boolean paramBoolean) {
    try {
      getService().disallowSetBrightness_v3(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void disallowSetInputMethod_v3(String paramString, boolean paramBoolean) {
    try {
      getService().disallowSetInputMethod_v3(paramString, paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void disallowSetMediaVolume_v3(boolean paramBoolean) {
    try {
      getService().disallowSetMediaVolume_v3(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void disallowSetNotificationVolume_v3(boolean paramBoolean) {
    try {
      getService().disallowSetNotificationVolume_v3(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void disallowSetShutDownTime_V3(boolean paramBoolean) {
    try {
      getService().disallowSetShutDownTime_V3(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void disallowSetSleepTimeout_V3(boolean paramBoolean) {
    try {
      getService().disallowSetSleepTimeout_V3(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void disallowSetSysDate_v3(boolean paramBoolean) {
    try {
      getService().disallowSetSysDate_v3(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void disallowSetSysTimeZone_v3(boolean paramBoolean) {
    try {
      getService().disallowSetSysTimeZone_v3(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void disallowSetSysTime_v3(boolean paramBoolean) {
    try {
      getService().disallowSetSysTime_v3(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void disallowSwitchLauncher_v3(boolean paramBoolean) {
    try {
      getService().disallowSwitchLauncher_v3(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean disallowUsbDebugging_v3(boolean paramBoolean) {
    try {
      paramBoolean = getService().disallowUsbDebugging_v3(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean disallowUsbMode_v3(boolean paramBoolean) {
    try {
      paramBoolean = getService().disallowUsbMode_v3(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean disallowWIFIAccessPoint_v3(boolean paramBoolean) {
    try {
      paramBoolean = getService().disallowWIFIAccessPoint_v3(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean disallowWifiDirect_v3(boolean paramBoolean) {
    try {
      paramBoolean = getService().disallowWifiDirect_v3(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean disallowWifiHotspot_v3(boolean paramBoolean) {
    try {
      paramBoolean = getService().disallowWifiHotspot_v3(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean disallowWifi_v3(boolean paramBoolean) {
    try {
      paramBoolean = getService().disallowWifi_v3(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean disallowWifiadvancesettings_v3(boolean paramBoolean) {
    try {
      paramBoolean = getService().disallowWifiadvancesettings_v3(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean disallowedBluetoothtethering_v3(boolean paramBoolean) {
    try {
      paramBoolean = getService().disallowedBluetoothtethering_v3(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean disallowedUSBtethering_v3(boolean paramBoolean) {
    try {
      paramBoolean = getService().disallowedUSBtethering_v3(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public void enableAirplaneMode(boolean paramBoolean) {
    try {
      getService().enableAirplaneMode(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void enableAllUnkownsources_v3(boolean paramBoolean) {
    try {
      getService().enableAllUnkownsources_v3(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean enableAutoBrightness(boolean paramBoolean) {
    try {
      paramBoolean = getService().enableAutoBrightness(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean enableBluetooth_v3(boolean paramBoolean) {
    try {
      paramBoolean = getService().enableBluetooth_v3(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean enableBluetoothtethering_v3(boolean paramBoolean) {
    try {
      paramBoolean = getService().enableBluetoothtethering_v3(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public void enableCaptureScreen_v3(boolean paramBoolean) {
    try {
      getService().enableCaptureScreen_v3(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean enableData(boolean paramBoolean) {
    try {
      paramBoolean = getService().enableData(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean enableData_v3(boolean paramBoolean) {
    try {
      paramBoolean = getService().enableData_v3(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean enableDevMode(boolean paramBoolean) {
    try {
      paramBoolean = getService().enableDevMode(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public void enableDevMode_v3(boolean paramBoolean) {
    try {
      getService().enableDevMode_v3(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean enableLocation_v3(boolean paramBoolean) {
    try {
      paramBoolean = getService().enableLocation_v3(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean enableMassStorage(boolean paramBoolean) {
    try {
      paramBoolean = getService().enableMassStorage(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public void enableNetworkAccess(boolean paramBoolean) {
    try {
      getService().enableNetworkAccess(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean enableSIM(boolean paramBoolean) {
    try {
      paramBoolean = getService().enableSIM(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public void enableSearch_v3(boolean paramBoolean) {
    try {
      getService().enableSearch_v3(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean enableSystemAutoUpdate(boolean paramBoolean) {
    try {
      paramBoolean = getService().enableSystemAutoUpdate(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean enableUSBtethering_v3(boolean paramBoolean) {
    try {
      paramBoolean = getService().enableUSBtethering_v3(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public void enableUnkownsources_v3(String paramString, boolean paramBoolean) {
    try {
      getService().enableUnkownsources_v3(paramString, paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean enableUsbDebugging(boolean paramBoolean) {
    try {
      paramBoolean = getService().enableUsbDebugging(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean enableWIFIcaptive_v3(boolean paramBoolean) {
    try {
      paramBoolean = getService().enableWIFIcaptive_v3(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean enableWifiHotspot_v3(boolean paramBoolean) {
    try {
      paramBoolean = getService().enableWifiHotspot_v3(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean enableWifi_v3(boolean paramBoolean) {
    try {
      paramBoolean = getService().enableWifi_v3(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public List<String> forceStopPackageWhiteListRead() {
    try {
      List<String> list = getService().forceStopPackageWhiteListRead();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (List<String>)remoteException;
  }
  
  public boolean forceStopPackageWhiteListWrite(List<String> paramList) {
    boolean bool;
    try {
      bool = getService().forceStopPackageWhiteListWrite(paramList);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public void fullScreenForever(boolean paramBoolean) {
    try {
      getService().fullScreenForever(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public List<String> getAppBlackRules() {
    try {
      List<String> list = getService().getAppBlackRules();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (List<String>)remoteException;
  }
  
  public List<String> getAppManageBlackList_v3() {
    try {
      List<String> list = getService().getAppManageBlackList_v3();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (List<String>)remoteException;
  }
  
  public List<String> getAppManageWhiteList_v3() {
    try {
      List<String> list = getService().getAppManageWhiteList_v3();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (List<String>)remoteException;
  }
  
  public List<String> getAutostartPackageBlackList() {
    try {
      List<String> list = getService().getAutostartPackageBlackList();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (List<String>)remoteException;
  }
  
  public String getBtStatus() {
    String str = null;
    try {
      String str1 = getService().getBtStatus();
      str = str1;
    } catch (RemoteException remoteException) {}
    return str;
  }
  
  public boolean getCustomCHARGE() {
    boolean bool;
    Log.d("CSDKManager", "getCustomCHARGE");
    try {
      Log.d("CSDKManager", "try getCustomCHARGE ");
      bool = getService().getCustomCHARGE();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean getCustomFASTBOOT() {
    boolean bool;
    Log.d("CSDKManager", "getCustomFASTBOOT ");
    try {
      Log.d("CSDKManager", "try getCustomFASTBOOT");
      bool = getService().getCustomFASTBOOT();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean getCustomHARDRST() {
    boolean bool;
    Log.d("CSDKManager", "getCustomHARDRST");
    try {
      Log.d("CSDKManager", "try getCustomHARDRST");
      bool = getService().getCustomHARDRST();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean getCustomOTG() {
    boolean bool;
    Log.d("CSDKManager", "getCustomOTG");
    try {
      Log.d("CSDKManager", "try getCustomOTG ");
      bool = getService().getCustomOTG();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean getCustomRecovery_v3() {
    boolean bool;
    Log.d("CSDKManager", "getCustomRecovery ");
    try {
      Log.d("CSDKManager", "try getCustomRecovery");
      bool = getService().getCustomRecovery_v3();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean getCustomSDUPDATE() {
    boolean bool;
    Log.d("CSDKManager", "getCustomSDUPDATE");
    try {
      Log.d("CSDKManager", "try getCustomSDUPDATE");
      bool = getService().getCustomSDUPDATE();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean getCustomSplashPath() {
    boolean bool;
    Log.d("CSDKManager", "getCustomSplashPath");
    try {
      Log.d("CSDKManager", "try getCustomSplashPath");
      bool = getService().getCustomSplashPath();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public String getDeviceInfo(int paramInt) {
    try {
      String str = getService().getDeviceInfo(paramInt);
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (String)remoteException;
  }
  
  public List<String> getDisplayBlacklist_v3() {
    try {
      List<String> list = getService().getDisplayBlacklist_v3();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (List<String>)remoteException;
  }
  
  public List<String> getInstallPackageBlackList() {
    try {
      List<String> list = getService().getInstallPackageBlackList();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (List<String>)remoteException;
  }
  
  public List<String> getInstallPackageWhiteList() {
    try {
      List<String> list = getService().getInstallPackageWhiteList();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (List<String>)remoteException;
  }
  
  public Bitmap getMiaScreen() {
    try {
      Bitmap bitmap = getService().getMiaScreen();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (Bitmap)remoteException;
  }
  
  public List<String> getNetworkAccessBlacklist() {
    try {
      List<String> list = getService().getNetworkAccessBlacklist();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (List<String>)remoteException;
  }
  
  public List<String> getNetworkAccessWhitelist() {
    try {
      List<String> list = getService().getNetworkAccessWhitelist();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (List<String>)remoteException;
  }
  
  public List<String> getUninstallPackageBlackList() {
    try {
      List<String> list = getService().getUninstallPackageBlackList();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (List<String>)remoteException;
  }
  
  public List<String> getUninstallPackageWhiteList() {
    try {
      List<String> list = getService().getUninstallPackageWhiteList();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (List<String>)remoteException;
  }
  
  public String getWifiStatus() {
    String str = null;
    try {
      String str1 = getService().getWifiStatus();
      str = str1;
    } catch (RemoteException remoteException) {}
    return str;
  }
  
  public boolean hideBackSoftKey(boolean paramBoolean) {
    try {
      paramBoolean = getService().hideBackSoftKey(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean hideHomeSoftKey(boolean paramBoolean) {
    try {
      paramBoolean = getService().hideHomeSoftKey(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean hideMenuSoftKey(boolean paramBoolean) {
    try {
      paramBoolean = getService().hideMenuSoftKey(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public void hideNavigationBar(boolean paramBoolean) {
    try {
      getService().hideNavigationBar(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean hideStatusBar(boolean paramBoolean) {
    try {
      paramBoolean = getService().hideStatusBar(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public boolean hideUsbMenu(boolean paramBoolean) {
    try {
      paramBoolean = getService().hideUsbMenu(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public void installPackage(String paramString) {
    try {
      getService().installPackage(paramString);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean isBackKeyAllowed() {
    boolean bool;
    try {
      bool = getService().isBackKeyAllowed();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isBluetoothAllowed() {
    boolean bool;
    try {
      bool = getService().isBluetoothAllowed();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isBluetoothDataTransferAllowed() {
    boolean bool = false;
    try {
      boolean bool1 = getService().isBluetoothDataTransferAllowed();
      bool = bool1;
    } catch (RemoteException remoteException) {}
    return bool;
  }
  
  public boolean isCameraAllowed() {
    boolean bool;
    try {
      bool = getService().isCameraAllowed();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isEnable() {
    boolean bool;
    try {
      bool = getService().isEnable();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isHomeKeyAllowed() {
    boolean bool;
    try {
      bool = getService().isHomeKeyAllowed();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isLicenseKeyEnabled(String paramString) {
    boolean bool;
    try {
      bool = getService_CLK().isLicenseKeyEnabled(paramString);
    } catch (Exception exception) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isLocationAllowed() {
    boolean bool;
    try {
      bool = getService().isLocationAllowed();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isNavigaBarAllowed() {
    boolean bool;
    try {
      bool = getService().isNavigaBarAllowed();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isNetworkRulesEnabled() {
    boolean bool;
    try {
      bool = getService().isNetworkRulesEnabled();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isPowerKeyAllowed() {
    boolean bool;
    try {
      bool = getService().isPowerKeyAllowed();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isRecentKeyAllowed() {
    boolean bool;
    try {
      bool = getService().isRecentKeyAllowed();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isTFcardAllowed() {
    boolean bool;
    try {
      bool = getService().isTFcardAllowed();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isUsbOnlyCharging() {
    boolean bool;
    try {
      bool = getService().isUsbOnlyCharging();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isVolumeKeyAllowed() {
    boolean bool;
    try {
      bool = getService().isVolumeKeyAllowed();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean killApp(String paramString) {
    boolean bool;
    try {
      bool = getService().killApp(paramString);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public void killApplicationProcess(String paramString) {
    try {
      getService().killApplicationProcess(paramString);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean launchFactoryReset() {
    boolean bool;
    try {
      bool = getService().launchFactoryReset();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public void masterClearInbulitSD() {
    try {
      getService().masterClearInbulitSD();
    } catch (RemoteException remoteException) {}
  }
  
  public boolean mobileData(boolean paramBoolean) {
    try {
      getService().mobileData(paramBoolean);
    } catch (RemoteException remoteException) {}
    return false;
  }
  
  public void putSettingsValue(int paramInt1, int paramInt2, String paramString1, String paramString2) {
    try {
      getService().putSettingsValue(paramInt1, paramInt2, paramString1, paramString2);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean rebootDevice() {
    boolean bool;
    try {
      bool = getService().rebootDevice();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean releaseKeyControl() {
    boolean bool;
    try {
      bool = getService().releaseKeyControl();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public void removeAppManageBlackList_v3(List<String> paramList) {
    try {
      getService().removeAppManageBlackList_v3(paramList);
    } catch (RemoteException remoteException) {}
  }
  
  public void removeAppManageWhiteList_v3(List<String> paramList) {
    try {
      getService().removeAppManageWhiteList_v3(paramList);
    } catch (RemoteException remoteException) {}
  }
  
  public void removeAutostartPackageBlackList(List<String> paramList) {
    try {
      getService().removeAutostartPackageBlackList(paramList);
    } catch (RemoteException remoteException) {}
  }
  
  public void removeDeviceOwner(String paramString) throws Exception {
    try {
      getService().removeDeviceOwner(paramString);
      return;
    } catch (Exception exception) {
      throw exception;
    } 
  }
  
  public void removeDisplayBlacklist_v3(List<String> paramList) {
    try {
      getService().removeDisplayBlacklist_v3(paramList);
    } catch (RemoteException remoteException) {}
  }
  
  public void removeInstallPackageBlackList(List<String> paramList) {
    try {
      getService().removeInstallPackageBlackList(paramList);
    } catch (RemoteException remoteException) {}
  }
  
  public void removeInstallPackageWhiteList(List<String> paramList) {
    try {
      getService().removeInstallPackageWhiteList(paramList);
    } catch (RemoteException remoteException) {}
  }
  
  public void removeNetworkAccessWhitelist(List<String> paramList) {
    try {
      getService().removeNetworkAccessWhitelist(paramList);
    } catch (RemoteException remoteException) {}
  }
  
  public void removeUninstallPackageBlackList(List<String> paramList) {
    try {
      getService().removeUninstallPackageBlackList(paramList);
    } catch (RemoteException remoteException) {}
  }
  
  public void removeUninstallPackageWhiteList(List<String> paramList) {
    try {
      getService().removeUninstallPackageWhiteList(paramList);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean requestKeyControl(int paramInt) {
    boolean bool;
    try {
      bool = getService().requestKeyControl(paramInt);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean requestKeyControl_V3(int paramInt, boolean paramBoolean) {
    try {
      paramBoolean = getService().requestKeyControl_V3(paramInt, paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public void setAlarmVolumeValue_v3(int paramInt) {
    try {
      getService().setAlarmVolumeValue_v3(paramInt);
    } catch (RemoteException remoteException) {}
  }
  
  public void setAppOpsPermissions(boolean paramBoolean) {
    try {
      getService().setAppOpsPermissions(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setBackkey(boolean paramBoolean) {
    try {
      getService().hideBackSoftKey(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setBootTime(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, long paramLong) {
    try {
      getService().setBootTime(paramBoolean, paramInt1, paramInt2, paramInt3, paramLong);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean setBrightness(int paramInt) {
    boolean bool;
    try {
      bool = getService().setBrightness(paramInt);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public void setComponentEnabled(ComponentName paramComponentName, int paramInt1, int paramInt2) {
    try {
      getService().setComponentEnabled(paramComponentName, paramInt1, paramInt2);
    } catch (RemoteException remoteException) {}
  }
  
  public void setCurrentUsbMode(int paramInt) {
    Log.d("CSDKManager", " setCurrentUsbMode");
    try {
      getService().setCurrentUsbMode(paramInt);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean setCustomBootAnim(String paramString) {
    boolean bool;
    try {
      bool = getService().setCustomBootAnim(paramString);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public void setCustomCHARGE(boolean paramBoolean) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("setCustomCHARGE enable = ");
    stringBuilder.append(paramBoolean);
    Log.d("CSDKManager", stringBuilder.toString());
    try {
      stringBuilder = new StringBuilder();
      this();
      stringBuilder.append("try setCustomCHARGE enable = ");
      stringBuilder.append(paramBoolean);
      Log.d("CSDKManager", stringBuilder.toString());
      getService().setCustomCHARGE(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setCustomFASTBOOT(boolean paramBoolean) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("setCustomFASTBOOT enable = ");
    stringBuilder.append(paramBoolean);
    Log.d("CSDKManager", stringBuilder.toString());
    try {
      stringBuilder = new StringBuilder();
      this();
      stringBuilder.append("try setCustomFASTBOOT enable = ");
      stringBuilder.append(paramBoolean);
      Log.d("CSDKManager", stringBuilder.toString());
      getService().setCustomFASTBOOT(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setCustomHARDRST(boolean paramBoolean) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("setCustomHARDRST enable = ");
    stringBuilder.append(paramBoolean);
    Log.d("CSDKManager", stringBuilder.toString());
    try {
      stringBuilder = new StringBuilder();
      this();
      stringBuilder.append("try setCustomHARDRST enable = ");
      stringBuilder.append(paramBoolean);
      Log.d("CSDKManager", stringBuilder.toString());
      getService().setCustomHARDRST(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setCustomLauncher(String paramString1, String paramString2) {
    try {
      getService().setCustomLauncher(paramString1, paramString2);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean setCustomLogo(String paramString) {
    null = true;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("logo path = ");
    stringBuilder.append(paramString);
    Log.d("CSDKManager", stringBuilder.toString());
    try {
      if (!TextUtils.isEmpty(paramString)) {
        File file = new File();
        this(paramString);
        if (file.exists()) {
          String[] arrayOfString = paramString.split("/");
          StringBuffer stringBuffer = new StringBuffer();
          this("");
          for (byte b = 0; b < arrayOfString.length; b++) {
            StringBuilder stringBuilder1 = new StringBuilder();
            this();
            stringBuilder1.append("index = ");
            stringBuilder1.append(b);
            stringBuilder1.append(" == ");
            stringBuilder1.append(arrayOfString[b]);
            Log.w("CSDKManager", stringBuilder1.toString());
            if (b == 1) {
              stringBuffer.append("data/");
            } else if (b == 2) {
              stringBuffer.append("media");
            } else {
              stringBuffer.append("/");
              stringBuffer.append(arrayOfString[b]);
            } 
          } 
          getService().setCustomSplashPath(stringBuffer.toString());
          Log.w("CSDKManager", stringBuffer.toString());
          return null;
        } 
      } 
    } catch (RemoteException remoteException) {}
    return false;
  }
  
  public void setCustomOTG(boolean paramBoolean) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("setCustomOTG enable = ");
    stringBuilder.append(paramBoolean);
    Log.d("CSDKManager", stringBuilder.toString());
    try {
      stringBuilder = new StringBuilder();
      this();
      stringBuilder.append("try setCustomOTG enable = ");
      stringBuilder.append(paramBoolean);
      Log.d("CSDKManager", stringBuilder.toString());
      getService().setCustomOTG(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setCustomRecovery_v3(boolean paramBoolean) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("setCustomRecovery enable = ");
    stringBuilder.append(paramBoolean);
    Log.d("CSDKManager", stringBuilder.toString());
    try {
      stringBuilder = new StringBuilder();
      this();
      stringBuilder.append("try setCustomRecovery enable = ");
      stringBuilder.append(paramBoolean);
      Log.d("CSDKManager", stringBuilder.toString());
      getService().setCustomRecovery_v3(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setCustomSDUPDATE(boolean paramBoolean) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("setCustomSDUPDATE enable = ");
    stringBuilder.append(paramBoolean);
    Log.d("CSDKManager", stringBuilder.toString());
    try {
      stringBuilder = new StringBuilder();
      this();
      stringBuilder.append("try setCustomSDUPDATE enable = ");
      stringBuilder.append(paramBoolean);
      Log.d("CSDKManager", stringBuilder.toString());
      getService().setCustomSDUPDATE(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean setCustomShutAnim(String paramString) {
    boolean bool;
    try {
      bool = getService().setCustomShutAnim(paramString);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public void setCustomSplashPath(String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("setCustomSplashPath path = ");
    stringBuilder.append(paramString);
    Log.d("CSDKManager", stringBuilder.toString());
    try {
      stringBuilder = new StringBuilder();
      this();
      stringBuilder.append("try setCustomSplashPath path = ");
      stringBuilder.append(paramString);
      Log.d("CSDKManager", stringBuilder.toString());
      getService().setCustomSplashPath(paramString);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean setDefaultAPN_v3(String paramString) {
    boolean bool;
    try {
      bool = getService().setDefaultAPN_v3(paramString);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean setDefaultInputMethod(String paramString) {
    boolean bool;
    try {
      bool = getService().setDefaultInputMethod(paramString);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public void setDefaultUsbMode(int paramInt) {
    try {
      getService().setDefaultUsbMode(paramInt);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean setDeviceOwner(String paramString) throws Exception {
    try {
      return getService().setDeviceOwner(paramString);
    } catch (Exception exception) {
      throw exception;
    } 
  }
  
  public boolean setDisplayBlacklist(List<String> paramList, boolean paramBoolean) {
    try {
      getService().setDisplayBlacklist(paramList, paramBoolean);
    } catch (RemoteException remoteException) {}
    return paramBoolean;
  }
  
  public void setDisplayBlacklist_v3(List<String> paramList) {
    try {
      getService().setDisplayBlacklist_v3(paramList);
    } catch (RemoteException remoteException) {}
  }
  
  public void setGps(boolean paramBoolean) {
    try {
      getService().setGps(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setHomeKey(boolean paramBoolean) {
    try {
      getService().hideHomeSoftKey(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean setHttpProxy(String paramString, int paramInt, List<String> paramList) {
    boolean bool;
    try {
      bool = getService().setHttpProxy(paramString, paramInt, paramList);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean setLauncher(String paramString) {
    boolean bool;
    try {
      bool = getService().setLauncher(paramString);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean setLocationMode(int paramInt) {
    boolean bool;
    try {
      bool = getService().setLocationMode(paramInt);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean setLockPassword(String paramString) {
    boolean bool;
    try {
      bool = getService().setLockPassword(paramString);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public void setLockScreenMode(int paramInt) {
    if (paramInt != 0) {
      if (paramInt == 1)
        try {
          getService().setLockSwipe();
        } catch (RemoteException remoteException) {} 
      return;
    } 
    getService().setLockNone();
  }
  
  public void setMediaVolumeValue_v3(int paramInt) {
    try {
      getService().setMediaVolumeValue_v3(paramInt);
    } catch (RemoteException remoteException) {}
  }
  
  public void setNotificationVolumeValue_v3(int paramInt) {
    try {
      getService().setNotificationVolumeValue_v3(paramInt);
    } catch (RemoteException remoteException) {}
  }
  
  public void setOTG(boolean paramBoolean) {
    try {
      getService().setOTG(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setPackageEnabled(String paramString, boolean paramBoolean) throws Exception {
    try {
      getService().setPackageEnabled(paramString, paramBoolean);
      return;
    } catch (Exception exception) {
      throw exception;
    } 
  }
  
  public void setPersistValue(String paramString1, String paramString2) {
    try {
      getService().setPersistValue(paramString1, paramString2);
    } catch (RemoteException remoteException) {}
  }
  
  public void setPowerLongPressKey(boolean paramBoolean) {
    try {
      getService().setPowerLongPressKey(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setPowerSingleClickKey(boolean paramBoolean) {
    try {
      getService().setPowerSingleClickKey(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setRecentKey(boolean paramBoolean) {
    try {
      getService().hideMenuSoftKey(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setRuntimePermissions(boolean paramBoolean) {
    try {
      getService().setRuntimePermissions(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setSafeModeDisabled(boolean paramBoolean) {
    try {
      getService().setSafeModeDisabled(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setShutDownTime(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, long paramLong) {
    try {
      getService().setShutDownTime(paramBoolean, paramInt1, paramInt2, paramInt3, paramLong);
    } catch (RemoteException remoteException) {}
  }
  
  public void setSleepTimeout_V3(int paramInt) {
    try {
      getService().setSleepTimeout_V3(paramInt);
    } catch (RemoteException remoteException) {}
  }
  
  public void setSysDate(int paramInt1, int paramInt2, int paramInt3) {
    try {
      getService().setSysDate(paramInt1, paramInt2, paramInt3);
    } catch (RemoteException remoteException) {}
  }
  
  public void setSysTime(long paramLong) {
    try {
      getService().setSysTime(paramLong);
    } catch (RemoteException remoteException) {}
  }
  
  public void setTimeZone_v3(String paramString) {
    try {
      getService().setTimeZone_v3(paramString);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean setUsbCharging(boolean paramBoolean) {
    try {
      paramBoolean = getService().setUsbOnlyCharging(paramBoolean);
    } catch (RemoteException remoteException) {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public void setUserRestriction(String paramString, boolean paramBoolean) {
    try {
      getService().setUserRestriction(paramString, paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setVolumedownKey(boolean paramBoolean) {
    try {
      getService().setVolumedownKey(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setVolumeupKey(boolean paramBoolean) {
    try {
      getService().setVolumeupKey(paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void setWifiProxy(boolean paramBoolean) {}
  
  public boolean setlockInputMethod(String paramString) {
    try {
      getService().setlockInputMethod(paramString);
    } catch (RemoteException remoteException) {}
    return false;
  }
  
  public boolean shutdownDevice() {
    boolean bool;
    try {
      bool = getService().shutdownDevice();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public void silentInstall(String paramString) {
    try {
      getService().installPackage(paramString);
    } catch (RemoteException remoteException) {}
  }
  
  public void silentUnInstall(String paramString) {
    try {
      getService().uninstallPackage(paramString, false);
    } catch (RemoteException remoteException) {}
  }
  
  public boolean sleepDevice() {
    boolean bool;
    try {
      bool = getService().sleepDevice();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public void uninstallPackage(String paramString, boolean paramBoolean) {
    try {
      getService().uninstallPackage(paramString, paramBoolean);
    } catch (RemoteException remoteException) {}
  }
  
  public void unlockScreen() {
    try {
      getService().unlockScreen();
    } catch (RemoteException remoteException) {}
  }
  
  public boolean updateSystemTime(String paramString) {
    boolean bool;
    try {
      bool = getService().updateSystemTime(paramString);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public List<String> urlBlackListRead() {
    try {
      List<String> list = getService().urlBlackListRead();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (List<String>)remoteException;
  }
  
  public boolean urlBlackListWrite(List<String> paramList) {
    boolean bool;
    try {
      bool = getService().urlBlackListWrite(paramList);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public List<String> urlWhiteListRead() {
    try {
      List<String> list = getService().urlWhiteListRead();
    } catch (RemoteException remoteException) {
      remoteException = null;
    } 
    return (List<String>)remoteException;
  }
  
  public boolean urlWhiteListWrite(List<String> paramList) {
    boolean bool;
    try {
      bool = getService().urlWhiteListWrite(paramList);
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
  
  public boolean wakeupDevice() {
    boolean bool;
    try {
      bool = getService().wakeupDevice();
    } catch (RemoteException remoteException) {
      bool = false;
    } 
    return bool;
  }
}


/* Location:              C:\Users\Tonyha7\Desktop\huovink_-mdm_catch_for_-lenovo-master\lspirer\lspirer\master-new\app\libs\Lenovo_Frameworks.jar!\android\app\csdk\CSDKManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */